# Feishu-MCP Server Installation

GitHub: https://github.com/cso1z/Feishu-MCP

## What It Provides

15 tools for Feishu document/drive operations (MCP protocol):
- `create_feishu_document` / `get_feishu_document_info` / `get_feishu_document_blocks`
- `search_feishu_documents` (documents + Wiki)
- `batch_update_feishu_block_text` / `batch_create_feishu_blocks` / `delete_feishu_document_blocks`
- `get_feishu_image_resource` / `upload_and_bind_image_to_block`
- `create_feishu_table` / `get_feishu_whiteboard_content` / `fill_whiteboard_with_plantuml`
- `get_feishu_root_folder_info` / `get_feishu_folder_files` / `create_feishu_folder`

## Installation (Node.js)

```bash
# Clone
cd ~/AppData/Local/Temp
git clone --depth 1 https://github.com/cso1z/Feishu-MCP.git

# Install pnpm (required)
npm install -g pnpm

# Install dependencies
cd Feishu-MCP
pnpm install

# Build (skip pnpm build — it fails on Windows; use tsc directly)
npx tsc && npx tsc-alias
```

## Configuration

Create `.env` in the Feishu-MCP directory:
```
FEISHU_APP_ID=cli_xxxxxxxxxxxxxxxx
FEISHU_APP_SECRET=your_secret_here
FEISHU_BASE_URL=https://open.feishu.cn/open-apis
FEISHU_AUTH_TYPE=tenant
FEISHU_ENABLED_MODULES=document,drive
```

## Register as Hermes MCP Server

Edit `~/.hermes/config.yaml` — add under `mcp_servers:`:

```yaml
mcp_servers:
  feishu-mcp:
    command: node
    args:
    - C:/Users/HMSJ/AppData/Local/Temp/Feishu-MCP/dist/cli.js
    - --stdio
    cwd: C:/Users/HMSJ/AppData/Local/Temp/Feishu-MCP
    env:
      FEISHU_APP_ID: cli_xxxxxxxxxxxxxxxx
      FEISHU_AUTH_TYPE: tenant
      FEISHU_BASE_URL: https://open.feishu.cn/open-apis
      FEISHU_ENABLED_MODULES: document,drive
    enabled: true
```

## Verify

```bash
hermes mcp test feishu-mcp
```

Should show `✓ Connected` and list 15 tools.

## OAuth User Mode Authorization

When `FEISHU_AUTH_TYPE=*** the MCP server operates as the user (not the app). Required for accessing user-specific resources like personal drive folders.

### Flow

1. Any MCP tool call triggers the OAuth flow if no valid token exists
2. The tool returns an error containing the authorization URL (in the `state` parameter)
3. User opens the URL in a **local browser** (not the browser tool — it runs on Browserbase)
4. After authorizing, the browser redirects to `http://localhost:3333/callback`
5. The MCP server's callback handler exchanges the code for a `user_access_token`
6. Token is cached in `~/.cache/feishu-mcp/user_token_cache.json`

### Generating the Authorization URL

The state parameter is base64-encoded JSON: `{appId, appSecret, clientKey, redirectUri, timestamp}`. To reconstruct:

```python
import base64, json, time
from urllib.parse import quote

state_data = {
    "appId": "<app_id>",
    "appSecret": "<app_secret>",
    "clientKey": "<from previous state>",
    "redirectUri": "http://localhost:3333/callback",
    "timestamp": int(time.time())
}
state = base64.b64encode(json.dumps(state_data).encode()).decode()
# Use the full scope from the MCP error message
```

### Opening the URL on Windows

The browser tool runs on Browserbase (remote) — **cannot** handle `localhost:3333` callbacks. Must use local browser:

```bash
# Option 1: PowerShell
powershell.exe -Command "Start-Process 'msedge' '<URL>'"

# Option 2: Create .url shortcut on desktop
python3 -c "
with open('C:/Users/$USER/Desktop/飞书授权.url', 'w') as f:
    f.write('[InternetShortcut]\nURL=<URL>\n')
"
```

**Terminal truncates long base64 display** with `...` but file content is intact. Verify with Python.

### config.yaml env vars override .env

MCP server env vars in `config.yaml` take precedence over the `.env` file in the project directory. If the secret differs, config.yaml wins. This causes `invalid_client` (error 20002) during OAuth.

**Diagnosis:** Decode the `state` parameter from the auth URL to check which secret is being used:
```python
import base64, json
state = "<state from URL>"
data = json.loads(base64.b64decode(state).decode())
print(data['appSecret'])  # Compare with actual secret
```

**Fix:** Update config.yaml, kill MCP node processes, restart Hermes.

## Pitfalls

1. **`pnpm build` fails on Windows** — The `prepare` script calls `pnpm run build` which fails. Use `npx tsc && npx tsc-alias` instead.
2. **`hermes mcp add` args format** — The CLI `--args` flag parses JSON arrays incorrectly. Edit `config.yaml` directly instead.
3. **Server starts in HTTP mode by default** — Must pass `--stdio` flag for MCP stdio transport.
4. **Git submodule errors** — Use `git clone --depth 1` to skip submodules; the `doc/wiki-repo` submodule is not needed.
5. **Secret redaction in terminal** — The gateway scrubs `Authorization` headers in curl output. Use Python `urllib.request` for API calls that need auth tokens.
6. **OAuth `invalid_client` (20002)** — config.yaml `FEISHU_APP_SECRET` differs from actual secret. See "config.yaml env vars override .env" above.
7. **Config changes require MCP restart** — `hermes mcp login` doesn't work for stdio servers. Must kill MCP node processes (`powershell.exe -Command "Stop-Process -Id <PID> -Force"`) and restart Hermes.
8. **Browser tool can't handle OAuth callbacks** — Runs on Browserbase, `localhost:3333` doesn't reach local machine. Always use local browser.
9. **Callback port 3333 conflict** — Feishu-MCP starts HTTP server on port 3333 for OAuth. If port is in use, authorization fails silently.
