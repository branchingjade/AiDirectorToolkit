# 飞书文档（Doc）发布

从 Obsidian/本地 Markdown 直接创建飞书文档。

## 前提

- `lark-cli` 已安装并登录（`lark-cli auth status` 确认 `docx:document:create` 权限）
- 以用户身份操作（`--as user`），bot 没有文档创建权限

## 基本命令

```bash
lark-cli docs +create \
  --doc-format markdown \
  --content @_push.md \
  --parent-token <folder_token> \
  --as user
```

- `--doc-format markdown`：直接传 Markdown，无需转 XML
- `@_push.md`：文件传参（**必须用相对路径**，`@file` 不接受绝对路径）
- `--parent-token`：目标文件夹 token（飞书文件夹 URL 中提取）
- `--as user`：用户身份，需 `docx:document:create` scope

## 文档标题规则

- 笔记第一个 `# 标题` = 飞书文档标题
- 正文从 `## ` 开始
- 只能有一个一级标题，否则标题可能被识别为 `Untitled`

## 返回

```json
{
  "document": {
    "document_id": "Q8i7djCP0ovIygxVy8zcsWmRnDh",
    "url": "https://my.feishu.cn/docx/Q8i7djCP0ovIygxVy8zcsWmRnDh"
  }
}
```

## Markdown 转义

| 字符 | 转义 |
|------|------|
| `\` | `\\` |
| `#` 行首 | `\#` |
| `*` `_` `[` `]` `` ` `` `$` `~` `<` | 前加 `\` |
| 代码块内 | 无需转义 |
| `[[wikilink]]` | 改为纯文本 |

## 与 Gateway 的区别

| | Gateway (IM) | lark-cli docs |
|------|------|------|
| 产出 | 群聊消息 | 飞书文档 |
| 格式 | post (Markdown 子集) | 完整 Docx |
| 身份 | bot | user |
| 场景 | 即时回复 | 知识发布 |
