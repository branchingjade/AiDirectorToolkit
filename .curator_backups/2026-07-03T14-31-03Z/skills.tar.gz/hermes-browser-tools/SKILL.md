---
name: hermes-browser-tools
description: "Configure, debug, and troubleshoot Hermes browser toolset — backend selection, agent-browser CLI dependency, headed/headless modes, and browser tool enable/disable."
version: 1.0.0
---

# Hermes Browser Tools

Hermes 的 `browser` 工具集（`browser_navigate`、`browser_click`、`browser_snapshot` 等）使用 `agent-browser` CLI 作为本地驱动。了解这个依赖关系是排查浏览器工具问题的关键。

## 架构

```
Hermes browser 工具 (browser_navigate / click / snapshot / ...)
  └── browser_tool.py ──调用──▶ agent-browser CLI (npm 全局包)
                                   └── 启动 Chromium 实例
```

**后端选项：**
| 后端 | 类型 | 需要 |
|------|------|------|
| agent-browser (默认) | 本地 headless Chromium | `npm install -g agent-browser` |
| Browserbase | 云端 | `BROWSERBASE_API_KEY` + `BROWSERBASE_PROJECT_ID` |
| Browser Use | 云端 | `BROWSER_USE_API_KEY` |
| Camofox | 本地反检测 | `CAMOFOX_URL` |

## 常见操作

### 启用/禁用

```bash
hermes tools disable browser   # 禁用
hermes tools enable browser    # 启用
```
工具变更需要 `/reset` 或重启会话生效。

### 有头模式（agent-browser 直接调用）

在 `~/.hermes/.env` 中添加：
```
AGENT_BROWSER_HEADED=true
```
但仅对 `agent-browser` 直接调用有效 — Hermes browser 工具通过 `--cdp` 模式控制 Chrome，窗口由 Chrome 自身的启动方式决定。

### CDP Override 模式（绕过 --session 死锁）

Hermes 内置了 `_get_cdp_override()` 机制，设置 `BROWSER_CDP_URL` 后自动切换到 `--cdp` 模式而非 `--session`：

```bash
# ~/.hermes/.env
BROWSER_CDP_URL=http://localhost:9222
```

适用于 Windows 下 `agent-browser --session` 死锁问题。详见 `hermes-windows-browser` 技能。

### 验证

```bash
agent-browser --version        # 确认 CLI 已安装
hermes tools list | grep browser   # 确认工具集已启用
```

## 陷阱

- **卸载 agent-browser 会直接导致 Hermes browser 工具集不可用。** 报错 `[WinError 2] 系统找不到指定的文件` 就是这个原因。Hermes browser 工具本质上是 `agent-browser` CLI 的 wrapper，并非直接控制 Chromium。
- **`agent-browser --session` 在 Windows 上死锁**：daemon/socket IPC 不兼容，导致所有 Hermes browser 操作卡死。解决：用 `BROWSER_CDP_URL` 切到 `--cdp` 模式。详见 `hermes-windows-browser` 技能。
- npm 全局包卸载后可能有临时目录残留（`.agent-browser-*`），手动清理：`rm -rf ~/AppData/Roaming/npm/node_modules/.agent-browser-*`
- 云端后端（Browserbase/Browser Use）不需要本地 agent-browser，但需要付费 API key。
- 有头模式（`AGENT_BROWSER_HEADED=true`）只对 agent-browser 直接调用有效。Hermes browser 通过 `--cdp` 控制 Chrome 时，Chrome 窗口由启动参数（`--headless` / VBS `Run`）决定。

## 相关技能（注意重叠，curator 后续合并）

- `hermes-windows-browser` — Windows CDP 配置、独立 profile、无头/有头模式
- `hermes-browser-windows` — 同主题，内容近似，在 devops 分类下
