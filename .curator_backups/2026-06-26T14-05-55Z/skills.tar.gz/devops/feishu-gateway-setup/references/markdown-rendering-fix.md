# Feishu Markdown Rendering Fix

## Current State (2026-06-24)

ALL messages are sent as `post` type — no table downgrade, no conditionals.

### Verified working (tested on Feishu DM)

| Feature | Status |
|---------|--------|
| Bold, italic, links | ✅ |
| Headings, lists, blockquotes | ✅ |
| **Tables** | ✅ (contrary to old assumption) |
| Code blocks (with language) | ✅ |
| Inline code | ✅ |
| Multi-paragraph messages | ✅ |
| Columns / multi-column layout | ❌ (need card messages) |
| Buttons / interactive elements | ❌ (need card messages) |

### Code (feishu.py `_build_outbound_payload`)

```python
    def _build_outbound_payload(self, content: str) -> tuple[str, str]:
        return "post", _build_markdown_post_payload(content)
```

### After code changes

```bash
hermes gateway restart   # must run externally, not inside gateway
```

### Unrelated: `final_response_markdown` is CLI-Only

The `display.final_response_markdown` config setting (values: `render`, `strip`, `raw`) only affects the CLI/TUI output, not the gateway.
