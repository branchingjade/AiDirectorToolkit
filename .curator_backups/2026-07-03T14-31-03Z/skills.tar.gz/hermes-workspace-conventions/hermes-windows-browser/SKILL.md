---
name: hermes-windows-browser
description: Hermes browser 工具集在 Windows 上的配置与故障排除。
version: 1.0.0
triggers:
  - "Hermes browser 不工作/卡死/超时"
  - "agent-browser --session 卡住"
  - "Windows 上配置 Hermes 浏览器"
  - "BROWSER_CDP_URL"
  - "Chrome remote debugging"
  - "有头模式浏览器"
---

# Hermes Windows Browser 配置

## 核心问题

Hermes browser 工具集底层依赖 `agent-browser` CLI。在 Windows 上，`agent-browser --session <name>` 模式会死锁（daemon/socket IPC 不兼容）。`agent-browser --cdp <port>` 模式正常。

## 修复方案（零代码修改）

Hermes 已有 CDP override 机制（`browser_tool.py` `_get_cdp_override()`），只需配置环境变量即可自动切换到 `--cdp` 模式。

### 1. 设置环境变量

在 `~/.hermes/.env` 添加：

```
BROWSER_CDP_URL=http://localhost:9222
```

`_resolve_cdp_override()` 会自动发现 Chrome WebSocket 端点，支持：
- `http://localhost:9222`（推荐）
- `ws://localhost:9222`
- 完整 WS URL

### 2. Chrome 以 debug 模式运行

```bash
"/c/Program Files/Google/Chrome/Application/chrome.exe" --remote-debugging-port=9222
```

### 3. 开机自启

在 `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\` 放入 VBS 脚本（静默启动）：

```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """C:\Program Files\Google\Chrome\Application\chrome.exe"" --remote-debugging-port=9222", 0, False
```

### 4. 重启 Hermes

`/reset` 使环境变量生效。

## 验证

```bash
curl -s http://localhost:9222/json/version
# 应返回 Chrome 版本信息

agent-browser open https://baidu.com --cdp 9222 --json
# 应返回成功
```

## 独立 Chrome Profile（关键）

**不能使用用户主 profile！** Windows 上 Chrome 有后台驻留进程（"关闭后继续运行后台应用"），`taskkill /F` 无法彻底清理，进程立即重生。新 Chrome 启动时会复用已有实例，忽略 `--remote-debugging-port`，导致端口始终无监听。

**解决方案：用 `--user-data-dir` 创建独立 profile：**

```bash
chrome.exe --remote-debugging-port=9222 --user-data-dir=C:\Users\<用户>\.hermes\chrome-cdp-profile
```

这个独立 profile 与主 Chrome 完全隔离，不冲突。登录态在此 profile 内持久保存，重启不丢失。

完整启动命令：
```bash
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9222 \
  --user-data-dir=C:/Users/HMSJ/.hermes/chrome-cdp-profile
```

## 开机自启（VBS 可见窗口）

Chrome 后台进程（`terminal(background=true)` 启动的）会表现为"后台任务"且窗口不可见。用户需要看到 Chrome 窗口来交互（扫码登录等）。使用 `cmd //c start` + 独立 profile：

```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """C:\Program Files\Google\Chrome\Application\chrome.exe"" --remote-debugging-port=9222 --user-data-dir=C:\Users\HMSJ\.hermes\chrome-cdp-profile", 1, False
```

`1` = 正常可见窗口，`0` = 隐藏。（注：`terminal(background=true)` 下的 Chrome 窗口不可见。）

放入 `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\chrome-debug.vbs`。

模板脚本：`skill_view(name="hermes-windows-browser", file_path="scripts/chrome-cdp-startup.vbs")`

## 相关技能（注意重叠，curator 后续合并）

- `hermes-browser-tools` — 浏览器工具集通用参考（架构、后端、陷阱）
- `hermes-browser-windows` — 同主题，内容近似，在 devops 分类下

## 有头 vs 无头模式

**有头（默认）**：Chrome 窗口可见，适合扫码登录（微信等需要视觉交互的场景）。

**无头**：`--headless=new`，窗口不可见，适合登录后的日常使用。

```bash
# 无头模式启动（登录态不变，cookie 在 profile 中持久保存）
chrome.exe --remote-debugging-port=9222 --headless=new --user-data-dir=C:\Users\<user>\.hermes\chrome-cdp-profile
```

切换方法：关掉 Chrome 重开，换 `--headless=new` 参数。`--user-data-dir` 不变，登录态不丢。

## 窗口可见性陷阱

| 启动方式 | 窗口可见 | 说明 |
|----------|---------|------|
| `cmd //c start "" chrome.exe ...` | ✅ | 正确方式 |
| VBS `Run(..., 1, False)` | ✅ | 开机自启推荐 |
| `terminal(background=true)` | ❌ | 后台进程无窗口，且 Hermes 后台任务列表累积 |
| `execute_code` `subprocess.Popen` | ❌ | 沙箱环境无桌面权限 |
| VBS `Run(..., 0, False)` | ❌ | 等同于隐藏窗口 |

## 注意事项

- **不关主 Chrome**：独立 profile 模式不需要关闭用户的正常 Chrome，两不干扰。
- `BROWSER_CDP_URL` 设置后 Hermes 自动跳过 session/daemon 管理
- 如需切换回 cloud 模式（Browserbase 等），删除 `BROWSER_CDP_URL` 即可
- `/browser connect` 命令会覆盖 `BROWSER_CDP_URL`
- `taskkill /F /IM chrome.exe` 对主 Chrome 无效（后台驻留保护），但对独立 profile 的 Chrome 有效
