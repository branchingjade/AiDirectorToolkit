---
name: alist
description: alist 安装、配置与故障排除——Windows 环境下将云存储挂载为本地 WebDAV。触发词：alist、WebDAV、百度网盘挂载、alist 配置。
---

# alist

Windows 下安装配置 alist，将百度网盘等云存储挂载为本地 WebDAV。

## 安装

```bash
# 下载最新版
mkdir -p ~/Documents/Hermes/tools/alist
cd ~/Documents/Hermes/tools/alist
curl -sL "https://api.github.com/repos/AlistGo/alist/releases/latest" | grep -oP '"tag_name":\s*"\K[^"]+'
# 下载 alist-windows-amd64.zip → 解压

# 初始化（获取管理员密码）
./alist.exe admin random
```

## 添加百度网盘存储

### 1. 获取 refresh token

百度 OAuth URL 格式：
```
https://openapi.baidu.com/oauth/2.0/authorize?response_type=code&client_id=hq9yQ9w9kR4YHj1kyYafLygVocobh7Sf&redirect_uri=oob&scope=basic,netdisk
```

用户在浏览器打开 → 登录百度账号 → 授权 → 获取 authorization code → 交换 refresh token：

```python
import json, urllib.request
# POST https://openapi.baidu.com/oauth/2.0/token
# grant_type=authorization_code, code=<授权码>, client_id=..., client_secret=..., redirect_uri=oob
# 返回 refresh_token
```

### 2. 添加存储（API 方式）

通过管理 API 添加，避免浏览器中文编码问题：

```python
# 登录 → POST /api/auth/login
# 创建 → POST /api/admin/storage/create
#   driver: "BaiduNetdisk"
#   mount_path: "/百度网盘"
#   webdav_policy: "native_proxy"
#   addition: JSON with refresh_token, root_folder_path, etc.
```

### 3. 设置根文件夹路径

通过 API 编辑存储，修改 `addition` 中的 `root_folder_path`：
- 默认 `"/"` → 暴露整个百度网盘根目录
- 改为 `"/WebDAV"` → 只暴露指定文件夹（需先在百度网盘创建该文件夹）

## WebDAV 策略 ⚠️

**Windows 原生 WebDAV 客户端必须用"本地代理"**，不能用"302 重定向"——Windows 发送 GET 探测 /dav/ 会被 405 拒绝。

推荐用 RaiDrive 替代 Windows 原生 WebDAV，兼容性更好。

## 开机自启

Startup 目录 `.vbs` 文件，静默启动：

```vbs
Set WshShell = CreateObject("WScript.Shell")
WshShell.CurrentDirectory = "C:\Users\<user>\Documents\Hermes\tools\alist"
WshShell.Run "C:\Users\<user>\Documents\Hermes\tools\alist\alist.exe server", 0, False
```

放至 `%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\alist-server.vbs`。

## 管理员密码管理

```bash
# 查看当前管理员
./alist.exe admin

# 重置密码（直接写 config + 在线清缓存）
./alist.exe admin set <新密码>
```

**注意**：`alist admin set` 修改 config.json 后会尝试通过 API 清缓存（需 server 正在运行）。如果 server 未运行，重启后生效。

## Kimi WebBridge 优先

当 alist 管理页面需要浏览器操作且涉及中文时，优先用 **Kimi WebBridge** 操作用户真实浏览器（已有登录态），而不是 Hermes CDP browser——后者对中文表单输入支持差（编码问题导致登录失败）。

```bash
# 导航
curl.exe -s -X POST http://127.0.0.1:10086/command -H "Content-Type: application/json" \
  --data-binary @/c/Users/<user>/AppData/Local/Temp/wb-payload.json

# payload: {"action":"navigate","args":{"url":"http://localhost:5244/@manage","newTab":true},"session":"alist"}
```

## 全局安全设置

```python
# 关签名（WebDAV 不需要）+ 开首页索引
api("/api/admin/setting/save", method="POST", body=[
    {"key": "sign_all", "value": "false"},
    {"key": "allow_indexed", "value": "true"}
])

# 禁用 guest 用户
api("/api/admin/user/save", method="POST", body={
    "id": guest_id, "username": "guest", "password": "",
    "base_path": "/", "role": 2, "disabled": True, "permission": 0
})
```

## 常见问题

### Windows WebDAV "Method Not Allowed"
- **原因**：Windows WebDAV 客户端发 GET 到 /dav/ 被 alist 拒绝（405）
- **解决**：存储 WebDAV 策略改为"本地代理"；或用 RaiDrive

### curl 登录 API 返回 400
- **原因**：bash 编码中文参数导致 JSON 损坏
- **解决**：用 Python urllib 发请求（UTF-8 编码可靠）

### alist admin set 改了密码但不生效
- **原因**：server 运行中缓存了旧凭据
- **解决**：重启 alist server（`alist admin set` 会自动清缓存，失败则手动重启）

## 陷阱

- **不要用 bash/curl 内联中文字段**——shell 编码问题导致 JSON 损坏，使用 Python urllib 或 WebBridge
- **Windows 原生 WebDAV 客户端兼容性差**——推荐 RaiDrive
- **修改密码前告知用户**——`alist admin set` 就地改密码，用户可能无法登录
- **storage/save API 需要传完整对象**——只传要改的字段会导致未传字段被清空。先 GET 当前存储对象，修改目标字段后完整 PUT 回去
