# 飞书发送交互式卡片（Interactive Message Card）

通过 Python 直接调用飞书 API 发送卡片，避免 shell 转义问题。

## 获取 Token

```python
import json, urllib.request

req = urllib.request.Request(
    "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
    data=json.dumps({"app_id": app_id, "app_secret": app_secret}).encode(),
    headers={"Content-Type": "application/json"}
)
resp = json.loads(urllib.request.urlopen(req).read())
token = resp["tenant_access_token"]
```

## 发送卡片

```python
card = {
    "config": {"wide_screen_mode": True},
    "header": {
        "title": {"content": "标题", "tag": "plain_text"},
        "template": "blue"  # blue/wathet/turquoise/green/yellow/orange/red/carmine/violet/purple/indigo/grey
    },
    "elements": [
        {"tag": "markdown", "content": "**Markdown内容**\n\n表格等"},
        {"tag": "hr"},
        {"tag": "markdown", "content": "更多内容"}
    ]
}

body = {
    "receive_id": chat_id,
    "msg_type": "interactive",
    "content": json.dumps(card)  # content 是 JSON 字符串
}

req = urllib.request.Request(
    "https://open.feishu.cn/open-apis/im/v1/messages?receive_id_type=chat_id",
    data=json.dumps(body).encode(),
    headers={
        "Content-Type": "application/json",
        "Authorization": "Bearer " + token
    }
)
result = json.loads(urllib.request.urlopen(req).read())
```

## 注意事项

- `content` 字段必须是 JSON **字符串**（`json.dumps(card)`），不是对象
- 使用 `urllib` 而非 `curl`，避免 shell 转义和 secret redaction 问题
- 卡片支持 markdown 语法：**加粗**、表格、链接等
- 飞书**普通消息不支持 markdown**，需要用卡片格式
- `receive_id_type` 可选：`chat_id`（群聊）、`open_id`（用户）、`union_id`

## 卡片元素类型

| tag | 用途 |
|-----|------|
| `markdown` | Markdown 文本 |
| `plain_text` | 纯文本 |
| `hr` | 分割线 |
| `action` | 按钮/交互组件 |
| `note` | 备注 |
| `image` | 图片 |
