# 视觉模型兜底：Tesseract OCR 截图分析

当 active model 不支持 vision（如 DeepSeek 全系列）且 `vision_analyze` 返回 `unknown variant image_url` 时，走 Tesseract OCR 兜底。

## 决策树

```
vision_analyze 调用
  ├─ 成功 → 直接使用
  └─ 400 error: "unknown variant image_url"
       └─ 模型不支持图片 → OCR 兜底
            ├─ 图像分析（尺寸/颜色/结构）→ 初步判断内容类型
            ├─ 深色模式截图 → 反转+阈值预处理
            └─ Tesseract OCR → 提取文字
```

## 一次性环境准备

### Windows

```bash
# Tesseract 引擎（winget，无需管理员）
winget install UB-Mannheim.TesseractOCR

# Python 包
/c/Users/HMSJ/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe -m ensurepip
/c/Users/HMSJ/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe -m pip install pytesseract

# 中文语言数据（42MB）— 不要放 Program Files（需管理员），放用户目录
mkdir -p ~/tessdata
curl -L -o ~/tessdata/chi_sim.traineddata \
  "https://github.com/tesseract-ocr/tessdata/raw/main/chi_sim.traineddata"
```

### 验证

```bash
TESSDATA_PREFIX="$HOME/tessdata" python -c "
import pytesseract
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
print(pytesseract.get_languages())
"  # 应输出 ['chi_sim', 'eng']
```

## 运行时 OCR 流程

### 1. 先做图像像素分析（不依赖 OCR）

```python
from PIL import Image

img = Image.open("screenshot.png")

# 量化颜色分布
quantized = img.quantize(colors=16)
# → 判断是深色模式（#151515 占比 >50%）还是浅色

# 行亮度分布 → 判断结构（标题/正文/列表）
# 宽高比 → 判断来源（0.38 ≈ 手机截图）
```

### 2. 深色模式预处理（关键！不做 OCR 纯垃圾）

深色 UI（如 GitHub Dark、终端、IDE Dark 主题）直接 OCR 会出随机乱码。必须先预处理：

```python
from PIL import Image, ImageOps

img = Image.open("screenshot.png")

# 灰度→反转→阈值二值化→3倍放大
img_bw = ImageOps.invert(img.convert('L'))
img_bw = img_bw.point(lambda x: 255 if x > 128 else 0)
w, h = img_bw.size
img_bw = img_bw.resize((w * 3, h * 3), Image.LANCZOS)
img_bw.save("clean_for_ocr.png")
```

### 3. 运行 OCR

```bash
TESSDATA_PREFIX="$HOME/tessdata" python -c "
import pytesseract
from PIL import Image
pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'
img = Image.open('clean_for_ocr.png')
text = pytesseract.image_to_string(img, lang='chi_sim+eng', config='--psm 6')
print(text)
"
```

### PSM 模式速查

| PSM | 适用场景 |
|-----|---------|
| 3 | 自动检测（默认，最通用） |
| 4 | 单列文本 |
| 6 | **统一文本块**（列表、目录、表格 → 首选） |
| 11 | 稀疏文本（图标+文字混排） |
| 12 | 稀疏+方向检测 |

先试 PSM 6，不行再试 3。

## 陷阱

1. **venv Python 可能没有 pip**：需先 `python -m ensurepip`
2. **Program Files 写权限**：tessdata 不要放 `C:\Program Files\`，用 `TESSDATA_PREFIX` 指向用户目录
3. **curl 空格路径**：Windows 上 curl 的 `-o "C:/Program Files/..."` 会因路径含空格失败，先下载到无空格路径再 move
4. **只装 eng 语言包**：winget 安装的 Tesseract 默认只有 `eng`，中文需手动下载 `chi_sim.traineddata`
5. **不要用系统 Python**：系统 Python 的 PIL 可能被 venv 的损坏版覆盖，始终用 venv Python

## 与浏览器兜底的关系

两个兜底策略独立运行，互不依赖：

- **浏览器兜底**（memory 中有完整决策树）：CDP 失败 → Kimi WebBridge
- **视觉兜底**（本文档）：vision_analyze 失败 → Tesseract OCR

不纠结、不反复折腾一个方案。
