---
name: external-skill-sync
description: "Install and sync skills from external GitHub repos into Hermes. Covers tap setup, bulk install via direct copy (CLI timeout workaround), and cron-based auto-update."
version: 1.0.0
author: agent
platforms: [windows, linux, macos]
tags: [skills, tap, github, sync, cron, feishu]
---

# External Skill Sync

Manage skills from third-party GitHub repos (e.g. mattpocock/skills). Covers adding the repo as a tap, installing all skills at once, and keeping them updated via cron.

## Trigger

Use when the user wants to install skills from a GitHub repo, or set up auto-sync for external skill repos.

## Adding a tap

```bash
hermes skills tap add https://github.com/<owner>/<repo>
```

Verify: `hermes skills tap list`

## Bulk install — direct copy method

When `hermes skills install <URL>` times out or hits GitHub rate limits, bypass it by cloning the repo and copying skill directories directly:

```bash
# 1. Clone
git clone --depth 1 https://github.com/<owner>/<repo>.git /tmp/<repo>

# 2. Copy each category (skip deprecated)
for cat in engineering productivity misc in-progress personal; do
    cp -r "/tmp/<repo>/skills/$cat" "$HOME/AppData/Local/hermes/skills/mattpocock-$cat"
done
```

On Windows: `$HOME/AppData/Local/hermes/skills/`. On Linux/macOS: `~/.hermes/skills/`.

Each skill is a directory with a `SKILL.md` file. Hermes auto-discovers them. No restart needed — use `/reload-skills` in-session.

## Auto-sync via cron

Create a sync script (`~/.hermes/scripts/sync-<repo>-skills.sh`):

```bash
#!/bin/bash
set -e
REPO_URL="https://github.com/<owner>/<repo>.git"
CLONE_DIR="/tmp/<repo>-update"
SKILLS_DST="$HOME/AppData/Local/hermes/skills"

rm -rf "$CLONE_DIR"
git clone --depth 1 "$REPO_URL" "$CLONE_DIR" 2>/dev/null

for cat in engineering productivity misc in-progress personal; do
    src="$CLONE_DIR/skills/$cat"
    dst="$SKILLS_DST/<prefix>-$cat"
    if [ -d "$src" ]; then
        rm -rf "$dst"
        cp -r "$src" "$dst"
        echo "Synced <prefix>-$cat: $(find "$dst" -name SKILL.md | wc -l) skills"
    fi
done

rm -rf "$CLONE_DIR"
echo "Sync complete."
```

Then create a cron job with `no_agent=true` + `script=<path>`:

```bash
hermes cron create "0 9 * * *" --name "Sync <repo> skills" --script scripts/sync-<repo>-skills.sh --no-agent
```

To also deliver to Feishu: use `cronjob(action='update', deliver='origin,feishu', job_id='...')`. Bare `feishu` routes to home channel (set via `/sethome`).

## Pitfalls

- **`hermes skills install` timeout**: Network issues or GitHub rate limits. Fall back to direct copy method above.
- **GITHUB_TOKEN**: If using `hermes skills install`, set `GITHUB_TOKEN` in `.env` to raise API limit from 60 to 5000/hr.
- **`/reload-skills`**: After direct copy, run in-session to pick up new skills without restart.
- **Protected skills**: Bundled and hub-installed skills cannot be edited — only local/external ones.
