---
name: feishu-gateway-setup
description: "Configure Feishu (飞书) as a messaging platform in Hermes gateway — lark-cli installation, identity binding, auth, display formatting, and autonomous reply settings."
version: 1.0.0
tags: [feishu, lark, gateway, setup, display, messaging]
---

# Feishu Gateway Setup for Hermes

Complete workflow for setting up Feishu (飞书) as a messaging platform in Hermes gateway with clean, concise message formatting.

## Prerequisites

- Feishu app with Bot capability enabled (App ID + App Secret from https://open.feishu.cn)
- Hermes installed and running

## Step 1 — Install lark-cli and Skills

```bash
npm install -g @larksuite/cli
npx -y skills add "https://open.feishu.cn" --skill -y
```

This installs 27 lark-* skills covering doc, im, calendar, drive, base, sheets, slides, task, etc.

## Step 2 — Ask Identity

Present the user with two options:
- **以机器人身份** (bot-only) — robot identity, suitable for group chats and shared docs
- **以用户身份** (user-default) — user identity, requires OAuth authorization

Include this warning for user-default:
> **⚠️ 如果你选「以用户身份」：请勿将此机器人分享给他人或拉入群聊中使用 —— 它能访问你的个人飞书数据。**

## Step 3 — Configure .env

Add to `~/.hermes/.env`:
```
FEISHU_APP_ID=<app_id>
FEISHU_APP_SECRET=<app_secret>
FEISHU_CONNECTION_MODE=websocket
FEISHU_GROUP_POLICY=open
```

Note: `FEISHU_GROUP_POLICY=open` is REQUIRED for group messages to work. The feishu adapter reads this from env vars, NOT from config.yaml. Without it, all group messages are silently rejected.
The secret redaction feature may obscure displayed values — use `wc -c` to verify correct length instead of reading the value.

## Step 4 — Bind Identity

```bash
lark-cli config bind --identity <bot-only|user-default>
```

If multi-account error: show candidates from `error.hint`, let user pick, then:
```bash
lark-cli config bind --identity <IDENTITY> --app-id <chosen_app_id>
```

## Step 5 — Auth Login (user-default only)

Skip for bot-only.

First call — get auth URL:
```bash
lark-cli auth login --recommend --no-wait
```
Extract `verification_url` from JSON output. Send to user as markdown autolink: `<https://...>`.
**Never** open the URL yourself (sandbox browser can't complete auth).
Save `device_code` for next step.

After user confirms authorization:
```bash
lark-cli auth login --device-code <device_code>
```

## Step 6 — Verify

```bash
lark-cli auth status
```

Check: `identity` matches, `tokenStatus` is `valid` or `needs_refresh` (not `expired`).

## Step 7 — Enable Gateway Platform

```bash
hermes config set platforms.feishu.enabled true
pip install websockets   # required for websocket mode
```

## Step 8 — Clean Display Format (CRITICAL)

**The user prefers clean, OpenClaw-like responses — no tool progress, no reasoning, no footer.**

```bash
hermes config set display.platforms.feishu.tool_progress false
hermes config set display.platforms.feishu.interim_assistant_messages false
hermes config set display.platforms.feishu.show_reasoning false
hermes config set display.platforms.feishu.require_mention true
hermes config set display.platforms.feishu.system_prompt "始终使用中文回复。简洁直接，不要冗长。"
```

Runtime footer is global; disable it:
```bash
hermes config set display.runtime_footer.enabled false
```

## Step 9 — Autonomous Reply in Specific Groups

**CRITICAL**: `free_response_channels` does NOT work for the Feishu platform. Use `group_rules` instead. Additionally, `group_rules` is NOT bridged to the adapter by default — a source-code fix is required.

### 9a — Bridge `group_rules` in gateway/config.py

The feishu adapter reads per-group rules from `extra.get("group_rules")`, but the config bridge does not forward `group_rules`. Add this to `~/.hermes/hermes-agent/gateway/config.py`, after the `group_user_allowed_commands` bridge (around line 975):

```python
if "group_rules" in platform_cfg:
    bridged["group_rules"] = platform_cfg["group_rules"]
```

Without this fix, `hermes config set platforms.feishu.group_rules.oc_XXX.require_mention false` has NO effect — the adapter never sees the setting and always falls back to the global `require_mention`.

### 9b — Set per-group rules

For groups that should get free responses (no @mention needed):

```bash
hermes config set platforms.feishu.group_rules.oc_CHAT_ID.require_mention false
hermes config set platforms.feishu.require_mention true    # other groups still need @
```

For per-channel prompts:
```bash
hermes config set platforms.feishu.channel_prompts.oc_CHAT_ID "始终使用中文回复，简洁直接。"
```

### Why `free_response_channels` doesn't work on Feishu

The Feishu platform adapter reads its per-group rules from `extra.get("group_rules")`, not from `free_response_channels`. The `free_response_channels` value gets bridged to the platform config but is never processed into group rules by the feishu adapter. This is different from Discord/Slack where `free_response_channels` is explicitly handled.

## Step 10 — Markdown Rendering

All messages are sent as `post` type (markdown-capable) — no exceptions. The table downgrade (`text` fallback) was removed. See `references/markdown-rendering-fix.md` for the code change and rationale.

### Verified working (tested 2026-06-24)

| Feature | Status |
|---------|--------|
| Bold, italic, strikethrough | ✅ |
| Links (inline + in tables) | ✅ |
| Headings, lists, blockquotes | ✅ |
| Tables (3+ columns, links in cells) | ✅ |
| Code blocks (fenced, with language) | ✅ |
| Inline code | ✅ |
| Multi-paragraph messages | ✅ |
| Columns / multi-column layout | ❌ (need card messages) |
| Buttons / interactive elements | ❌ (need card messages) |

### Strategy

- **Normal messages**: post+md — covers all standard Markdown
- **Interactive needs** (buttons, multi-column): fall back to Feishu card messages
- Transition trigger: auto-detect when post+md can't express the required component

## Step 11 — Set Home Channel & Restart

In the Feishu DM/group, send `/sethome` to set the home channel. Then:

```bash
hermes gateway restart
```

Wait ~10s, verify connection:
```bash
# Use hermes config path to find logs portably (avoids ~/.hermes/logs which doesn't exist on Windows GUI installs)
LOG_DIR="$(dirname "$(hermes config path)")/logs"
grep "feishu connected" "$LOG_DIR/gateway.log" | tail -1
```

## Pitfalls

- **⚠️ FEISHU_GROUP_POLICY IS AN ENV VAR, NOT CONFIG**: The feishu adapter reads `FEISHU_GROUP_POLICY` from environment variables (default: `"allowlist"`) at line 1527 of `feishu.py`, NOT from `platforms.feishu.group_policy` in config.yaml. If this env var is not set to `"open"`, ALL group messages are silently rejected with the rejection reason `"group_policy_rejected"`. This was the root cause of "群里不回消息" after all other settings were correct. Fix: `echo "FEISHU_GROUP_POLICY=open" >> ~/.hermes/.env` then restart gateway. Even if `platforms.feishu.group_policy: open` is in config.yaml, the code ignores it.
- **config.yaml NOT .env**: `hermes config set` writes to config.yaml. For env vars (FEISHU_APP_ID, FEISHU_APP_SECRET, FEISHU_GROUP_POLICY), manually write to .env via terminal.
- **Secret redaction**: The security.redact_secrets feature obscures displayed secret values. Use character count (`wc -c`) to verify correctness instead of reading values.
- **Gateway restart timing**: `hermes gateway restart` may report "no process detected after 6s" — this is often a false alarm; check logs for actual connection.
- **WS disconnected after restart**: The gateway cleanly disconnects and reconnects; the old session in Feishu may show "disconnected" briefly. Wait 10-15s.
- **`final_response_markdown` is CLI-only**: The `display.final_response_markdown` config setting (`render` / `strip` / `raw`) only affects the CLI/TUI terminal output, NOT the gateway. Changing it will have zero effect on Feishu message formatting. If Feishu messages aren't rendering Markdown, the issue is in the Feishu adapter's `_build_outbound_payload`, not this config setting.
- **Config changes need restart**: Any platform or display config changes require `hermes gateway restart` to take effect.
- **`free_response_channels` doesn't work on Feishu**: The feishu adapter reads per-group rules from `platforms.feishu.group_rules`, NOT from `free_response_channels`. Use `hermes config set platforms.feishu.group_rules.<chat_id>.require_mention false` instead. This was discovered via source-code inspection of `feishu.py:_admit()` and `_require_mention_for()` — they use `self._group_rules` (populated from `extra.get("group_rules")`), never from `free_response_channels`.
- **`group_rules` not bridged to adapter**: Even after setting `platforms.feishu.group_rules` in config.yaml, the group rules are NOT forwarded to the feishu adapter by default. The bridge function in `gateway/config.py` only forwards `group_policy`, `free_response_channels`, `channel_prompts`, etc. — but NOT `group_rules`. Add `if "group_rules" in platform_cfg: bridged["group_rules"] = platform_cfg["group_rules"]` to the bridge function (after the `group_user_allowed_commands` block, ~line 975). Without this, per-group `require_mention: false` settings are silently ignored.
- **Feishu sessions hidden from Desktop sidebar**: The Desktop GUI's session list in `cli.py:_list_recent_sessions` hardcodes `source="cli"` and `include_all_sources=False`, which hides all gateway-originated sessions (including feishu) from the sidebar and `/sessions` slash command. Fix: change to `include_all_sources=True` and remove the `source="cli"` filter. After this fix, `/sessions` shows all sessions including feishu ones. The Desktop sidebar's "Messaging" section (fed by `refreshMessagingSessions()` in `desktop-controller.tsx`) already includes feishu but in a separate collapsed section — users may need to expand it.
- **Audio sending via lark-cli**: The `--audio` flag rejects WAV files with "file type
  does not match the type of message being sent" (code 230055). Use `--file` instead
  to send audio as a downloadable file attachment. The recipient can click to play.
- **Bot can't DM users**: If the bot hasn't been added to a user's P2P chat,
  sending via `--as bot --chat-id <p2p_chat_id>` fails with "Bot/User can NOT be
  out of the chat" (code 230002). The user must initiate the DM first, or use
  `--as user` (requires `im:message.send_as_user` scope).: On Windows desktop GUI installs, gateway logs live at `%LOCALAPPDATA%/hermes/logs/gateway.log`, NOT at `~/.hermes/logs/gateway.log`. The `~/.hermes/` directory may contain only a minimal stub `config.yaml` with no logs at all. Always use `hermes config show` to find the actual config path, then derive logs from `<config_dir>/logs/`. The portable verify command in Step 11 handles this automatically.
