---
name: knowledge-base
description: 知识库完整维护系统——目录架构、笔记创建、frontmatter规范、MOC同步、Git版本控制、持续维护触发规则。
platforms: [linux, macos, windows]
version: 2.0.0
---

# 知识库维护

> 触发词：知识库、KnowledgeBase、vault、笔记、MOC、知识管理、Obsidian

不只是文件读写——这是知识库的完整维护系统。涵盖架构设计、笔记生命周期（创建→链接→提交）、MOC 索引维护、两级巡检，以及持续更新的触发规则。

## 目录架构

```
~/Documents/KnowledgeBase/              ← Git 仓库 (branchingjade/knowledge-base)
├── .git/
├── .gitignore
├── README.md
├── CHANGELOG.md
├── Obsidian Vault/                     ← Obsidian 唯一仓库
│   ├── .obsidian/                      ← Obsidian 配置
│   ├── MOC.md                          ← 总索引（唯一入口）
│   ├── _hermes/                        ← 🛠 Hermes 运维与方法（权重最高）
│   │   ├── 技能来源.md
│   │   ├── 备份迁移.md
│   │   ├── 浏览器双轨策略.md
│   │   └── Memory与Skill划分原则.md
│   ├── 犬子无双/                       ← 🎨 项目产出
│   │   └── assets/                     ← 截图等附件
│   ├── 技术/                           ← 🔬 技术参考
│   │   └── 超分/
│   │       ├── 图像超分指南.md
│   │       ├── 视频超分工具对比.md
│   │       └── SeedVR2 fp8伪影排查.md
│   └── 日志/                           ← 📋 会话记录（权重最低）
│       └── 2026-06-24~25.md
└── _hermes/                            ← (仓库根) 飞书推送配置
└── 技术/                               ← (仓库根) 知识库架构文档
```

**层级权重**：`_hermes/`（运维） > `项目/`（产出） > `技术/`（参考） > `日志/`（存档）。新增笔记按此归位。

- **KnowledgeBase 根目录** = Git 仓库
- **Obsidian Vault 子目录** = Obsidian 打开的唯一仓库
- 笔记全放在 `Obsidian Vault/` 下，Git 版本控制在 KnowledgeBase 层
- 不要在 KnowledgeBase 根目录直接放 `.obsidian/`（会造成伪双仓库）
- 根目录只保留 `README.md`、`CHANGELOG.md` 和 infra 配置目录，不放笔记

## 笔记创建规范

### Frontmatter 模板

每篇笔记必须包含以下 frontmatter：

```yaml
---
tags: [分类标签1, 分类标签2]
date: YYYY-MM-DD
related: [[关联笔记1]] · [[关联笔记2]] · [[Hermes踩坑记录]]  # 可选
---
```

- `tags`：至少 2 个标签，首标签为父目录/主题
- `date`：创建日期
- `related`：用 `[[wikilink]]` 链接关联笔记，多个用 ` · ` 分隔

### 命名规范

- 中文优先，简洁直白
- 目录名用英文下划线（`_hermes/`）
- 文件名不含 `:` `|` `/` 等特殊字符

### 创建流程

1. 判断归属目录（按权重）
2. `write_file` 创建笔记，含完整 frontmatter + 内容
3. 检查 MOC.md 是否需要新增链接
4. `git add -A && git commit -m "..." && git push`

### MOC 维护

- 新增笔记后，检查 MOC.md 对应分类下是否有该笔记的链接
- 如无，在 MOC.md 对应小节追加 `- [[新笔记名]] — 一句话描述`
- 删除笔记时同步移除 MOC 链接
- MOC.md 自身保持精简，不重复笔记内容

### 交叉引用深度标准

**禁止标签式链接**（`详见 [[xxx]]`）。每条交叉引用必须是叙事段落，包含三要素：

1. **场景**：在什么任务/阶段踩的或发现的
2. **因果**：为什么会在这里发生、导致了什么
3. **教训**：从中学到什么

**双向性**：A 链到 B 的同时，B 也必须链回 A。踩坑记录 → 项目笔记 → 踩坑记录，形成闭环。

**精确性**：用 `[[笔记名#章节锚点|显示文本]]` 链到具体位置，不是笼统链整篇。

**独立可读**：不跳转也能理解上下文。读者只看当前笔记就能通顺读完，需要深入时再点链接。

### 踩坑记录规范

每条坑必须含 `> 发生在 [[项目笔记]]` 叙事段——不可只有 wikilink，要附一段上下文：什么项目、当时在做什么、为什么会踩。坑与坑之间有关联时（如"同一晚连踩两坑"），明确写出姊妹坑链接。

## 笔记写入时机

**阶段性完成后写，不即时写。** 一项任务/功能/排查做完了、验证过了、结论清晰了，再落笔记。半成品不写。

## 维护分级

### 每日小维护

| 检查项 | 操作 |
|--------|------|
| Hermes 记忆同步 | `/bin/cp` 同步 MEMORY.md + USER.md 到 `_hermes/memory/`（Windows MSYS 必须用 `/bin/cp` 绕过 `cp -i` 别名） |
| 未提交 git 变更 | `git status --short`，有则 commit + push |
| 悬空 `[[wikilinks]]` | 遍历 frontmatter `related`，确认目标文件存在 |
| 新增文件归位 | 有 `.md` 不在正确目录 → 移动 |

> Cron 自动化执行细节见 `references/cron-daily-maintenance.md`

### 每周大维护（附加每日项）

| 检查项 | 操作 |
|--------|------|
| 过时内容 | 比对当前配置/版本，标记或更新 |
| MOC 完整性 | 遍历所有笔记，确认 MOC.md 有对应链接 |
| 目录健康 | 检查是否有空目录、命名不一致、根目录进入笔记 |
| 图谱孤岛 | 无 `[[wikilinks]]` 入/出的笔记，补链或归档 |

## 持续维护触发

以下场景在**阶段完成后**触发写笔记：

| 触发场景 | 归属目录 | 示例 |
|---------|---------|------|
| 技术决策/方案选型 | `技术/` | 工具对比、架构选型 |
| 排查/故障分析 | `技术/` | fp8 伪影、性能瓶颈 |
| 配置变更/迁移 | `_hermes/` | 备份切换、网关迁移 |
| 方法论/工作流 | `_hermes/` | Memory/Skill 划分 |
| 踩坑/教训 | `技术/` 或 `_hermes/` | MSYS路径、编码、API边界 |

**禁止**：A. 过程半成品写笔记 B. 做完不留笔记。

### Push 规则

KnowledgeBase 内任何文件变动后：先 `git status --short` 展示变更清单 → 再 `git add -A && git commit -m "..." && git push`。少量单文件提交不需询问，批量或多文件时用 `clarify` 确认。

## Skill 自维护

本 skill 是知识库规范的**唯一权威源**。以下场景必须同步更新本 skill + GitHub 副本：

| 场景 | 更新内容 |
|------|---------|
| 笔记规范变更 | frontmatter 模板、命名规则、交叉引用标准 |
| 目录架构调整 | 架构图、权重说明 |
| 维护流程变化 | 每日/每周巡检项、触发表 |
| 新增笔记类型 | 触发表追加行 |

**GitHub 副本同步**：修改后执行 `cp ~/AppData/Local/hermes/skills/note-taking/knowledge-base/SKILL.md ~/Documents/KnowledgeBase/_hermes/knowledge-base-skill.md && git commit push`。

默认路径：`~/Documents/KnowledgeBase/Obsidian Vault`。可用 `OBSIDIAN_VAULT_PATH` 环境变量覆盖。路径含空格，优先用 `read_file`/`write_file`/`search_files` 等文件工具而非 shell 命令。

## 常见坑

### MSYS `cp -i` 别名导致静默失败

Windows git-bash/MSYS 环境下 `cp` 默认 alias 为 `cp -i`（交互式确认）。在 cron 或非 TTY 模式下，`cp -i` 因无法读取用户输入而**静默跳过覆盖**（不报错、不写入、exit code 0）。

**修复**：使用 `/bin/cp` 绕过别名，或用 `\cp`：

```bash
# ❌ 静默失败
cp source target

# ✅ 强制覆盖
/bin/cp source target
```

涉及场景：记忆同步（`cp ~/AppData/Local/hermes/memories/*.md` → vault）、GitHub 副本同步。

### 悬空 Wikilink 检测误报

自动化检测 `[[wikilink]]` 时常见误报来源：

1. **语法示例文本**：笔记正文中的 `[[...]]` 是展示 wikilink 语法，不是真实链接
2. **空 wikilink**：`[[]]` 残留或 grep 提取 artifact
3. **路径分隔符**：`[[子目录/笔记名]]` 提取出的 link 名含 `/`，对比 `.md` 文件名时需取最后一段（`${link##*/}`）或直接用文件路径匹配

推荐方法：`comm -23 <(grep -roh '\[\[[^]]*\]\]' ... | sed ... | sort -u) <(find ... -name '*.md' | sed ... | sort -u)`，然后人工排查 `...` 和空行等误报。

## Read a note

Use `read_file` with the resolved absolute path to the note. Prefer this over `cat` because it provides line numbers and pagination.

## List notes

Use `search_files` with `target: "files"` and the resolved vault path. Prefer this over `find` or `ls`.

- To list all markdown notes, use `pattern: "*.md"` under the vault path.
- To list a subfolder, search under that subfolder's absolute path.

## Search

Use `search_files` for both filename and content searches. Prefer this over `grep`, `find`, or `ls`.

- For filenames, use `search_files` with `target: "files"` and a filename `pattern`.
- For note contents, use `search_files` with `target: "content"`, the content regex as `pattern`, and `file_glob: "*.md"` when you want to restrict matches to markdown notes.

## Create a note

Use `write_file` with the resolved absolute path and the full markdown content. Prefer this over shell heredocs or `echo` because it avoids shell quoting issues and returns structured results.

## Append to a note

Prefer a native file-tool workflow when it is not awkward:

- Read the target note with `read_file`.
- Use `patch` for an anchored append when there is stable context, such as adding a section after an existing heading or appending before a known trailing block.
- Use `write_file` when rewriting the whole note is clearer than constructing a fragile patch.

For an anchored append with `patch`, replace the anchor with the anchor plus the new content.

For a simple append with no stable context, `terminal` is acceptable if it is the clearest safe option.

## Targeted edits

Use `patch` for focused note changes when the current content gives you stable context. Prefer this over shell text rewriting.

### Wikilinks 交叉引用

- `[[笔记名]]` — 基础链接
- `[[笔记名#章节标题|显示文本]]` — 精确锚点，直指目标章节
- 踩坑记录用 `> 发生在 [[项目笔记]]：具体场景描述` 格式做反向叙事链接

**深度标准**：交叉引用必须含上下文叙事，两份文档各读各的通顺，交叉时能顺藤摸瓜。

| ❌ 标签式 | ✅ 叙事式 |
|----------|---------|
| `详见 [[踩坑记录]]` | 讲清楚**怎么踩的、为什么这里会踩、教训是什么** → `详见 [[踩坑记录#具体章节]]` |

## Git integration

When the vault lives inside a Git repo (e.g. as a subdirectory like `repo/Obsidian Vault/`), `.gitignore` must handle `.obsidian/` directories correctly.

### .gitignore pattern for nested vaults

```
# Track core config, ignore everything else
**/.obsidian/*
!**/.obsidian/app.json
!**/.obsidian/appearance.json
!**/.obsidian/core-plugins.json
!**/.obsidian/community-plugins.json
**/.obsidian/workspace*
```

**Why `**/` prefix is required:** `.obsidian/*` (without `**/`) only matches `.obsidian/` at the repo root — it will NOT match `Subfolder/.obsidian/`. The `**/` glob matches at any depth, so `**/.obsidian/*` correctly ignores `.obsidian/` directories anywhere in the repo tree.

**Why `/*` not `/`:** `.obsidian/` (trailing slash, directory-only match) prevents re-inclusion of files inside it — Git refuses to un-ignore files whose parent directory is excluded. Use `.obsidian/*` (match all contents) so that negation patterns (`!**/.obsidian/app.json`) can re-include specific files.

Verify with `git check-ignore`:
- Core config (app.json, etc.) should NOT be ignored → tracked
- workspace.json and everything else inside `.obsidian/` should be ignored
