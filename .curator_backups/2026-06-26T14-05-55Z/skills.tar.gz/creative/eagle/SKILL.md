---
name: eagle
description: Eagle 本地 API 资产管理——浏览文件夹、搜索素材、管理标签。Eagle 是一款设计/素材管理工具，通过 localhost:41595 提供 REST API。
---

# Eagle API 资产管理

## 触发条件
用户提到 Eagle、素材库、在 Eagle 中查找/管理文件、Eagle 标签/文件夹操作。

## API 基础

- **端口**：`localhost:41595`
- **认证**：无需 token（token 在 `/api/application/info` 响应中可见，但所有端点无需认证即可调用）

### 核心端点

```bash
# 获取应用信息（版本、平台、偏好设置）
curl -s http://localhost:41595/api/application/info

# 获取完整文件夹树（递归，包含 children）
curl -s http://localhost:41595/api/folder/list

# 列出文件夹内的项目
curl -s "http://localhost:41595/api/item/list?folders=<FOLDER_ID>"

# 按关键词搜索
curl -s "http://localhost:41595/api/item/list?keyword=<关键词>"

# 按扩展名筛选（限制 50 条）
curl -s "http://localhost:41595/api/item/list?ext=mp3&limit=50"
```

### 响应格式

```json
{
  "status": "success",
  "data": [
    {
      "id": "MQF4WH0AXL5YA",
      "name": "音乐",
      "children": [...],       // folder/list 才有
      "ext": "wav",
      "tags": [],
      "url": "",
      "folders": ["MQF4WH0AXL5YA"]
    }
  ]
}
```

## 关键陷阱

### 1. folder/list 返回完整树，响应巨大——禁止用 execute_code
`/api/folder/list` 一次性返回所有文件夹的递归树，没有分页或按 parentId 过滤。用户的 Eagle 库树可能超过 100k 字符。

**🚫 绝对禁止**：用 `execute_code` 调用 Eagle API。`execute_code` 内的 Python 进程会因巨型 JSON 卡死，导致整个会话变成 `session busy` 永久阻塞。

**✅ 唯一正确做法**：终端管道 `curl | python3 -c`，流式处理，不进 execute_code。

```bash
curl -s http://localhost:41595/api/folder/list | python3 -c "
import sys,json
d=json.load(sys.stdin)
# 递归查找
def find(data, name):
    for f in data:
        if name in f['name']:
            print(f\"{f['name']} [{f['id']}]\")
        if 'children' in f:
            find(f['children'], name)
find(d.get('data',[]), '犬子无双')
"
```

**已确认的文件夹结构**（无需反复查询）：
- 项目/《犬子无双》 → MPUZUBBX5VLF8
- 项目/《犬子无双》/素材/音乐 → MQF4WH0AXL5YA
- 项目/《犬子无双》/素材/音效 → MQQCUD4KA1DRV

### 2. 文件夹 ID 直接用于 item/list
用 `folders=<ID>` 参数直接定位文件夹，不需要完整路径。ID 从 folder/list 的 `id` 字段获取。

### 3. keyword 搜索是模糊匹配
搜索文件名、标签、注释等字段。中文搜索可能不精确——如果搜不到，改用文件夹 ID 定位。

### 4. parentId 参数不可靠
`/api/folder/list?parentId=<ID>` 可能返回根目录而非指定子目录。不要依赖它——用 `/api/folder/list`（无参）获取完整树后在 Python 中本地过滤。

### 5. 外部平台元数据可能无法自动抓取
版权音乐平台（如曲多多/haifanwu.com）通常有 WAF + SPA 保护：
- **API 直调**：被 WAF 拦截
- **CDP 浏览器**：已成功验证——用 `browser_console` 调用 Nuxt router 导航到详情页后提取数据（见 `references/quduoduo.md`）
- **大批量**：用 `delegate_task` 并行提取（每 agent 4-8 首）

## 写入操作（更新元数据）

### 更新文件标签/注释/URL

```bash
curl -X POST "http://localhost:41595/api/item/update" \
  -H "Content-Type: application/json" \
  -d '{"id":"<ITEM_ID>","tags":["版权音乐","曲多多"],"annotation":"曲目ID: 4776764\n来源: haifanwu.com","url":"https://haifanwu.com"}'
```

可写字段：`tags`（数组）、`annotation`（纯文本）、`url`（链接）。

无批处理端点，逐条 POST。

**⚠️ 禁止用 terminal + curl 传中文**：shell 管道的转义会破坏 UTF-8 编码，导致 Eagle 中所有中文变成乱码。批量写入时用 Python `urllib.request` 直连 API（在 `execute_code` 中），不使用 `terminal()` 中转。

### 从文件名提取元数据

Eagle 中版权音乐常见命名格式：
```
曲多多_<ID>_<英文名>.wav    # 曲多多/haifanwu.com
```

可从文件名提取 ID 和名称直接写入标签/注释，无需爬平台（参考 references/quduoduo.md）。

## 典型工作流

### 查找项目素材
1. 用 folder/list 获取完整树
2. 在 Python 中过滤目标文件夹名
3. 用文件夹 ID 调用 item/list

### 解读用户路径描述
用户说"项目-《犬子无双》音乐"意味着 Eagle 路径：`项目 → 《犬子无双》 → 素材 → 音乐`

### 批量查看文件
用 `curl ... | python3 -c` 管道，提取 name、ext、tags、url 字段即可。不要打印整个 JSON 对象。

### 同步外部平台元数据到 Eagle
1. 用 item/list 列出目标文件
2. 从文件名提取 ID → 尝试匹配外部平台
3. 逐条 POST 更新 tags/annotation/url
4. **先讲思路，确认后再执行**——平台可能无法自动抓取（见 references/quduoduo.md）
