---
name: mimo-audio-analyzer
description: "Analyze audio files using MiMo v2.5 audio understanding via base64 API call."
version: 1.0.0
author: agent
tags: [mimo, audio, analysis, multimodal, xiaomi]
platforms: [windows, linux, macos]
---

# MiMo Audio Analyzer

Analyze local audio files using MiMo v2.5's audio understanding capability. Works by base64-encoding the audio and sending it directly to the MiMo API via `input_audio` content type.

## Prerequisites

- `XIAOMI_API_KEY` set in `~/.hermes/.env`
- Python 3 with stdlib only (no extra deps)

## Usage

```bash
source ~/.hermes/.env
python3 scripts/mimo_audio.py <audio_file> [question]
```

## Verified Test Results

Tested with a 25.8 MB WAV (153s Mandarin pop/rock song):
- Base64 size: 34.4 MB (under 50 MB limit) ✅
- Token usage: prompt=981 (audio=958), completion=413 (reasoning=357)
- Audio tokens validated: 958 ≈ 153s × 6.25 ✅
- Output: correctly identified genre, instruments, vocals, mood

## API Details

- Endpoint: `POST https://api.xiaomimimo.com/v1/chat/completions`
- Auth header: `api-key: *** NOT `Authorization: *** - Content type in messages: `{type: "input_audio", input_audio: {data: "data:{mime};base64,{b64}"}}`
- Model: `mimo-v2.5`
- Supported MIME types: `audio/wav`, `audio/mpeg`, `audio/flac`, `audio/mp4`, `audio/ogg`
- Limits: base64 string ≤ 50 MB, URL ≤ 100 MB
- Token calculation: ≈ audio_duration_seconds × 6.25

## Pitfalls

- **Reasoning tokens**: mimo-v2.5 uses reasoning/thinking tokens that consume `max_completion_tokens` quota. A setting of 1024 will result in EMPTY content output (all tokens eaten by reasoning). Use 4096+ for normal-length outputs. The script defaults to 4096.
- **Base64 bloat**: Raw audio × 1.33 = base64 size. A 38 MB WAV will exceed the 50 MB limit after encoding.
- **Format support**: Only WAV, MP3, FLAC, M4A, OGG. Convert with ffmpeg first.
- **Key sourcing**: On git-bash/WSL, use `source ~/.hermes/.env` (bare `export XIAOMI_API_KEY=*** gets redacted by Hermes).
- **No local file upload**: MiMo only accepts URL or base64 — no direct file upload endpoint.
