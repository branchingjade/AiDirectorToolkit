---
name: hermes-workspace-conventions
description: "Hermes 工作区约定。目录结构、操作流程（计划优先）、会话分支策略规范。用户会纠正不合理的安排。Use when: 新建文件夹、组织文件、决定项目放哪里、需确认执行顺序、问会话分支/worktree/回滚怎么用。"
---

# Hermes 工作区目录约定

## 根目录

所有内容在 `~/Documents/Hermes/` 下，按用途分：

```\n~/Documents/Hermes/\n├── Plugins/             存档 — 浏览器扩展、工具安装包、脚本\n├── Projects/            独立项目 — 有 git repo 的软件项目\n├── 分镜/                创作产出 — 分镜、提示词等创意文档\n├── 分析/                分析报告产出\n├── .hermes/             Hermes 运行时\n└── *.md                 参考文档\n```

> **`.gitignore` 模板**：`references/workspace-gitignore.md` — 覆盖 Hermes 运行时、备份、日志、Blender 缓存等。工作区缺 `.gitignore` 时从此模板复制。

## 分类规则

### Plugins/ — 插件存档

**放什么：** 浏览器扩展、油猴脚本、ComfyUI 节点、TD .tox 等。

**不放什么：** 正在开发中的、有自己 git repo 的项目。

```
Plugins/
└── browsers/extensions/
    └── RH小帮手-v2.2.4/     ← 发行版存档
```

### Projects/ — 独立项目

**判断标准：** 有独立 git repo、有 build/dev 流程、能独立发版 → 放 Projects/。

```
Projects/
└── rh-helper/              ← 开发版 (.git, build.sh, src/)
```

### 根目录 — 参考文档

跨项目参考文档放根目录，如 `版本管理策略.md`。

### 分镜/ — 创作产出

**放什么：** 分镜脚本（`分镜_*.md`）、Seedance/RunningHub 提示词（`优化提示词_*.md`）、海报文案等创意工作直接产出。

**不放什么：** 分析报告（→ `分析/`）、项目代码（→ `Projects/`）、参考知识（→ Obsidian vault）。

### 分析/ — 分析报告

**放什么：** 调研报告、对比评测、技术分析等结构化输出。子目录按项目名组织，MD 引用同目录 `assets/`。

## 操作约定

### 计划优先（大方向）

**架构变更、新增系统/流程、跨模块改动、方案选型——先出方案等用户确认再执行。方案没定下来就禁止执行。**

**⚠️ 选项式回复后的确认门槛**：当你用 clarify 问"思路一还是思路二"或自然语言给出多个方案让用户选时，用户回复"思路一"≠ 给你绿灯动手。必须再追问一句"要动手吗？"等用户明确说"做"/"动手"/"开始"后才能执行。用户只是选了方向，不是给了执行许可。

**反面案例**：用户问"有办法解决吗"→ agent 提了两个思路 → 用户说"思路一" → agent 立即 project_create + write_file + terminal 全套开工 → 用户"停，怎么就自己干起来了"。正确做法：用户说"思路一"后回复"要动手吗？"，等确认。

### 任务后收尾（完成 ≠ 结束）

**执行机制：** 每次建 todo 列表，最后一项固定为「收尾检查：Obsidian/Git/Skill」。随任务追踪，不依赖记忆触发。

任何阶段成果完成后，**必须输出以下清单并逐项处理**。不输出 = 不合格，不等用户提醒：

```
收尾：
- [ ] Obsidian笔记（有值得记录的学习 → 主动提出）
- [ ] Skill同步（方法论/工具用法变了 → 更新对应skill）
- [ ] Git push（KnowledgeBase有变更 → commit+push）
- [ ] 记忆同步（memory.md → vault Hermes运维/memory/）
- [ ] 悬空wikilink检查
```

**反面案例**：处理了 20 首音乐、发现 `__NUXT__` 提取方式、更新了 eagle skill——全程没输出收尾清单，用户问才做。两次。

**扩展：对外展示/审美相关任务同样适用。** GitHub 主页、个人网站、公开 README 等——用户的审美偏好无法预判，回滚成本高（删仓库需要 `delete_repo` scope，比创建麻烦）。操作顺序：①说明可定制的层级 → ②clarify 问方向 → ③出内容预览，确认后再 push。禁止未确认就创建仓库并推送到远程。

以下情况不需要规划，直接做：
- 单文件小改（patch、write_file 单文件）
- 修 bug、数据查询
- 用户给方向性反馈（"太薄弱""不够好""为什么没触发X"）→ 先追问澄清，不要立即执行修补。触发 `grill-me` skill 深度追问后再动手。

批量操作必须先 1 条验证，确认后扩全量。用户说"先做规划"就是字面意思——先给方案，不动手。

## 会话工作流约定

### 分支策略：思路用分支，执行回主线

```
主线（执行 + 回滚保护）
  │
  ├─ /branch → 分支A（纯聊天探索，不碰文件）
  ├─ /branch → 分支B（纯聊天探索，不碰文件）
  │
  └─ 回到主线 → 实际修改文件，翻车了 /rollback
```

- **`/branch`** — 只分叉对话历史，不隔离文件。轻量，适合换思路聊、对比方案。
- **`hermes -w`** — 对话+文件双隔离（自动创建 git worktree），适合并行开发任务。
- **回滚保护** — 全局开启：`hermes config set checkpoints.enabled true`，此后任何项目文件修改前自动快照。

### 开关回滚

全局开启后所有项目生效：
```bash
hermes config set checkpoints.enabled true
```

单个会话开启（不持久化）：
```bash
hermes --checkpoints
```

回滚命令：`/rollback`（列快照）、`/rollback N`（恢复到第 N 个快照）

详见 `references/session-grouping-mechanism.md` — 会话侧边栏分组的三级结构（Project → Repo → Lane）及分裂修复方法。

## Pitfalls

### Cron 投递模式

Windows 上 cron job 的投递陷阱和 LLM 驱动 prompt 设计经验：
`skill_view(name="hermes-workspace-conventions", file_path="references/cron-delivery-patterns.md")`

### 自检→修复闭环

写代码/skill/配置/cron job/记忆后，必须执行自检→修复闭环，**禁止只检不修**：

1. **自检与修复是同一个 todo 项** — 禁止拆成「自检X」+「修复X」两个任务。拆开后修复项永远勾不掉，用户已多次纠正。

2. **自检清单**（按任务类型选适用项）：

| 任务类型 | 检查项 |
|---------|--------|
| Python 脚本 | regex 正确性（`.+` vs `.*`、锚点）、边界条件（空输入/首次运行/API 故障）、副作用（state file、文件覆盖） |
| Skill | 提取方式、串并行推荐、陷阱≥3条、不引用废弃 API、边界用例≥1条、批量替换后同文件内容重复检查 |
| Memory 修改 | 去重检查（无重复条目）、无冲突（与 skill 一致）、指向 skill 的指针正确 |
| Obsidian 笔记 | frontmatter 用 YAML 列表格式（`related`/`tags`）、无无效属性（`name:`/`version:`等 skill 元数据禁入）、wikilink 目标文件存在 |
| 配置/插件 | 默认值合理性、重启/重载要求 |

2. **修复**：自检中标记 ⚠️ 的项**必须立即修复**后才算完成。等用户提醒才修 = 不合格。

3. **确认**：任何写入/修改操作后简短确认——改了什么、无冲突——再进入下一步。不是"操作成功"就过。

**反面案例**：批量 patch 后自检发现 frontmatter 双行残留，未修复就结束会话——用户第二天发现。

### 批量替换后内容重复检查

当对 skill 文件做大段内容替换时（如某节从全量复制改为引用），替换后的新内容可能与该文件已有章节重复。**每次批量替换后必须做交叉 grep**——用新内容的关键词搜索同文件上层，确认没有重复。

**反面案例**：AI导演助手 4.5 节约束去重时，新增的「运镜铁律」与文件已有的 4.2 节「三条铁律」内容完全相同。自检时用 `grep` 交叉比对才发现并移除。如果没做这个检查，同文件内就会有两个章节说完全一样的话。

**检查方法**：
```bash
# 替换后，用新内容的特征关键词搜索文件上层（替换位置之前的部分）
grep -n "新内容关键词" file.md | head -5
# 如果匹配行号分布在两个不同区段 → 重复，修复
```

### Skill 同步铁律

任何约定/标准/流程变更后，必须同步更新对应 skill + GitHub 副本。特别是：
- 笔记规范变更 → `knowledge-base` skill
- 调用策略变更 → 对应工具 skill
- 工作流变更 → `hermes-workspace-conventions`

**反面案例**：交叉引用标准从标签式升级为叙事式后，更新了 3 份笔记但忘记更新 `knowledge-base` skill——用户追问"skill优化了吗"才发现遗漏。自检时"skill已同步"必须作为固定检查项。

---

- **不要** 把独立项目放到 Plugins/（Plugins 是存档，不是开发空间）

### Memory vs Skill 划分原则

知识放 Memory 还是 Skill，按一个判断标准：

> **"不加载 skill 时，需要这条规则才能不做错决定吗？"**

| 需要 → | **Memory**（决策铁律） |
| 不需要 → | **Skill**（操作手册） |

**⚠️ Memory 不可靠**：行为规则放 memory 是脆弱的——memory 是被动文本，agent 不会主动逐条对照。本次会话用户先后要求"不要逐首写独立脚本""先规划再执行""主动做 Obsidian 维护"，全都在 memory 里有对应条目但全部被跳过。**行为规则必须嵌入 skill 的工作流步骤中，靠 skill 加载时注入上下文来触发，不能单靠 memory。**

### Memory 只放

- 出问题时立刻需要的判断规则（"遇到 X 就做 Y"）
- 被纠正过的教训/铁律
- 指向 skill 的指针（末尾加 `→ 详见 xxx skill`）

### Memory 不放

- 版本号、文件路径、命令参数、API 端点
- 代码模板、具体操作步骤
- 会过期的数据（文件大小、job ID）

### Skill 放

- 完整的操作流程和参数说明
- references/ 下的深度参考文档
- 每次用到才需要加载的内容

Memory 清理的系统化方法见 `references/memory-cleanup-methodology.md`。

### SOUL.md / USER.md / MEMORY.md 角色区分

三个身份/持久化文件各司其职，容易混淆。详见 `references/identity-and-memory-files.md`。

### Bilibili API 反爬绕过

B 站 API 对程序化请求有严格风控，Googlebot UA 可绕过：`skill_view(name="hermes-workspace-conventions", file_path="references/bilibili-api-googlebot-bypass.md")`

### 更新外部产品映射的 skill

skill 映射第三方产品（如 kimi-webbridge → Moonshot AI 的 WebBridge 产品）时：
- 产品迭代需要更新 skill → **只用 `patch`，禁止 `edit`/`create` 全量覆盖**
- 全量覆盖会丢失本地补丁（如兜底策略、自定义陷阱等）

## 回复渠道规则

- Hermes TUI 里问 → TUI 回复
- 飞书里问 → 飞书回复  
- cron 自动推送 → 推飞书
- **禁止跨渠道**：用户在 TUI 问不要推到飞书让他们去看，反之亦然
- **不要** 在 Hermes 工作区外创建同级目录（如 `~/Documents/dev/`）
- 可以先放 subdir 再迁移，但最终位置按此约定
- **重命名项目必须同步改目录名**：用户要求更直观的项目名时，不能只改 Hermes 内部的 project name，必须把磁盘上的目录也一起 rename，再重建 project 指向新路径。只改名字不改目录 = 用户会纠正。

### Obsidian Vault 维护

知识库维护系统：`skill_view(name="knowledge-base")` — 目录架构、笔记创建规范、交叉引用标准、两级巡检。
- **桌面端项目不会自动发现**：文件系统里有目录不代表侧边栏会显示。Hermes 桌面端项目需要通过 `project_create(name, path)` 显式注册才会出现在侧边栏。用户说"项目中看不到"时要主动帮他们注册。
- **项目根目录如有嵌套会导致会话分组杂音**：当项目根（如 `Documents/Hermes`）包含子目录同时又是另一个独立项目（如 `Projects/rh-helper`）时，会话列表可能出现重复分组。桌面端侧边栏的会话分组按分支/源标签划分，与 git 分支无关。会话数据库在 `AppData\\Local\\hermes\\state.db`（`~/.hermes/state.db` 为空文件，`AppData\\Roaming\\Hermes\\DIPS` 是浏览器弹窗数据库，都不是会话库）。
- **会话元数据不一致导致侧边栏分裂**：同一项目下的会话如果 `git_branch` 或 `git_repo_root` 字段不一致，会被分到不同的 lane（如 "master" / "main" / "Hermes" 三个分组）。症状：侧边栏同一项目下出现多个"分支"分组。根因：`project_tree.py` 的 `_place()` 按 `git_branch` + `git_repo_root` 分配 lane——有值的会话创建独立命名 lane，无值的会话走 `_place_by_heuristic()` 用 cwd basename 作为 lane 名。修复：`UPDATE sessions SET git_branch=NULL, git_repo_root=NULL WHERE cwd='项目路径' AND (git_branch IS NOT NULL OR git_repo_root IS NOT NULL)`——注意只清本项目下的，别清其他项目的。改完需重启 GUI 刷新侧边栏。
