---
name: hermes-maintenance
description: "Keep Hermes Agent running: diagnose ImportError after updates, restart gateway, check process state."
version: 1.0.0
platforms: [windows, linux, macos]
---

# Hermes Maintenance

Operational patterns for keeping Hermes Agent healthy — updating, restarting components, and diagnosing common post-update failures.

## Trigger

- Hermes throws `ImportError` or `AttributeError` for things that clearly exist in the source on disk
- After running `hermes update` or `git pull` in the hermes-agent repo
- Gateway responses are stale or erroring while the desktop app works fine

## Diagnostic: stale process after code update

**Symptom:** `ImportError: cannot import name 'X' from 'agent.module'` — the constant/function exists in the source file on disk but the running process can't find it.

**Root cause:** The gateway is a persistent background process. It loads Python modules once at startup. When source code is updated on disk (via `hermes update`, `git pull`, or desktop auto-update), the running gateway still holds the pre-update bytecode in memory. Restarting the desktop app does NOT restart the gateway.

**Verify:** Check if the constant exists in the source and can be imported from a fresh Python:

```bash
cd ~/AppData/Local/hermes/hermes-agent  # Windows
./venv/Scripts/python.exe -c "from agent.prompt_builder import PARALLEL_TOOL_CALL_GUIDANCE; print('OK')"
```

If that succeeds but Hermes still fails → stale gateway process.

**Fix:**

```bash
hermes gateway restart
```

If restart fails (e.g., Scheduled Task doesn't recover), try stop then start:

```bash
hermes gateway stop
hermes gateway start
```

Verify:

```bash
hermes gateway status
# Should show: ✓ Gateway process running (PID: N)
```

Then check logs for absence of the error:

```bash
grep "ImportError" ~/AppData/Local/hermes/logs/gateway.log | tail -5
```

## Gateway lifecycle

The gateway runs as a Scheduled Task (`Hermes_Gateway`) on Windows, or a systemd user service on Linux/macOS. It persists across desktop app restarts.

| Action | Command |
|--------|---------|
| Status | `hermes gateway status` |
| Start | `hermes gateway start` |
| Stop | `hermes gateway stop` |
| Restart | `hermes gateway restart` |
| Logs | `tail -f ~/AppData/Local/hermes/logs/gateway.log` |

## Browser toolset: dependency on agent-browser

The `browser` toolset (`browser_navigate`, `browser_click`, etc.) is powered by the `agent-browser` CLI (https://github.com/vercel-labs/agent-browser), installed globally via npm.

**Symptom:** `[WinError 2] 系统找不到指定的文件。` or `agent-browser: command not found` when using any browser tool.

**Root cause:** `agent-browser` is not installed, or was uninstalled. Hermes's `tools/browser_tool.py` calls `agent-browser` as a subprocess — it's not bundled with Hermes.

**Verify:**

```bash
which agent-browser
npm ls -g agent-browser
```

**Fix:**

```bash
npm install -g agent-browser
```

After install, a `/reset` (new session) may be needed for the tool to register the binary path.

**Architecture note:** `agent-browser` manages Chromium download and lifecycle. The Hermes browser tools are a Python wrapper around its CLI. Cloud backends (Browserbase, Browser Use) bypass `agent-browser` but require paid API keys (see `hermes tools` → browser plugins).

## Browser: Windows `--session` hang + CDP workaround

**Symptom:** All Hermes browser tools (`browser_navigate`, `browser_snapshot`, etc.) hang indefinitely on Windows. The agent session freezes until timeout.

**Root cause:** Hermes's `browser_tool.py` calls `agent-browser` with `--session <name>` for local mode. `agent-browser --session` spawns a daemon process that uses Unix-domain-socket IPC — this hangs on Windows (observed in every version through 0.30.1). `agent-browser` standalone (without `--session`) and `agent-browser --cdp <port>` both work fine.

**Verify the hang:**

```bash
# This hangs:
agent-browser open https://baidu.com --session test --json
```

```bash
# These work instantly:
agent-browser open https://baidu.com --json
agent-browser open https://baidu.com --cdp 9222 --json
```

**Workaround — use agent-browser directly via CDP:** Start Chrome with remote debugging, then use `agent-browser --cdp 9222` for all operations:

```bash
# 1. Start Chrome with remote debug port
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9222 \
  --user-data-dir="$HOME/chrome-debug-profile" &

# 2. Verify CDP is up
curl -s http://localhost:9222/json/version | grep webSocketDebuggerUrl

# 3. Use agent-browser with --cdp (NO --session!)
agent-browser open "https://haifanwu.com" --cdp 9222 --json
agent-browser read --cdp 9222 --json
agent-browser eval "<js>" --cdp 9222 --json
agent-browser snapshot --cdp 9222 --json
```

**Impact on Hermes:** The built-in `browser` toolset is effectively broken on Windows. It always uses `--session` mode and cannot be configured to use CDP. Until agent-browser fixes the Windows session bug or Hermes adds a CDP backend option, the browser tools should remain disabled:

```bash
hermes tools disable browser
```

**Add `--headed` for visible browser (WeChat QR login, etc.):**

```bash
agent-browser open "https://haifanwu.com" --cdp 9222 --headed
# Or set AGENT_BROWSER_HEADED=true in ~/.hermes/.env
```

## Pitfalls

- **Desktop restart ≠ gateway restart.** The gateway is a separate process. If you `hermes update` or the desktop auto-updates, you MUST restart the gateway separately.
- **`.pyc` cache is not the issue.** Deleting `__pycache__` won't help — the stale bytecode is in the running process's memory, not on disk. Only a process restart fixes it.
- **`sourceMode: false` in `desktop-build-stamp.json`** is normal for the desktop app build. It means the desktop was built from a specific commit, not that it's running stale code. The agent process reads from the source tree at runtime.
- **agent-browser `--session` hangs on Windows.** Do not use `--session` mode on Windows. Use `--cdp <port>` instead (see Browser section above).
