# 飞书 user_access_token 认证模式

## 为什么需要 user_access_token

`tenant_access_token`（应用身份）无法访问用户的私人文件夹和文档，即使通过群组授权分享也可能失效。
`user_access_token`（用户身份）可以直接以用户身份操作，绕过权限限制。

## Feishu-MCP 配置源优先级

Feishu-MCP 读取配置的顺序（高→低）：
1. **CLI 参数**（如 `--feishu-app-secret`）
2. **环境变量**（`process.env.FEISHU_*`，由 Hermes 从 config.yaml `mcp_servers.feishu-mcp.env` 传入）
3. **dotenv `.env` 文件**（MCP 工作目录下的 `.env`，通过 `dotenv` 库加载——**不会覆盖已有环境变量**）
4. **默认值**

**关键含义**：config.yaml 中的 env 会覆盖 .env 文件中的同名变量。

## OAuth 授权完整流程

### 前置条件
1. config.yaml 配置 `FEISHU_AUTH_TYPE: user` + `FEISHU_APP_SECRET`
2. 飞书开放平台 → 安全设置 → 重定向 URL 添加 `http://localhost:3333/callback`
3. **重启网关**（从外部终端：`hermes gateway restart`）

### 授权步骤
1. 调用任意 Feishu-MCP 工具（如 `get_feishu_root_folder_info`）
2. MCP 返回错误，错误信息中包含 OAuth 授权链接
3. 授权链接的 `state` 参数是 base64 编码的 JSON（含 appId, appSecret, clientKey, redirectUri, timestamp）
4. 用户在浏览器打开链接 → 飞书登录页 → 授权确认
5. 浏览器重定向到 `http://localhost:3333/callback?code=xxx&state=xxx`
6. Feishu-MCP 回调服务用 code 换取 user_access_token 并缓存
7. 页面显示「授权成功」

### 回调服务
- Feishu-MCP 在 stdio 模式下也会启动 localhost:3333 HTTP 服务用于 OAuth 回调
- 回调服务是独立的 Node.js 进程
- Token 缓存在 `~/.cache/feishu-mcp/user_token_cache.json`

### 在用户电脑上打开授权链接
如果需要在用户本机打开链接（而非远程浏览器）：
```bash
# 方法1：PowerShell 打开 Edge
powershell.exe -Command "Start-Process 'msedge' 'URL_HERE'"

# 方法2：创建桌面快捷方式
python3 -c "
url = 'https://accounts.feishu.cn/...'
shortcut = f'[InternetShortcut]\nURL={url}\n'
with open('C:/Users/HMSJ/Desktop/飞书授权.url', 'w') as f:
    f.write(shortcut)
"
```

## Troubleshooting

### `invalid_client`（错误码 20002）
**原因**：client_secret 不正确
**排查**：
1. 检查 config.yaml 中 `FEISHU_APP_SECRET` 的值
2. 检查 Feishu-MCP 工作目录下 `.env` 文件中的 `FEISHU_APP_SECRET`
3. 两者可能不一致——config.yaml env 优先级更高
4. 确认飞书开放平台上的 App Secret 与配置一致
5. 修改后**必须重启网关**（外部终端 `hermes gateway restart`）

### 网关拒绝重启
```
✗ Refusing to restart the gateway from inside the gateway process.
```
**解决**：打开一个新的 cmd/PowerShell 窗口，运行 `hermes gateway restart`

### MCP 进程使用旧配置
**症状**：config.yaml 已更新但 MCP 工具仍使用旧值
**原因**：网关进程缓存了启动时的 config.yaml，spawn 的 MCP 子进程继承旧环境变量
**解决**：
1. 从外部终端 `hermes gateway restart`
2. 或手动 kill 网关进程（pythonw.exe running `hermes_cli.main gateway run`）后重新启动

### 授权页面显示成功但 token 未缓存
**原因**：浏览器重定向到 callback 时，回调服务可能未收到 code 参数
**排查**：
- 检查 callback 页面的原始数据，确认是否有 `access_token`
- 如果显示「缺少 code 参数」，说明浏览器直接访问了 callback 而非从飞书跳转
- 确认授权链接中的 `redirect_uri` 是 `http://localhost:3333/callback`

### state 参数验证
授权链接的 state 参数可以解码验证配置是否正确：
```python
import base64, json
from urllib.parse import unquote
state = unquote("URL中的state参数值")
data = json.loads(base64.b64decode(state))
print(json.dumps(data, indent=2))
# 确认 appSecret 是否与期望值一致
```

## 注意事项

- user_access_token 有效期约 2 小时，Feishu-MCP 支持自动刷新
- `offline_access` scope 必须包含，否则 refresh_token 不下发
- 首次授权需要用户在浏览器中操作，无法完全自动化
- 多用户场景：每个用户需要单独完成 OAuth 授权
- 安全设置中的重定向 URL 必须与回调地址完全一致（包括端口号）

## 相关 Feishu-MCP 工具需要 user_access_token

- `list_feishu_tasks` — 列取"我负责的"任务
- 文件夹操作（当 tenant_access_token 权限不足时）
- 任何需要以用户身份操作的场景
