# RunningHub 导演台 (HyperFrames) Analysis via Kimi WebBridge

How to analyze a RunningHub 导演台 (Director / HyperFrames) project when the user shares a URL like `https://rhtv.runninghub.cn/projects/canvas/<id>`.

## Difference from ComfyUI Workflow Analysis

| 维度 | ComfyUI 工作流 | 导演台 (HyperFrames) |
|------|---------------|---------------------|
| URL 前缀 | `runninghub.cn/workflow/` | `rhtv.runninghub.cn/projects/canvas/` |
| 渲染方式 | Vue SPA + ComfyUI iframe | Vue/React SPA (3D canvas) |
| a11y tree | iframe 内容不可见 | UI 元素可见（工程列表、资产面板等） |
| 提取方法 | evaluate JS into iframe | snapshot + screenshot + vision |
| 核心功能 | 节点+连线+参数 | 3D 场景+角色+分镜+机位 |

## Step-by-Step

### 1. Navigate

```json
{"action":"navigate","args":{"url":"https://rhtv.runninghub.cn/projects/canvas/<id>","newTab":true,"group_title":"导演台"},"session":"rh-director"}
```

### 2. Wait for SPA render (~3s), then screenshot

```json
{"action":"screenshot","args":{"format":"jpeg","quality":75},"session":"rh-director"}
```

### 3. Analyze with vision

Key questions:
- 工程名称？有没有可动角色/假人模型？
- 3D 场景内容？室内/室外？
- 分镜/机位？有几个预览角度？
- 资产库有什么？素材库/虚拟人像库/我的资产/团队资产？

### 4. Navigate the UI

Use `snapshot` to find UI element refs, then `click` to:
- 展开「我的工程」列表 → 切换项目
- 切换「资产」标签 → 浏览素材库/虚拟人像库
- 点击「导演台」→ 进入 3D 编辑视图
- 切换「3D 模式」/「2D 模式」

### 5. Explore the 3D Scene

The 3D viewport renders on a `<canvas>`. a11y tree won't show the 3D content — use `screenshot` + vision. Scene editing tools (move, rotate, scale, lighting) are in the bottom toolbar.

## Key UI Elements (by role)

- 「我的工程 N」button — expand project list
- 「资产」button — asset library (素材库, 虚拟人像库, 我的资产, 团队资产)
- 「导演台」button — 3D director mode
- 「分镜大师」button — storyboard tools
- 「编辑元素」button — element editor
- 「打光」/「灯光」— lighting controls
- 「角度」— camera angle
- FOV/镜头距离 sliders — field of view and camera distance
- 「截屏」「录制视频」— export tools
- 「加入 Agent」— AI assistant

## Pitfalls

1. **Not an iframe** — 导演台 is a native SPA, not a ComfyUI iframe. The `app.graph` API does not exist here.
2. **3D canvas invisible to a11y** — Snapshot won't show 3D scene content, only UI chrome. Use screenshot + vision for scene analysis.
3. **项目切换** — Clicking a project thumbnail navigates away. Use `screenshot` after navigation to confirm the new project loaded.
