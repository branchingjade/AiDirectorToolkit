#!/usr/bin/env python3
"""Sync external skills from tapped GitHub repos into Hermes skills directory.

Cron-friendly: stdout is the delivery message (compact Chinese brief).
Use with cron: script=scripts/sync-external-skills.py, no_agent=true
"""
import os
import stat
import sys
import shutil
import subprocess
from pathlib import Path

SKILLS_DST = Path.home() / "AppData" / "Local" / "hermes" / "skills"
TMP_BASE = Path("/tmp")

# Repo config
REPOS = {
    "https://github.com/mattpocock/skills.git": {
        "categories": ["engineering", "productivity", "misc", "in-progress", "personal"],
        "dst_prefix": "mattpocock",
        "skills_subpath": "skills",
    },
}


def rmtree_force(path):
    """Remove a directory tree, handling Windows permission issues.

    On Windows, .git/objects/pack/*.idx files are read-only and shutil.rmtree
    fails with PermissionError. This onerror handler chmods +w and retries.
    """
    def on_error(func, p, exc_info):
        os.chmod(p, stat.S_IWRITE)
        func(p)
    shutil.rmtree(str(path), onerror=on_error)


def clone(repo_url, clone_dir):
    clone_dir = Path(clone_dir)
    if clone_dir.exists():
        rmtree_force(clone_dir)
    subprocess.run(
        ["git", "clone", "--depth", "1", repo_url, str(clone_dir)],
        check=True, capture_output=True,
    )
    return clone_dir


def sync_repo(repo_url, categories, dst_prefix, skills_subpath="skills"):
    """Generic sync: clone, copy category dirs, count skills, clean up."""
    name = repo_url.rstrip("/").split("/")[-1].replace(".git", "")
    clone_dir = TMP_BASE / f"{name}-sync"
    clone(repo_url, clone_dir)

    results = []
    src_base = clone_dir / skills_subpath
    for cat in categories:
        src = src_base / cat
        dst = SKILLS_DST / f"{dst_prefix}-{cat}"
        if src.is_dir():
            if dst.exists():
                rmtree_force(dst)
            shutil.copytree(src, dst)
            count = len(list(dst.rglob("SKILL.md")))
            label = f"{dst_prefix}-{cat}"
            results.append((label, count))

    rmtree_force(clone_dir)
    return results


def main():
    total_count = 0
    all_results = []

    for repo_url, cfg in REPOS.items():
        prefix = cfg["dst_prefix"]
        categories = cfg["categories"]
        subpath = cfg.get("skills_subpath", "skills")
        try:
            results = sync_repo(repo_url, categories, prefix, subpath)
            for label, count in results:
                all_results.append((label, count))
                total_count += count
        except Exception as e:
            print(f"❌ {prefix} 同步失败: {e}", file=sys.stderr)

    if total_count == 0:
        print("🔄 技能同步 | 无更新")
    else:
        parts = []
        for repo_url, cfg in REPOS.items():
            prefix = cfg["dst_prefix"]
            repo_total = sum(
                c for label, c in all_results if label.startswith(prefix)
            )
            if repo_total > 0:
                parts.append(f"{prefix} {repo_total}个")
        repos_part = " + ".join(parts) if parts else "无"
        print(f"🔄 技能同步 | {repos_part} | 执行 /reload-skills 生效")
        for label, c in all_results:
            print(f"   {label}: {c} 个技能")


if __name__ == "__main__":
    main()
