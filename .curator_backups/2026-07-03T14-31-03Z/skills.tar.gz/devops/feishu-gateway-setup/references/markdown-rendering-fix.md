# Feishu Markdown Rendering

## Actual code behavior (verified 2026-07-01)

`_build_outbound_payload` in `adapter.py` (note: code now lives under `plugins/platforms/feishu/adapter.py`, not `gateway/platforms/feishu.py`):

```python
def _build_outbound_payload(self, content: str) -> tuple[str, str]:
    if _MARKDOWN_HINT_RE.search(content):
        return "post", _build_markdown_post_payload(content)
    return "text", json.dumps({"text": content}, ...)
```

**Logic**: post format (markdown rendered) only fires when `_MARKDOWN_HINT_RE` matches. Plain text without any markdown syntax → `text` format → no rendering.

`_MARKDOWN_HINT_RE` matches:
- `#` headings, `-`/`*` lists, `1.` ordered lists
- `---` horizontal rules, ``` code fences, `` ` `` inline code
- `**bold**`, `~~strikethrough~~`, `<u>underline</u>`, `*italic*`
- `[links](url)`, `>` blockquotes
- `|` pipe tables (table separator line triggers markdown hint match)

## Workaround: SOUL.md format requirement

Force the agent to prefer markdown in Feishu responses. Add to `~/.hermes/SOUL.md`:

```markdown
# 飞书回复格式

所有通过飞书平台发送的回复，**尽量**包含 markdown 格式元素
（**粗体**、- 列表、# 标题、`代码` 等）以确保富文本渲染。
简短回复（确认、问候、单句）可不含。

回复规则：无推理过程、无工具进度、无底栏，中文简洁。
```

This nudges `_MARKDOWN_HINT_RE` to match more often, triggering post format.

### ⚠️ Do NOT use "必须" (must)

Using "必须" causes the agent to choke on short replies in group chats — it tries to force markdown into every response and may fail silently, making the bot unresponsive. **Symptom**: DM works fine, group chat goes silent. **Fix**: relax to "尽量" and restart gateway.

## `_build_markdown_post_rows` — md element single-paragraph constraint (CRITICAL)

Feishu's post message format: **each `md` tag supports only ONE paragraph.** Multi-paragraph content (containing blank lines / `\n\n`) inside a single `md` element causes the ENTIRE element to fail parsing and render as plain text.

The fix (applied in `feishu.py` `_build_markdown_post_rows`):

- New helper `_make_rows(text)` splits content on `\n{2,}` (blank lines) and wraps each non-empty paragraph in its own `[{"tag": "md", "text": "..."}]` row
- Content without code fences: directly passed through `_make_rows()`
- Content with code fences: each flushed segment goes through `_make_rows()` via `rows.extend(_make_rows(segment))` (replaces old `rows.append`)

**Before fix**: `**bold**\n\n*italic*` → one `md` element → plain text garbage
**After fix**: `**bold**\n\n*italic*` → two separate `md` elements → both render correctly

Code change at `adapter.py` `_build_markdown_post_rows`. Requires `hermes gateway restart` after applying.

## Pitfalls

- **Entire message in code block**: If agent wraps the whole response in ```triple backticks```, Feishu renders EVERYTHING in monospace. Use `##` headings and `-` bullets for structure, only use ``` for actual code snippets.
- **Tables (FIXED 2026-07-01)**: `_MARKDOWN_TABLE_RE` no longer forces text mode — the force-text block at `adapter.py:_build_outbound_payload` (~line 4441) was removed:
  ```python
  # REMOVED (was lines 4438-4443):
  # if _MARKDOWN_TABLE_RE.search(content):
  #     return "text", json.dumps({"text": content}, ...)
  ```
  Tables now fall through to `_MARKDOWN_HINT_RE` (pipe `|` triggers the markdown hint), get `msg_type=post`, and render correctly. Verified via live Feishu test covering all markdown syntax including 3-column tables with links.
- **Multi-paragraph in one `md` element**: ⚠️ This was the root cause of multi-paragraph messages rendering as plain text before the `_make_rows()` fix (see above). The fix is in code — the agent does NOT need to manually split paragraphs; `_build_markdown_post_rows` handles it automatically.
- **Gateway restart required**: After editing SOUL.md or adapter.py, `hermes gateway restart` to take effect.
