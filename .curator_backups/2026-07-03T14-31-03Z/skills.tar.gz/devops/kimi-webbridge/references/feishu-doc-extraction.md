# Feishu 云文档内容提取

通过 Kimi WebBridge 访问需要登录态的飞书云文档（`my.feishu.cn/docx/...`）并提取全文内容。

## 要点

- 飞书文档是 SPA，内容在 `document.body.innerText` 中即可获取全文
- 主滚动容器是 `.bear-web-x-container`（非 `document.body` 或 `window`）
- 侧边栏链接是页内锚点，点击即可滚动到对应标题

## 完整流程

### 1. 导航到文档

```json
{"action":"navigate","args":{"url":"https://my.feishu.cn/docx/<TOKEN>","newTab":true,"group_title":"文档标题"},"session":"feishu-doc"}
```

### 2. 滚动到底部

Feishu 的滚动容器不是 `window` 或 `document.body`。先找到可滚动元素：

```js
// 查找所有 scrollHeight > clientHeight 的 div
(() => {
  const divs = document.querySelectorAll('div');
  let found = [];
  for (const d of divs) {
    if (d.scrollHeight > d.clientHeight + 100) {
      found.push({class: d.className.substring(0,80), scrollHeight: d.scrollHeight, clientHeight: d.clientHeight});
      if (found.length >= 3) break;
    }
  }
  return JSON.stringify(found);
})()
```

找到后滚动到底部：

```js
(() => {
  const el = document.querySelector('.bear-web-x-container');
  el.scrollTop = el.scrollHeight;
  return 'scrolled';
})()
```

### 3. 提取内容

```js
(() => { return JSON.stringify({text: document.body.innerText}); })()
```

`innerText` 返回全文，包含侧边栏和所有展开的章节。

### 4. 展开折叠章节

侧边栏链接（`@e` ref）是页内锚点，点击不会导航到新页面，只会滚动到对应标题：

```json
{"action":"click","args":{"selector":"@e16"},"session":"feishu-doc"}
```

### 5. 截图辅助理解布局

当 a11y 树不够直观时，截图后用 `vision_analyze` 理解页面结构和折叠状态：

```json
{"action":"screenshot","args":{"format":"jpeg","quality":70},"session":"feishu-doc"}
```

## 陷阱

- **滚动容器不是 window**：`window.scrollTo(0, document.body.scrollHeight)` 对飞书文档无效，必须操作 `.bear-web-x-container`
- **innerText 足够**：飞书文档的内容在 `innerText` 中完整呈现（包括代码块文本），不需要逐个节点遍历
- **侧边栏项可能为空**：`AI应用`、`Skills` 等侧边栏链接对应的章节可能确实没有内容，不是加载失败
- **关闭 session**：任务完成后考虑 `close_session` 释放浏览器标签
