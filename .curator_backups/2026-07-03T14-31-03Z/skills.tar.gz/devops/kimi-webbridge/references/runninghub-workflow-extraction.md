# RunningHub 工作流节点提取

通过 Kimi WebBridge 从 RunningHub 画布页面的 ComfyUI iframe 中提取完整工作流节点信息。

## 前置条件

- Kimi WebBridge 守护进程运行中（`localhost:10086`）
- RunningHub 工作流页面已打开并完成渲染
- 页面含 ComfyUI iframe

## 步骤

### 1. 导航到工作流页面

```json
{"action":"navigate","args":{"url":"https://www.runninghub.cn/workflow/<id>","newTab":true,"group_title":"提取工作流"},"session":"rh-extract"}
```

### 2. 等待 SPA 渲染（2-3秒），确认 iframe 已加载

### 3. 探查 iframe 是否可访问

```js
(() => {
  const iframe = document.querySelector('iframe');
  if(!iframe) return 'no iframe';
  const win = iframe.contentWindow;
  if(!win) return 'no contentWindow (cross-origin?)';
  const app = win.app;
  if(!app) return JSON.stringify({winKeys: Object.keys(win).filter(k => k.length < 30 && win[k]).slice(0,30)});
  return 'app accessible, node count: ' + (app.graph?._nodes?.length || Object.keys(app.graph?.nodes||{}).length);
})()
```

### 4. 提取完整节点清单

```js
(() => {
  const iframe = document.querySelector('iframe');
  const win = iframe.contentWindow;
  const app = win.app;
  const graph = app.graph;
  const nodes = graph._nodes || graph.nodes;
  const arr = Array.isArray(nodes) ? nodes : Object.values(nodes);
  const result = arr.map(n => ({
    type: n.type,
    title: n.title,
    id: n.id,
    inputs: n.inputs ? n.inputs.map(i => ({name: i.name, type: i.type, link: i.link})) : [],
    outputs: n.outputs ? n.outputs.map(o => ({name: o.name, type: o.type, links: o.links})) : []
  }));
  return JSON.stringify(result);
})()
```

### 5. 如需提取连线关系

```js
(() => {
  const app = document.querySelector('iframe').contentWindow.app;
  const links = app.graph.links || app.graph._links || [];
  const arr = Array.isArray(links) ? links : Object.values(links);
  return JSON.stringify(arr.map(l => ({
    id: l.id,
    origin_id: l.origin_id,
    origin_slot: l.origin_slot,
    target_id: l.target_id,
    target_slot: l.target_slot,
    type: l.type
  })));
})()
```

## RunningHub 特有节点

| RH 节点 | 作用 | 参数 |
|---------|------|------|
| `GetNode` | 引用上传的输入图片 | 输出 `IMAGE`，标题通常为 `Get_<名称>` |
| `SetNode` | 中间路由/直通节点 | 输入 `IMAGE`，输出 `IMAGE` |
| `ModelSamplingAuraFlow` | RH 封装的 AuraFlow 采样 | 输入 `model`, `shift`，输出 `MODEL` |
| `SeedVR2BlockSwap` | SeedVR2 显存管理配置 | 输入 `blocks_to_swap`, `use_non_blocking`, `offload_io_components` |
| `ImageScaleToTotalPixels` | 按目标总像素数缩放（非固定倍数） | 输入 `image`, `upscale_method`, `megapixels` |

其他节点多为标准 ComfyUI 类型（`LoadImage`, `CheckpointLoaderSimple`, `CLIPTextEncode`, `KSampler`, `SaveImage` 等）及社区节点（Impact Pack 的 `PixelKSampleUpscalerProvider` / `IterativeImageUpscale`, rgthree 的 `Image Comparer`）。

### 6. 提取完整参数值（widgets）

上面的步骤只拿到节点类型和连线关系，**不含参数值**（denoise、steps、checkpoint 名称等）。完整数据需同时读取 `n.widgets`：

```js
(() => {
  const iframe = document.querySelector('iframe');
  const app = iframe.contentWindow.app;
  const graph = app.graph;
  const nodes = Object.values(graph._nodes);
  const result = nodes.map(n => {
    const w = {};
    if(n.widgets) for(let kw of n.widgets) { w[kw.name] = kw.value; }
    const ins = {};
    if(n.inputs) for(let i of n.inputs) {
      ins[i.name] = i.link ? {link: i.link} : (i.widget?.value ?? i.value ?? '?');
    }
    return {id:n.id, type:n.type, title:n.title, widgets:w, inputs:ins};
  });
  return JSON.stringify(result);
})()
```

**widgets 字段包含所有可调参数的当前值**（如 `denoise: 0.25`, `steps: 3`, `ckpt_name: "z-image-turbo-bf16-aio.safetensors"`），`inputs` 中的 link 引用通过 `{link: <id>}` 标识连线关系。

## 注意事项

- iframe 跨域时 `contentWindow` 返回 null，此时无法提取
- RH 的 `GetNode` 是输入图片的唯一入口——工作流必须通过它引用用户上传的图片，不能用标准 `LoadImage`
- 节点 ID 在每次保存/加载时可能变化，不要硬编码 ID
- 部分节点（如 `ModelSamplingAuraFlow`）是 RH 封装层，本地 ComfyUI 不存在对应节点

## 陷阱

### evaluate 不支持 async 函数
`evaluate` 的 `code` 参数传入 `async () => { ... }` 时不会执行，只返回函数对象。需要异步操作时用 IIFE 包装 Promise 链：

```js
// ❌ 不会执行
async () => { const r = await fetch('/api/...'); return r.json(); }

// ✅ 正确
(() => {
  return fetch('/api/...').then(r => r.json()).then(d => JSON.stringify(d));
})()
```

### 视觉分析会误读参数值
不要依赖 `vision_analyze` 读 ComfyUI 截图上的参数数字。本会话实测：视觉模型将 `denoise: 0.25` 误读为 `0.65`，`steps: 3` 误读为 `8`。**参数值必须通过代码提取（`app.graph._nodes[].widgets[]`），截图仅用于理解节点空间布局。**

### session tab 关闭后需重建
用户关闭浏览器标签后，该 session 下的所有 evaluate/snapshot 返回 `"session tab was closed"`。必须重新 `navigate` 创建新 session。
