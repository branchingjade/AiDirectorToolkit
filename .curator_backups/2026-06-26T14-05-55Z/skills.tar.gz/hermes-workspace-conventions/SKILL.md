---
name: hermes-workspace-conventions
description: "Hermes 工作区约定。目录结构、操作流程（计划优先）、会话分支策略规范。用户会纠正不合理的安排。Use when: 新建文件夹、组织文件、决定项目放哪里、需确认执行顺序、问会话分支/worktree/回滚怎么用。"
---

# Hermes 工作区目录约定

## 根目录

所有内容在 `~/Documents/Hermes/` 下，按用途分：

```
~/Documents/Hermes/
├── Plugins/             存档 — 浏览器扩展、工具安装包、脚本
├── Projects/            独立项目 — 有 git repo 的软件项目
├── .hermes/             Hermes 运行时
└── *.md                 参考文档
```

## 分类规则

### Plugins/ — 插件存档

**放什么：** 浏览器扩展、油猴脚本、ComfyUI 节点、TD .tox 等。

**不放什么：** 正在开发中的、有自己 git repo 的项目。

```
Plugins/
└── browsers/extensions/
    └── RH小帮手-v2.2.4/     ← 发行版存档
```

### Projects/ — 独立项目

**判断标准：** 有独立 git repo、有 build/dev 流程、能独立发版 → 放 Projects/。

```
Projects/
└── rh-helper/              ← 开发版 (.git, build.sh, src/)
```

### 根目录 — 参考文档

跨项目参考文档放根目录，如 `版本管理策略.md`。

## 操作约定

### 计划优先

**任何操作前必须：先规划 → 等用户确认 → 再执行。方案没定下来就禁止执行。**

- 批量操作必须先 1 条验证，确认后扩全量
- 不要拿到问题直接动手，不要跳过规划阶段
- 用户说"先做规划"就是字面意思——先给方案，不动手

## 会话工作流约定

### 分支策略：思路用分支，执行回主线

```
主线（执行 + 回滚保护）
  │
  ├─ /branch → 分支A（纯聊天探索，不碰文件）
  ├─ /branch → 分支B（纯聊天探索，不碰文件）
  │
  └─ 回到主线 → 实际修改文件，翻车了 /rollback
```

- **`/branch`** — 只分叉对话历史，不隔离文件。轻量，适合换思路聊、对比方案。
- **`hermes -w`** — 对话+文件双隔离（自动创建 git worktree），适合并行开发任务。
- **回滚保护** — 全局开启：`hermes config set checkpoints.enabled true`，此后任何项目文件修改前自动快照。

### 开关回滚

全局开启后所有项目生效：
```bash
hermes config set checkpoints.enabled true
```

单个会话开启（不持久化）：
```bash
hermes --checkpoints
```

回滚命令：`/rollback`（列快照）、`/rollback N`（恢复到第 N 个快照）

详见 `references/session-grouping-mechanism.md` — 会话侧边栏分组的三级结构（Project → Repo → Lane）及分裂修复方法。

## Pitfalls

- **不要** 把独立项目放到 Plugins/（Plugins 是存档，不是开发空间）
- **不要** 在 Hermes 工作区外创建同级目录（如 `~/Documents/dev/`）
- 可以先放 subdir 再迁移，但最终位置按此约定
- **重命名项目必须同步改目录名**：用户要求更直观的项目名时，不能只改 Hermes 内部的 project name，必须把磁盘上的目录也一起 rename，再重建 project 指向新路径。只改名字不改目录 = 用户会纠正。
- **桌面端项目不会自动发现**：文件系统里有目录不代表侧边栏会显示。Hermes 桌面端项目需要通过 `project_create(name, path)` 显式注册才会出现在侧边栏。用户说"项目中看不到"时要主动帮他们注册。
- **项目根目录如有嵌套会导致会话分组杂音**：当项目根（如 `Documents/Hermes`）包含子目录同时又是另一个独立项目（如 `Projects/rh-helper`）时，会话列表可能出现重复分组。桌面端侧边栏的会话分组按分支/源标签划分，与 git 分支无关。会话数据库在 `AppData\\Local\\hermes\\state.db`（`~/.hermes/state.db` 为空文件，`AppData\\Roaming\\Hermes\\DIPS` 是浏览器弹窗数据库，都不是会话库）。
- **会话元数据不一致导致侧边栏分裂**：同一项目下的会话如果 `git_branch` 或 `git_repo_root` 字段不一致，会被分到不同的 lane（如 "master" / "main" / "Hermes" 三个分组）。症状：侧边栏同一项目下出现多个"分支"分组。根因：`project_tree.py` 的 `_place()` 按 `git_branch` + `git_repo_root` 分配 lane——有值的会话创建独立命名 lane，无值的会话走 `_place_by_heuristic()` 用 cwd basename 作为 lane 名。修复：`UPDATE sessions SET git_branch=NULL, git_repo_root=NULL WHERE cwd='项目路径' AND (git_branch IS NOT NULL OR git_repo_root IS NOT NULL)`——注意只清本项目下的，别清其他项目的。改完需重启 GUI 刷新侧边栏。
