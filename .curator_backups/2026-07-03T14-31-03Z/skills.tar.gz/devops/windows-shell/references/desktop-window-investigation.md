# Desktop Window Investigation (Windows)

当需要调查 Windows 桌面上某个窗口的来源时使用 — 结合 Python ctypes 枚举窗口、
截图、视觉分析的三步法。

## 为什么不用 PowerShell

PowerShell 通过 git-bash 传递命令时，中文输出有 GBK/UTF-8 编码问题，导致
`subprocess` 解码失败。直接用 Python ctypes 调用 Win32 API 最可靠。

## 三步法

### 1. 枚举所有可见窗口

```python
import ctypes
from ctypes import wintypes

user32 = ctypes.windll.user32
WNDENUMPROC = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_int, ctypes.c_int)

windows = []

def enum_callback(hwnd, lParam):
    if user32.IsWindowVisible(hwnd):
        length = user32.GetWindowTextLengthW(hwnd)
        if length > 0:
            buf = ctypes.create_unicode_buffer(length + 1)
            user32.GetWindowTextW(hwnd, buf, length + 1)
            title = buf.value
            
            cls_buf = ctypes.create_unicode_buffer(256)
            user32.GetClassNameW(hwnd, cls_buf, 256)
            cls = cls_buf.value
            
            rect = wintypes.RECT()
            user32.GetWindowRect(hwnd, ctypes.byref(rect))
            
            x, y = rect.left, rect.top
            w, h = rect.right - rect.left, rect.bottom - rect.top
            
            if w > 0 and h > 0:
                windows.append({
                    'title': title, 'class': cls,
                    'x': x, 'y': y, 'w': w, 'h': h, 'hwnd': hwnd
                })
    return True

user32.EnumWindows(WNDENUMPROC(enum_callback), 0)

# 按位置排序，左上角优先
windows.sort(key=lambda w: (w['y'], w['x']))

# 筛选特定区域的窗口
for w in windows:
    if w['x'] < 200 and w['y'] < 200 and w['w'] > 30 and w['h'] > 30:
        print(f"'{w['title']}' ({w['class']}) @ ({w['x']},{w['y']}) {w['w']}x{w['h']}")
```

### 2. 截取桌面（全屏或局部）

```python
from PIL import ImageGrab
# 全屏
img = ImageGrab.grab()
img.save('/tmp/desktop.png')

# 裁剪左上角 500x500
img = ImageGrab.grab(bbox=(0, 0, 500, 500))
img.save('/tmp/corner.png')
```

如果没有 PIL，`mss` 是备选：
```python
import mss
with mss.mss() as sct:
    sct.shot(output='/tmp/desktop.png')
```

### 3. 用 vision_analyze 检查截图

截完图后用 `vision_analyze` 查看，配合精准问题描述。

## 获取更多窗口细节

```python
# 获取窗口样式（判断是否为弹窗/工具窗口/分层窗口）
style = user32.GetWindowLongW(hwnd, -16)   # GWL_STYLE
ex_style = user32.GetWindowLongW(hwnd, -20) # GWL_EXSTYLE

WS_VISIBLE = 0x10000000
WS_POPUP = 0x80000000
WS_EX_TOOLWINDOW = 0x80      # 不在任务栏显示
WS_EX_LAYERED = 0x80000      # 分层窗口（常见于叠加层/悬浮窗）
WS_EX_TRANSPARENT = 0x20     # 透明窗口（点击穿透）

print(f"Visible: {bool(style & WS_VISIBLE)}")
print(f"Popup: {bool(style & WS_POPUP)}")
print(f"ToolWindow: {bool(ex_style & WS_EX_TOOLWINDOW)}")
print(f"Layered: {bool(ex_style & WS_EX_LAYERED)}")
```

## 根据窗口标题查找进程来源

```python
# 根据窗口标题找进程
hwnd = user32.FindWindowW(None, "窗口标题")
if hwnd:
    pid = ctypes.c_ulong()
    user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
    # 然后用 PowerShell 查进程路径
    # Get-Process -Id <pid> | Format-List Path,Company
```

## 常见自启窗口来源

用 PowerShell 检查注册表自启项（注意 `\$` 转义）：
```bash
powershell -NoProfile -Command "Get-ItemProperty 'HKCU:\\Software\\Microsoft\\Windows\\CurrentVersion\\Run' | Format-List"
```

常见"意想不到"的自启窗口来源：
- Eagle（素材管理）：`--hidden` 参数有时无效，在左上角留下 480×440 的深色窗口
- CC Switch（桌面切换工具）：在 (0,0) 留下 15×15 的微小叠加层
- 各种 Electron 应用（飞书、豆包、Kimi 等）的辅助窗口
