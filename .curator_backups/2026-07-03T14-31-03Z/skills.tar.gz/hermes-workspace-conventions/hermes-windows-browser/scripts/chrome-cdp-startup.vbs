Set WshShell = CreateObject("WScript.Shell")
' 1 = 正常可见窗口, 0 = 隐藏
WshShell.Run """C:\Program Files\Google\Chrome\Application\chrome.exe"" --remote-debugging-port=9222 --headless=new --user-data-dir=C:\Users\HMSJ\.hermes\chrome-cdp-profile", 1, False
