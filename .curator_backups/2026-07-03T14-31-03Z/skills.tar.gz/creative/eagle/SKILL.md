---
name: eagle
description: Eagle 本地 API 资产管理——浏览文件夹、搜索素材、管理标签。Eagle 是一款设计/素材管理工具，通过 localhost:41595 提供 REST API。
---

# Eagle API 资产管理

## 触发条件
用户提到 Eagle、素材库、在 Eagle 中查找/管理文件、Eagle 标签/文件夹操作。

## API 基础

- **端口**：`localhost:41595`
- **认证**：无需 token（token 在 `/api/application/info` 响应中可见，但所有端点无需认证即可调用）

### 核心端点

```bash
# 获取应用信息（版本、平台、偏好设置）
curl -s http://localhost:41595/api/application/info

# 获取完整文件夹树（递归，包含 children）
curl -s http://localhost:41595/api/folder/list

# 列出文件夹内的项目
curl -s "http://localhost:41595/api/item/list?folders=<FOLDER_ID>"

# 按关键词搜索
curl -s "http://localhost:41595/api/item/list?keyword=<关键词>"

# 按扩展名筛选（限制 50 条）
curl -s "http://localhost:41595/api/item/list?ext=mp3&limit=50"
```

### 响应格式

```json
{
  "status": "success",
  "data": [
    {
      "id": "MQF4WH0AXL5YA",
      "name": "音乐",
      "children": [...],       // folder/list 才有
      "ext": "wav",
      "tags": [],
      "url": "",
      "folders": ["MQF4WH0AXL5YA"]
    }
  ]
}
```

## Eagle MCP vs REST API（分工明确）

| 操作 | 用哪个 | 原因 |
|------|--------|------|
| 查询文件夹内容 | `mcp_eagle_listItems(folders=...)` | REST `?folders=` 在 Eagle 4.0 返回 404 |
| 搜索关键词 | MCP 或 REST 均可 | 两个都正常工作 |
| 获取文件路径 | `mcp_eagle_getItemFilePath` | REST 没有这个端点 |
| 更新标签/注释 | REST `POST /api/item/update` | **MCP 没有 update 工具**，必须走 REST |
| 文件夹操作 | `mcp_eagle_createFolder` | REST `parent` 参数有坑 |

**写入操作始终用 `execute_code` + Python `urllib`**，不走 MCP。

**⚠ MCP 工具需要新会话才能生效**：`hermes mcp add eagle` 后必须 `/new` 重开。如果当前会话没有 `mcp_eagle_*` 工具，用下方 REST API 直调（Python `urllib`）降级。

## 关键陷阱

### 1. 中文编码：禁止 terminal + curl，必须 Python urllib

**🚫 禁止**：terminal 中用 `curl` 传中文 JSON。shell 管道编码转换会破坏 UTF-8，导致 Eagle 中文件夹名/标签变成乱码。

**✅ 正确**：用 `execute_code` + Python `urllib.request` 直连 API：

```python
import urllib.request, json

def api(method, path, data=None):
    url = f"http://localhost:41595{path}"
    if data:
        payload = json.dumps(data, ensure_ascii=False).encode('utf-8')
        req = urllib.request.Request(url, data=payload, method=method,
            headers={'Content-Type': 'application/json; charset=utf-8'})
    else:
        req = urllib.request.Request(url, method=method)
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())
```

**例外**：`folder/list` 返回巨型树（可能 >100KB），用 `curl | python3 -c` 流式管道，不进入 execute_code。

### 2. execute_code 中文搜索需 URL 编码

`execute_code` 中的 `urllib.request` 对 URL 路径中的中文会抛 `UnicodeEncodeError: 'ascii' codec can't encode characters`：

```python
# ❌ 中文直接拼 URL → UnicodeEncodeError
items = api('GET', '/item/list?keyword=修复')

# ✅ URL 编码中文
import urllib.parse
kw = urllib.parse.quote('修复')
items = api('GET', f'/item/list?keyword={kw}')
```

### 3. 创建文件夹：用 `parent` 不是 `parentId`

```python
# ❌ parentId 不可靠——文件夹会被建到根目录
api('POST', '/folder/create', {'folderName': 'test', 'parentId': '<ID>'})

# ✅ parent 正确
api('POST', '/folder/create', {'folderName': 'test', 'parent': '<ID>'})
```

### 4. 导入文件：验证结果，不依赖树

`addFromPath(s)` 的 `folderId` 参数已验证可用。导入后立即用直接查询验证，不要依赖 `folder/list` 的树结构（有缓存延迟）：

```python
items = api('GET', f'/item/list?folders={folder_id}')
```

### 5. 文件夹树缓存延迟

`/api/folder/list` 返回的 `children` 可能不反映最近变更。始终用 `item/list?folders=<ID>` 验证。

### 6. 没有删除/移动端点

- `/folder/delete` → 404
- `/item/delete` → 404  
- `/item/move` → 404

出错的文件夹/文件只能让用户在 Eagle GUI 手动删除或拖动。

### 7. 获取文件真实路径（缩略图 API 技巧）

Eagle REST API 没有 `getItemFilePath`，但缩略图 API 暴露了目录：

```python
# 先获取 item 的 thumbnail URL
r = api('GET', '/item/thumbnail?id=<ITEM_ID>')
thumb_path = r['data']  # e.g. "Y:/HMSJ_B.library/images/XXX.info/file_thumbnail.png"
# 去掉 _thumbnail.png 即得文件所在目录
file_dir = thumb_path.rsplit('_thumbnail.png', 1)[0]
# 然后 ls 或直接拼接文件名
```

库路径模式：`<盘符>:/<库名>.library/images/<ITEM_ID>.info/<文件名>.<ext>`

### 8. 覆盖 Eagle 库文件

由于 API 不支持更新文件内容，要替换已导入文件的内容只能直接覆写磁盘文件：

```bash
cp "新文件路径" "Y:/库名.library/images/<ITEM_ID>.info/原文件名"
```

这不会破坏 Eagle 的元数据索引。完整流程见 `references/eagle-file-ops.md`。

### 9. 外部平台元数据：优先用 `window.__NUXT__` 直接取 JSON

曲多多等 Nuxt SPA 在 SSR 渲染时把数据注入 `window.__NUXT__.data[0].songDetail`。**
这是最干净的提取方式**——结构化 JSON，无需文本解析。
优于 DOM shortcut 和快照直读。一次 `browser_console` 调用拿到全部字段。

```javascript
// 首选：__NUXT__ 直接取
var sd = window.__NUXT__.data[0].songDetail;
// sd.bpm, sd.duration, sd.name, sd.composer, sd.performer
// sd.attribute → 分类标签树 [{typeName: "使用场景", child: [{tagName: "影视配乐"}, ...]}, ...]
```

`fetch()` 获取的 HTML 中 `__NUXT__` 数据分散为函数参数 `(false,"true",0,null,{...},...)`，无法从文本直接解析。必须通过 `browser_navigate` 让页面渲染后从 `window.__NUXT__` 读取。

### 10. CDP 浏览器会下载图片到 Eagle 自动导入

`browser_navigate` 加载页面时连带下载专辑封面图，Eagle 自动导入到库中。**处理前清空 `C:\Users\<用户>\Documents\eagle\` 目录**，处理中定期清理。Eagle API 不支持删除，已导入的图片需用户在 GUI 手动移除。

### 11. 禁止逐首重写脚本——用可复用模板

用户对此零容忍。批量写入 Eagle 时，**在 execute_code 中定义一个 `w()` 函数**，每首只传数据 dict，不要重写 urllib/json 样板。模板见 `references/batch-write-template.md`。

## 写入操作（更新元数据）

### 更新文件标签/注释/URL

```bash
curl -X POST "http://localhost:41595/api/item/update" \
  -H "Content-Type: application/json" \
  -d '{"id":"<ITEM_ID>","tags":["版权音乐","曲多多"],"annotation":"曲目ID: 4776764\n来源: haifanwu.com","url":"https://haifanwu.com"}'
```

可写字段：`tags`（数组）、`annotation`（纯文本）、`url`（链接）。

无批处理端点，逐条 POST。

**⚠️ 禁止用 terminal + curl 传中文**：shell 管道的转义会破坏 UTF-8 编码，导致 Eagle 中所有中文变成乱码。批量写入时用 Python `urllib.request` 直连 API（在 `execute_code` 中），不使用 `terminal()` 中转。

### 从文件名提取元数据

Eagle 中版权音乐常见命名格式：
```
曲多多_<ID>_<英文名>.wav    # 曲多多/haifanwu.com
```

可从文件名提取 ID 和名称直接写入标签/注释，无需爬平台（参考 references/quduoduo.md）。

## 典型工作流

### 查找项目素材
1. 用 folder/list 获取完整树
2. 在 Python 中过滤目标文件夹名
3. 用文件夹 ID 调用 item/list

### 解读用户路径描述
用户说"项目-《犬子无双》音乐"意味着 Eagle 路径：`项目 → 《犬子无双》 → 素材 → 音乐`

### 批量查看文件
用 `curl ... | python3 -c` 管道，提取 name、ext、tags、url 字段即可。不要打印整个 JSON 对象。

### 同步外部平台元数据到 Eagle（强制执行前检查）

**⚠️ 执行前强制四步（任何批量操作必须先走）**：
1. **清空自动导入目录**：`C:\Users\HMSJ\Documents\eagle\`（防 browser_navigate 下载封面被 Eagle 捡走）
2. 用 `mcp_eagle_listItems(folders=...)` 列出目标文件，筛选待处理（无标签的跳过）
3. **先讲思路（方向级，非细节）、确认后再动手**
4. 第一首验证通过后，后面全部用同一套代码

确认后执行：

1. `browser_navigate` 到歌曲页 → `browser_console` 读 `window.__NUXT__.data[0].songDetail`（纯 JS 数据，不解析 DOM）
2. `execute_code` 用 `w()` 模板写入（见 `references/batch-write-template.md`）
3. 处理中定期清理自动导入目录

详细提取方法和字段说明见 `references/quduoduo.md`。
