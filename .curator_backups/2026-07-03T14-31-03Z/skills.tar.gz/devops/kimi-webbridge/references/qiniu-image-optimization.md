# Qiniu imageMogr2 实时缩略

## 背景

七牛 CDN 的 `imageMogr2` 支持在 URL 上追加参数实现实时图像处理——缩放、格式转换、裁剪等，无需服务端改动。

## 常见参数

| 参数 | 作用 | 示例 |
|------|------|------|
| `thumbnail/300x` | 限定宽度 300px，等比缩放 | `thumbnail/200x` |
| `thumbnail/!30p` | 缩放到原图 30% | `thumbnail/!50p` |
| `format/webp` | 转为 WebP | `format/webp` |
| `format/jpg` | 转为 JPEG | `format/jpg` |
| `ignore-error/1` | 处理失败时返回原图 | `ignore-error/1` |

## 实战：RunningHub 画布性能优化

RunningHub 的图片 CDN (`rh-canvas-files.xiaoyaoyou.com`) 使用七牛 imageMogr2，但前端只加了 `ignore-error/1`，没加缩略参数，导致 5.5K/4K 原图直接渲染为节点缩略图。

### 诊断脚本

通过 WebBridge evaluate 快速排查：

```js
// 统计图片加载情况
(() => {
  const imgs = document.querySelectorAll('img');
  const groups = {};
  imgs.forEach(img => {
    const src = img.src;
    if (src.includes('imageMogr2')) groups.mogr2 = (groups.mogr2||0)+1;
    else if (src.includes('xiaoyaoyou.com')) groups.raw = (groups.raw||0)+1;
    else if (src.startsWith('blob:')) groups.blob = (groups.blob||0)+1;
    else if (src.startsWith('data:')) groups.dataUri = (groups.dataUri||0)+1;
  });
  const mem = performance.memory || {};
  return JSON.stringify({...groups, heapMB: (mem.usedJSHeapSize/1024/1024).toFixed(1)});
})()
```

### 修复方式对比

| 方式 | 原理 | 副作用 | 推荐 |
|------|------|--------|------|
| DOM 改 img.src | JS 逐个改属性 | ⚠️ 触发 Vue 响应式 + DOM 重建 | ❌ |
| `declarativeNetRequest` | Chrome 网络栈重写 URL | 无 | ✅ |
| CDN 端加参数 | service 端修改模板 | 无 | ✅（需平台配合） |

### 网络层方案（declarativeNetRequest）

```json
{
  "id": 1,
  "priority": 1,
  "action": {
    "type": "redirect",
    "redirect": {
      "regexSubstitution": "https://\\1.xiaoyaoyou.com/\\2?imageMogr2/thumbnail/300x/format/webp/ignore-error/1"
    }
  },
  "condition": {
    "regexFilter": "^https://([^.]+)\\.xiaoyaoyou\\.com/(.*)$",
    "resourceTypes": ["image"]
  }
}
```

请求在发出前被重写，JS 线程完全不参与——不触发 Vue 响应式，不触发 DOM 重建。完整模板见 `templates/declarative-net-request-cache.json`。

## 诊断层2：DOM 节点过载

图片优化后仍卡顿，进一步排查发现根因不止图片——RunningHub 的 Vue/React Flow 画布**不虚拟化节点**，所有节点都在 DOM 中：

```js
// 统计节点数量和屏外渲染
(() => {
  const nodes = document.querySelectorAll('.vue-flow__node, .react-flow__node');
  const vh = window.innerHeight, vw = window.innerWidth;
  let visible = 0, offscreen = 0;
  nodes.forEach(n => {
    const r = n.getBoundingClientRect();
    (r.bottom > -500 && r.top < vh+500 && r.right > -500 && r.left < vw+500)
      ? visible++ : offscreen++;
  });
  return JSON.stringify({
    totalNodes: nodes.length,
    domElements: document.querySelectorAll('*').length,
    visible, offscreen,
    heapMB: (performance.memory.usedJSHeapSize/1024/1024).toFixed(1)
  });
})()
```

实测 RunningHub 画布：**546 节点 / 6225 DOM 元素**，图片优化省了 ~17MB 但卡顿依旧。

### CSS 补丁：content-visibility

```js
(() => {
  const s = document.createElement('style');
  s.textContent = `
    .vue-flow__node, .react-flow__node {
      content-visibility: auto;
      contain-intrinsic-size: 200px 150px;
    }
    [style*="backdrop-filter"] {
      backdrop-filter: blur(12px) !important;
    }
    .vue-flow__viewport, .react-flow__viewport {
      will-change: transform;
    }
  `;
  document.head.appendChild(s);
})()
```

`content-visibility: auto` 让浏览器跳过屏外节点的渲染，CSS containment 限制重排范围。

## 综合诊断结论

RunningHub 画布卡顿的多重根因（完整诊断流程见 `references/performance-debugging.md`）：
1. **图片层**：七牛 CDN 缺缩略参数 → 5.5K 原图当缩略图（declarativeNetRequest 网络层修复 ✅）
2. **DOM 层**：Flow 画布无虚拟化 → 546 节点全在 DOM（CSS content-visibility 缓解，无法根治）
3. **响应式层**：Vue track+get+notify 占 16.3% 主线程 → 需 RunningHub 用 `markRaw`/`shallowRef` 修复

## 适用场景

任何使用七牛 CDN + imageMogr2 的网站，如果存在大图渲染性能问题，都可以通过追加 URL 参数即时优化，无需等待前端修复。对于 SPA 画布类应用，还需要同时排查 DOM 节点数量和虚拟化情况。
