# RunningHub Workflow Analysis via Kimi WebBridge

How to parse and analyze a RunningHub (or similar auth-gated SPA) workflow
when the user shares a URL like `https://www.runninghub.cn/workflow/<id>`.

## Why WebBridge (NOT Hermes CDP)

RunningHub is a Vue 3 SPA — all content is JS-rendered. Its API endpoints
(`/api/workflow/detail`, `/api/workflow/flow`) require authentication cookies.
Hermes CDP uses a separate headless Chrome profile without the user's login
state, so it returns empty pages or 412 TOKEN_INVALID.

**Rule: user says "用我的浏览器" → go straight to Kimi WebBridge.**
Do not attempt Hermes CDP browser tools first. The user's real Chrome has the
session cookies that RunningHub (and other auth-gated SPAs) need.

## Step-by-Step

### 1. Navigate to the workflow URL

```bash
# Write payload to temp file (Windows native path)
# Then curl with MSYS path:
curl.exe -s -X POST http://127.0.0.1:10086/command \
  -H "Content-Type: application/json" \
  --data-binary @/c/Users/<user>/AppData/Local/Temp/wb-nav.json
```

Payload:
```json
{"action":"navigate","args":{"url":"https://www.runninghub.cn/workflow/<id>","newTab":true,"group_title":"工作流解析"},"session":"rh-wf"}
```

### 2. Wait for SPA render, then screenshot

The snapshot (accessibility tree) only shows task history and UI chrome —
the ComfyUI canvas nodes live inside an `<iframe>` that the a11y tree
doesn't expose. **Skip snapshot. Go straight to screenshot.**

```json
{"action":"screenshot","args":{},"session":"rh-wf"}
```

Returns `{format, path, sizeBytes, mimeType}`. The screenshot captures
the full viewport including the ComfyUI iframe canvas.

### 3. Analyze with vision

Feed the screenshot path to `vision_analyze` with a detailed prompt:

> 详细描述这个页面，特别关注：
> 1. 页面上半部分显示什么（标题、工具栏等）
> 2. 中间 ComfyUI 画布里有哪些节点、连线
> 3. 左侧或右侧有哪些面板/参数
> 4. 底部有什么内容
> 尽可能详细，节点名称、参数都要列出来

The vision model will identify:
- Group labels (color-coded boxes like "上传原图", "迭代放大", "SeedVR2", "输出")
- Node types and their relative positions
- Data flow (wire connections between groups)
- Preview outputs
- Parameter nodes (sliders, model selectors, sampler configs)
- UI metadata (run modes, status bar counters)

### 4. Synthesize analysis

From the vision output, reconstruct the workflow architecture:

```
[Group A] ─┬─→ [Group B] ─┬─→ [Group D]
            │              │
            └─→ [Group C] ─┘
```

Describe each group's role, node composition, and how they connect.

## Common RunningHub Workflow Patterns

### Dual-Path Restoration (Iterative + SeedVR2)

```
上传原图 ─┬─→ 迭代放大 (PixelKSampleUpscalerProvider) ─┬─→ 输出(合成)
           │                                             │
           └─→ SeedVR2 (扩散超分) ───────────────────────┘
```

Two complementary paths merge for final output:
- **迭代放大**: Structured SD img2img tile upscale; preserves layout
- **SeedVR2**: Diffusion-based denoising/super-resolution; natural textures

### Single-Path Upscale (Iterative only)

```
上传原图 → ImageScale (2x/4x) → 迭代放大 → 输出
```

Simpler variant using only PixelKSampleUpscalerProvider for structured detail enhancement.

## Pitfalls

1. **Don't try Hermes CDP first** — RunningHub needs auth cookies. CDP's headless
   profile has none. User's "用我浏览器" means WebBridge, not CDP.

2. **Don't rely on snapshot for canvas nodes** — The ComfyUI iframe content is
   invisible to the accessibility tree. Always use screenshot + vision.

3. **API calls need auth** — Direct `curl` to `/api/workflow/detail` returns
   412 TOKEN_INVALID without the user's session cookie. Only `evaluate` with
   `fetch()` from the page context works (uses the page's cookies), but
   screenshot + vision is simpler and more reliable.

4. **SPA render delay** — Wait a few seconds after navigate before screenshot.
   Vue 3 + ComfyUI iframe loading can take 3-5 seconds.

5. **`execute_code` may be blocked** — If blocked in cron mode or similar,
   fall back to `write_file` (Windows path) + `terminal` curl (MSYS path).
   The two-step pattern always works.
