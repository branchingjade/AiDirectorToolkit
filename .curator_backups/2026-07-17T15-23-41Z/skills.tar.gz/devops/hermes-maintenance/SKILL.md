---
name: hermes-maintenance
description: "Keep Hermes Agent running: diagnose ImportError after updates, restart gateway, check process state."
version: 1.1.0
platforms: [windows, linux, macos]
---

# Hermes Maintenance

Operational patterns for keeping Hermes Agent healthy — updating, restarting components, and diagnosing common post-update failures.

## Trigger

- Hermes throws `ImportError` or `AttributeError` for things that clearly exist in the source on disk
- After running `hermes update` or `git pull` in the hermes-agent repo
- Gateway responses are stale or erroring while the desktop app works fine
- **Quick health check after any fix:** see `references/quick-health-check.md` for the verification checklist

## Diagnostic: `hermes` CLI fails with uv trampoline error

**Symptom:** Every `hermes` command — even `hermes --version` — fails with:

```
error: uv trampoline failed to canonicalize script path
```

The `hermes.exe` in the venv's `Scripts/` dir is a PE32+ executable (uv-generated console-script launcher), not a plain Python script.

**Root cause:** uv's trampoline mechanism can't resolve the script path. Observed with uv 0.11.25 on Windows after updates or path changes. The venv Python itself (`venv/Scripts/python.exe`) still works fine — only the trampoline wrapper executables are affected.

**Workaround — invoke via Python directly:**

The entry point is `hermes_cli.main:main`. All CLI commands work when invoked through Python:

```bash
# Gateway restart (or any hermes subcommand)
cd ~/AppData/Local/hermes/hermes-agent
./venv/Scripts/python.exe -c "
import sys
sys.path.insert(0, r'C:\Users\<user>\AppData\Local\hermes\hermes-agent')
from hermes_cli.main import main
sys.argv = ['hermes', 'gateway', 'restart']
main()
"
```

**Pitfall:** If the Python invocation fails with `ModuleNotFoundError: No module named 'hermes'`, add `sys.path.insert(0, ...)` pointing to the hermes-agent source directory (editable install). The `__editable__.hermes_agent-*.pth` file in `venv/Lib/site-packages/` confirms the editable install but the finder may not activate for `-c` invocations.

**Permanent fix — reinstall editable package:**

The trampoline launchers are corrupted/misaligned with the venv state. A full editable reinstall rebuilds them:

```bash
cd ~/AppData/Local/hermes/hermes-agent
uv pip install -e . --reinstall
```

This also updates any stale transitive dependencies (starlette, uvicorn, etc.) that may have drifted. After this, `hermes --version` and all subcommands work normally.

**Verify the fix:**

```bash
hermes --version
hermes gateway status
```

**Pitfall: `hermes gateway restart` may exceed 30s timeout.** The command waits for the new process to fully initialize (including connecting to all messaging platforms like Feishu). The actual restart happens — check with `hermes gateway status` to confirm the new PID. For faster restarts, use:

```bash
hermes gateway stop && sleep 2 && hermes gateway start
```

**Pitfall: `hermes doctor` can hang (>15s).** Not suitable for quick triage. Use targeted checks instead:
- `hermes --version` — basic CLI health
- `hermes gateway status` — gateway liveness
- Direct Python import check for specific errors (see diagnostic above)

**Pitfall: venv rebuild race condition during desktop startup.** If the desktop bootstrap triggers a `uv sync` or venv repair, transient `ImportError` can occur on the first 1-2 backend launch attempts. The Electron boot loader has built-in retry logic — don't panic if the first launch fails. Check `desktop.log` for the pattern:
```
ImportError: cannot import name 'load_dotenv' from 'dotenv' (unknown location)
→ backend exited (1) → retrying → eventually succeeds
```

**Verify the workaround (fallback when `hermes` CLI is dead):**

```bash
./venv/Scripts/python.exe -c "
import sys; sys.path.insert(0, r'C:\Users\<user>\AppData\Local\hermes\hermes-agent')
from hermes_cli.main import main; sys.argv=['hermes','gateway','status']; main()
"
```

## Diagnostic: stale process after code update

**Symptom:** `ImportError: cannot import name 'X' from 'agent.module'` — the constant/function exists in the source file on disk but the running process can't find it.

**Root cause:** The gateway is a persistent background process. It loads Python modules once at startup. When source code is updated on disk (via `hermes update`, `git pull`, or desktop auto-update), the running gateway still holds the pre-update bytecode in memory. Restarting the desktop app does NOT restart the gateway.

**Verify:** Check if the constant exists in the source and can be imported from a fresh Python:

```bash
cd ~/AppData/Local/hermes/hermes-agent  # Windows
./venv/Scripts/python.exe -c "from agent.prompt_builder import PARALLEL_TOOL_CALL_GUIDANCE; print('OK')"
```

If that succeeds but Hermes still fails → stale gateway process.

**Fix:**

```bash
hermes gateway restart
```

If restart fails (e.g., Scheduled Task doesn't recover), try stop then start:

```bash
hermes gateway stop
hermes gateway start
```

Verify:

```bash
hermes gateway status
# Should show: ✓ Gateway process running (PID: N)
```

Then check logs for absence of the error:

```bash
grep "ImportError" ~/AppData/Local/hermes/logs/gateway.log | tail -5
```

## Gateway lifecycle

The gateway runs as a Scheduled Task (`Hermes_Gateway`) on Windows, or a systemd user service on Linux/macOS. It persists across desktop app restarts.

| Action | Command |
|--------|---------|
| Status | `hermes gateway status` |
| Start | `hermes gateway start` |
| Stop | `hermes gateway stop` |
| Restart | `hermes gateway restart` |
| Logs | `tail -f ~/AppData/Local/hermes/logs/gateway.log` |

## Diagnostic: cron jobs all fail with "config drifted"

**Symptom:** All (or most) cron jobs fail with `last_status: error`. Manual `cronjob action=run` returns:

```
RuntimeError: Skipped to prevent unintended spend: global inference config drifted since this job was created (provider 'deepseek' -> 'xiaomi'; model 'deepseek-v4-pro' -> 'mimo-v2.5-pro'), and this job is unpinned.
```

**Root cause:** The global inference config (provider/model) was changed (e.g. switching models for debugging). Cron jobs created before the change have `provider_snapshot`/`model_snapshot` frozen to the old config. When the scheduler detects the drift and the job has no explicit `model`/`provider` pinned, it blocks the run as a safety measure.

**Fix — clear snapshots permanently (recommended):**

**User preference:** Cron jobs MUST NOT pin model/provider. The user frequently switches global models for debugging. Jobs should seamlessly follow whatever the current global config is. Always clear snapshots rather than pinning.

Setting snapshots to `None` disables drift detection entirely — jobs follow the global config forever, no maintenance needed on model switches:

```python
import json
path = 'C:/Users/HMSJ/AppData/Local/hermes/cron/jobs.json'  # Windows
with open(path) as f:
    d = json.load(f)
for j in d['jobs']:
    j['provider_snapshot'] = None
    j['model_snapshot'] = None
with open(path, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
```

Verify with `cronjob action=run job_id=<any_id>` — should return `execution_success: true`.

**Alternative — update snapshots to current values (not recommended):**

If you want drift detection to remain active (blocking unexpected expensive model changes), update snapshots instead of clearing them:

```python
j['provider_snapshot'] = '<current_provider>'  # e.g. 'xiaomi'
j['model_snapshot'] = '<current_model>'         # e.g. 'mimo-v2.5-pro'
```

⚠️ This re-breaks on every future model switch.

**Pitfall:** The `cronjob action=update` API does NOT accept empty model/provider — `model=''` returns `"No updates provided"`. You must edit jobs.json directly. The API also can't clear snapshots; only direct JSON editing works.

**Pitfall:** `cronjob action=run` dispatches jobs **sequentially** (one at a time). The scheduled tick dispatches in parallel by default (`max_workers=None` = unbounded thread pool, configurable via `cron.max_parallel_jobs` or `HERMES_CRON_MAX_PARALLEL` env var). Don't judge cron speed by manual `run` — scheduled execution is much faster for multi-job batches.

**Pitfall:** jobs.json uses `id` (not `job_id`) as the key field. The `cronjob` API exposes it as `job_id` but internally it's `id`.

## MoA (Mixture of Agents) configuration & troubleshooting

MoA (`/moa`) runs reference advisors in parallel behind an aggregator model.
When it silently doesn't work, the cause is almost always one of these three:

- **Provider for reference/aggregator has no API key.** MoA's preset slots
  (`reference_models[*].provider`, `aggregator.provider`) are **not validated
  against credentialed providers**. If a preset says `openrouter` and
  `OPENROUTER_API_KEY` is missing, every MoA turn fails silently.
- **Flat keys under `moa:` are ignored when presets exist.** The legacy
  `moa.reference_models`, `moa.aggregator`, etc. are only promoted to the
  default preset when there are **no presets** at all. If `moa.presets:`
  has even one entry, every flat key under `moa:` is dead — the config
  parser never looks at them.
- **`hermes config set` can't write nested lists/dicts cleanly.**
  Schema-valid keys like `moa.presets.default.reference_models` require
  YAML sequences; the CLI serialiser can't round-trip them. The fix is
  direct YAML editing (Python `yaml.safe_load`/`yaml.dump`) as shown below.

Use `/moa <prompt>` for a single fire-and-forget MoA turn (model is
auto-restored after). Select a MoA preset from `/model` to apply it
for the whole session.

### Quick diagnosis

```bash
# 1. Check what presets exist (parsed *after* legacy promotion)
python -c "
import yaml; c=yaml.safe_load(open('$LOCALAPPDATA/hermes/config.yaml',encoding='utf-8'))
moa=c.get('moa',{})
print('presets:', list(moa.get('presets',{}).keys()))
print('default_preset:', moa.get('default_preset',''))
print('flat keys ignored:', [k for k in moa if k not in ('presets','default_preset','active_preset','save_traces','trace_dir')])
"
# 2. Check providers referenced vs credentials available
python -c "
import yaml,json
c=yaml.safe_load(open('$LOCALAPPDATA/hermes/config.yaml',encoding='utf-8'))
a=json.load(open('$LOCALAPPDATA/hermes/auth.json'))
creds=set(a.get('credential_pool',{}).keys())
for pn,p in c.get('moa',{}).get('presets',{}).items():
    ref_provs=set(r.get('provider','') for r in p.get('reference_models',[]))
    agg_prov=p.get('aggregator',{}).get('provider','')
    missing=ref_provs|{agg_prov} - creds
    if missing: print(f'  {pn}: MISSING {missing}')
    else: print(f'  {pn}: all providers credentialed ✓')
"
# 3. Available providers on this machine
python -c "
import json
a=json.load(open('$LOCALAPPDATA/hermes/auth.json'))
for p,entries in a.get('credential_pool',{}).items():
    print(f'  {p}: {len(entries)} key(s)')
"
```

### Fix recipe

```python
import yaml
path = 'C:/Users/HMSJ/AppData/Local/hermes/config.yaml'
c = yaml.safe_load(open(path, encoding='utf-8'))
moa = c.setdefault('moa', {})

# 1. Remove stray flat keys (dead — ignored when presets exist)
for stray in ['reference_models','aggregator','max_tokens','fanout','enabled']:
    moa.pop(stray, None)

# 2. Rebuild presets using ONLY providers you have keys for
presets = moa.setdefault('presets', {})
presets['default'] = {
    'enabled': True,
    'reference_models': [
        {'provider': 'deepseek', 'model': 'deepseek-v4-pro'},
        {'provider': 'xiaomi', 'model': 'mimo-v2.5-pro'},
    ],
    'aggregator': {'provider': 'deepseek', 'model': 'deepseek-v4-pro'},
    'max_tokens': 4096,
    'fanout': 'per_iteration',
}
moa['default_preset'] = 'default'
moa.pop('active_preset', None)

with open(path, 'w', encoding='utf-8') as f:
    yaml.dump(c, f, allow_unicode=True, default_flow_style=False, sort_keys=False)
```

Then `/reset` (or restart session) to pick up the change. Full details
including the config schema, legacy backward-compat rules, and the slash
command lifecycle are in `references/moa-config-deep-dive.md`.

## Browser toolset: dependency on agent-browser

The `browser` toolset (`browser_navigate`, `browser_click`, etc.) is powered by the `agent-browser` CLI (https://github.com/vercel-labs/agent-browser), installed globally via npm.

**Symptom:** `[WinError 2] 系统找不到指定的文件。` or `agent-browser: command not found` when using any browser tool.

**Root cause:** `agent-browser` is not installed, or was uninstalled. Hermes's `tools/browser_tool.py` calls `agent-browser` as a subprocess — it's not bundled with Hermes.

**Verify:**

```bash
which agent-browser
npm ls -g agent-browser
```

**Fix:**

```bash
npm install -g agent-browser
```

After install, a `/reset` (new session) may be needed for the tool to register the binary path.

**Architecture note:** `agent-browser` manages Chromium download and lifecycle. The Hermes browser tools are a Python wrapper around its CLI. Cloud backends (Browserbase, Browser Use) bypass `agent-browser` but require paid API keys (see `hermes tools` → browser plugins).

## Browser: Windows `--session` hang + CDP workaround

**Symptom:** All Hermes browser tools (`browser_navigate`, `browser_snapshot`, etc.) hang indefinitely on Windows. The agent session freezes until timeout.

**Root cause:** Hermes's `browser_tool.py` calls `agent-browser` with `--session <name>` for local mode. `agent-browser --session` spawns a daemon process that uses Unix-domain-socket IPC — this hangs on Windows (observed in every version through 0.30.1). `agent-browser` standalone (without `--session`) and `agent-browser --cdp <port>` both work fine.

**Verify the hang:**

```bash
# This hangs:
agent-browser open https://baidu.com --session test --json
```

```bash
# These work instantly:
agent-browser open https://baidu.com --json
agent-browser open https://baidu.com --cdp 9222 --json
```

**Workaround — use agent-browser directly via CDP:** Start Chrome with remote debugging, then use `agent-browser --cdp 9222` for all operations:

```bash
# 1. Start Chrome with remote debug port
"/c/Program Files/Google/Chrome/Application/chrome.exe" \
  --remote-debugging-port=9222 \
  --user-data-dir="$HOME/chrome-debug-profile" &

# 2. Verify CDP is up
curl -s http://localhost:9222/json/version | grep webSocketDebuggerUrl

# 3. Use agent-browser with --cdp (NO --session!)
agent-browser open "https://haifanwu.com" --cdp 9222 --json
agent-browser read --cdp 9222 --json
agent-browser eval "<js>" --cdp 9222 --json
agent-browser snapshot --cdp 9222 --json
```

**Impact on Hermes:** The built-in `browser` toolset is effectively broken on Windows. It always uses `--session` mode and cannot be configured to use CDP. Until agent-browser fixes the Windows session bug or Hermes adds a CDP backend option, the browser tools should remain disabled:

```bash
hermes tools disable browser
```

**Add `--headed` for visible browser (WeChat QR login, etc.):**

```bash
agent-browser open "https://haifanwu.com" --cdp 9222 --headed
# Or set AGENT_BROWSER_HEADED=true in ~/.hermes/.env
```


## Release monitoring: automated version tracking

When you need to stay informed about Hermes updates without manually checking.

### Shallow clone caveat

The hermes-agent repo at `~/AppData/Local/hermes/hermes-agent` is a **shallow clone** (depth=1). `git log HEAD..origin/main` only shows the top-level merge commit, not individual feature commits. Verify with `git rev-list --count HEAD` (returns 1). Use the **GitHub Compare API** to get the full commit list: `https://api.github.com/repos/NousResearch/hermes-agent/compare/<old_sha>...<new_sha>` → parse `commits[].commit.message`. See `cron-monitor` skill's `references/shallow-clone-github-compare.md` for details.

### Approach: LLM-driven (required) vs no_agent script (deprecated)

**LLM-driven (required):** `no_agent=False` cron job → LLM fetches releases via terminal/curl → understands, translates, and interprets content → formats Chinese report with analysis + 🔴🟡⚪ recommendation levels → delivered via normal cron delivery to Feishu DM. Advantage: handles translation, summarization, and user-specific recommendations natively. Cost: ~500-2000 output tokens per run (negligible with 98%+ caching).

**no_agent script (deprecated):** Python script fetches GitHub Releases API → regex parsing → delivery via direct platform API call. DO NOT USE for new setups. The Windows cron `subprocess.run` cannot capture stdout from Python scripts on this platform, making stdout-based delivery impossible.

### LLM-driven prompt template

```
你是 Hermes 版本简报助手。每次运行：

1. 拉取最新 releases（curl GitHub API）
2. 对比 ~/.hermes/hermes_monitor_last_tag.txt，只处理新版本
3. 输出中文简报，每条用自己的理解解释"对你意味着什么"，不是直译
4. 加推荐评级：🔴必更 🟡建议 ⚪可选
5. 跳过无关平台（Discord/Slack/Docker/Nix/macOS-only 等）和纯重构内务

用户画像：Windows 桌面，deepseek 模型，飞书网关，Hermes 桌面 GUI + TUI

输出格式用 markdown 排版但不要整篇塞进一个 ``` 代码块：
- 标题用 ##，列表用 -，重点用 **粗体**
- 分类用 emoji 标记（🔴🟡⚪）
- 末尾加 💡 升级建议

务必把所有条目翻译为中文。飞书投递，简洁有力，每条 ≤1 行。
```

### Cron job creation (LLM-driven)

```bash
cronjob action='create' \
  name='Hermes 版本简报' \
  schedule='0 9 * * 1' \
  deliver='feishu:oc_CHAT_ID' \
  no_agent=false
```

### Config: disable cron header wrapper

By default, cron deliveries wrap output with English header/footer ("Cronjob Response: ..."). Disable:

```bash
hermes config set cron.wrap_response false
```

### Filtering philosophy

Hermes releases are dense (~1000+ commits, multi-thousand-line release notes). Full delivery is noise. **Default to minimal:**

| Priority | What | When |
|----------|------|------|
| 🚨 Breaking | Regex `BREAKING\|⚠️` in list items | Always include |
| 🔒 Security | Security section items | Always include |
| 🪟 Windows | Windows section (user on Windows) | Always include |
| 📌 Relevant | Desktop, CLI/TUI, tools/MCP, Feishu | ≤2 items each |
| ⏭️ Skip | Discord/Slack/Telegram/iMessage, Docker/Nix, pure refactoring (`extracted\|reorganized\|refactor`) | Never include |

Key rules:
- ≤2 items per category, ≤120 chars per item
- Include release tagline (first bold text in body)
- Skip draft releases
- Track last seen tag in `~/.hermes/last_hermes_release.txt`

### Breaking change detection

Only items that are both (a) in a list and (b) contain `BREAKING` or `⚠️`. Filter out false positives: items with "optimization"/"only"/"default" but no "removed"/"no longer"/"must"/"break" are NOT breaking.

### Cron job template (LLM-driven)

```bash
cronjob action='create' \
  name='Hermes 版本简报' \
  schedule='0 9 * * 1' \
  deliver='feishu:oc_CHAT_ID' \
  no_agent=false
```

Set the prompt via `cronjob action='update' job_id=... prompt='...'` with the template above.

### Delivery targets

- **Feishu DM:** Use `feishu:oc_CHAT_ID` format. Find DM `oc_` chat_id by sending a test via `lark-cli --as bot im +messages-send --user-id ou_xxx --text "test"` — response includes `chat_id`.
- **Home channel:** `deliver='feishu'` (no chat_id) uses the home channel set via `/sethome`.

### Feishu formatting: markdown structure, not code block

When delivering markdown to Feishu via cron:
- ✅ Use `##` headings, `-` bullets, `**bold**`, emoji — Feishu renders these
- ❌ Do NOT wrap the entire message in ``` (triple backticks) — it becomes one monospace block
- ❌ Do NOT use box-drawing chars like `───` — Feishu may render as code
- Keep structure flat: headings → bold section labels → bullet items

### Reply channel discipline

Hermes TUI questions → answer in TUI. Feishu questions → answer in Feishu. Cron auto-push → Feishu. Never cross channels.

### Windows cron no_agent Python stdout capture failure

**Symptom:** A Python script runs correctly (debug logs confirm it detected new data, called `print()`, and updated state), but the scheduler logs `"empty stdout — silent run"` and skips delivery. `execution_success: true` but no message arrives.

**Root cause:** On Windows, the `_run_job_script` function in `cron/scheduler.py` uses `subprocess.run(capture_output=True, text=True)` with a sanitized environment. The encoding path on Windows can silently drop stdout from Python scripts — even a trivial `print("HELLO")` produces empty output. This is NOT caused by `redact_sensitive_text` (verified by adding debug-file logging before/after the print calls — the script's `print()` executes, but the parent process receives empty stdout).

**Diagnosis technique:** Add file-based debug logging inside the script (e.g., write to `~/.hermes/hermes_monitor_debug.log`) to confirm the script actually executes and detects new data. If debug logs show everything works but the scheduler says empty stdout → this bug.

**Workaround:** Don't rely on cron stdout delivery. Instead, have the script send messages directly via `lark-cli` (Feishu) or another platform-specific CLI. Set the cron job's `deliver=local` and handle delivery from within the script:

```python
import subprocess
# After generating the report, send directly
result = subprocess.run([
    'lark-cli', '--as', 'bot', 'im', '+messages-send',
    '--user-id', 'ou_xxx',  # or --chat-id oc_xxx for group
    '--text', report_text,
], capture_output=True, text=True)
```

For Feishu DM, find the user's `ou_` ID from `state.db` → `sessions` table → `user_id` column where `source='feishu'`. Then verify the DM `oc_` chat_id by sending a test message via `lark-cli` — the response includes the `chat_id` field.

**Tested delivery method:** `lark-cli --as bot im +messages-send --user-id ou_xxx --text "..."` works reliably from cron scripts and returns the `oc_` chat_id for future use.

- **Desktop restart ≠ gateway restart.** The gateway is a separate process. If you `hermes update` or the desktop auto-updates, you MUST restart the gateway separately.
- **`.pyc` cache is not the issue.** Deleting `__pycache__` won't help — the stale bytecode is in the running process's memory, not on disk. Only a process restart fixes it.
- **`sourceMode: false` in `desktop-build-stamp.json`** is normal for the desktop app build. It means the desktop was built from a specific commit, not that it's running stale code. The agent process reads from the source tree at runtime.
- **agent-browser `--session` hangs on Windows.** Do not use `--session` mode on Windows. Use `--cdp <port>` instead (see Browser section above).
