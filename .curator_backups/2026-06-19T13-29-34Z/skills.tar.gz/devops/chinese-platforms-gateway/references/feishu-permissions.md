# Feishu Application Permissions

## Required Permissions (Minimum)

| Permission | Purpose |
|------------|---------|
| `im:message` | Receive/read messages |
| `im:message:send_as_bot` | Send messages as bot |
| `im:resource` | Access user-sent images, files, audio |
| `im:chat` | Access group chat metadata |
| `im:chat:readonly` | Read group chat list and members |

## Recommended Permissions (Full Features)

| Permission | Purpose |
|------------|---------|
| `im:message.reactions:readonly` | Receive emoji reaction events |
| `admin:app.info:readonly` | Auto-detect bot identity (for @mention matching) |
| `contact:user.id:readonly` | Resolve user IDs (for allowlist matching) |

## Cloud Drive / Document Permissions

| Permission | Purpose |
|------------|---------|
| `drive:drive` | Read/write cloud drive |
| `drive:drive:readonly` | Read-only cloud drive |
| `drive:drive.member:write` | Add/remove collaborators on files/folders |
| `docs:doc:readonly` | Read-only documents |

## Event Subscriptions

| Event | Purpose |
|-------|---------|
| `im.message.receive_v1` | Receive messages (DM + group) |
| `card.action.trigger` | Interactive card button clicks |

## Quick Copy (for open platform console)

```
im:message
im:message:send_as_bot
im:resource
im:chat
im:chat:readonly
im:message.reactions:readonly
admin:app.info:readonly
contact:user.id:readonly
drive:drive
drive:drive:readonly
drive:drive.member:write
docs:doc:readonly
```

## Self-Built vs Store App Permissions

| Feature | Self-Built (自建) | Store (商店) |
|---------|------------------|-------------|
| Permission approval | Developer console → create version → admin review | User clicks applink authorization |
| One-click auth link | ❌ Not supported | ✅ `cob_store_apply_token` mini-program |
| Use case | Internal enterprise | External distribution |
| Review flow | Tenant admin only | Feishu platform + tenant admin |
