# 读取超长飞书文档

## 问题
`get_feishu_document_blocks` 返回的 JSON 对于大型文档（100+ block）会被截断（600K+ chars），导致无法提取完整内容。

## 解决方案：浏览器控制台提取

1. 用 `browser_navigate` 打开飞书文档 URL（支持 `larkoffice.com` 公开链接）
2. 用 `browser_console` 执行 `document.body.innerText.substring(0, 8000)` 分段提取文本
3. 公开文档无需登录即可读取

```javascript
// 分段提取，每次 8000 字符
document.body.innerText.substring(0, 8000)   // 第一段
document.body.innerText.substring(8000, 16000) // 第二段
```

## 注意事项
- 飞书文档 TOC 侧边栏的锚点链接在公开预览模式下**不可靠**（点击后可能不滚动到对应章节）
- 公开文档有水印（"访客 XXXXX"），但不影响内容读取
- `document.body.innerText` 包含 TOC 侧边栏文字 + 正文内容，正文在 TOC 之后
- 如果只需要特定章节，先通过 TOC 文字定位偏移量，再提取对应区间
