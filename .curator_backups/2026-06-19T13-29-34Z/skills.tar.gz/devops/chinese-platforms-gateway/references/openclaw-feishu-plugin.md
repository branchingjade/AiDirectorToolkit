# OpenClaw 飞书官方插件安装

OpenClaw 是飞书上的 AI 编程助手，官方插件文档：https://bytedance.larkoffice.com/docx/MFK7dDFLFoVlOGxWCv5cTXKmnMh

## 前置依赖

- OpenClaw 本体已安装（Linux/MacOS: 2026.2.26+, Windows: 2026.3.2+）
- **关键：`openclaw` 命令必须在 PATH 中**（不能只靠 `npx openclaw`）

## 安装步骤

### 1. 确保 openclaw 全局可用

```bash
# 检查是否在 PATH
which openclaw

# 如果不在 PATH，全局安装
npm install -g openclaw

# 验证
openclaw --version
```

**常见坑：** `npx openclaw --version` 能工作不代表 `openclaw` 在 PATH 中。lark 插件安装器直接调用 `openclaw` 命令，不走 npx。

### 2. 安装飞书插件

```bash
npx -y @larksuite/openclaw-lark install
```

### 3. 扫码配置机器人

安装过程会显示一个**飞书二维码**，需要用飞书 App 扫描来配置机器人。

**⚠️ 代理/远程场景：** 终端中的二维码无法通过飞书消息传递给用户。用户需要**在自己的终端中手动执行**安装命令，然后用飞书 App 扫描。

### 4. 补装 feishu 插件

安装 openclaw-lark 后通常会有配置警告，需要额外安装：
```bash
openclaw plugins install @openclaw/feishu
```

验证两个插件都为 `enabled`：
```bash
openclaw plugins list
```

### 5. 启动 OpenClaw 网关

OpenClaw 网关独立于 Hermes：
```bash
openclaw gateway start      # 启动（Scheduled Task）
openclaw gateway health     # 检查健康状态
openclaw status             # 完整状态（频道、会话等）
```

### 6. 访问 Dashboard

OpenClaw Web Dashboard：`http://127.0.0.1:18789/`

认证需要 gateway token：
```bash
# 获取完整 token（config get 会脱敏）
cat ~/.openclaw/openclaw.json | python3 -c "import sys,json; print(json.load(sys.stdin)['gateway']['auth']['token'])"
```

在 Dashboard 登录页输入 token → 点击「连接」。

## 更新插件

```bash
npx -y @larksuite/openclaw-lark install
```

会自动检测已安装版本并升级。

## 常见问题

| 问题 | 原因 | 解决 |
|------|------|------|
| `OpenClaw is not installed or not in PATH` | openclaw 不在 PATH | `npm install -g openclaw` |
| 扫码超时 | 用户未扫描二维码 | 用户在自己终端执行命令并扫码 |
| 群消息不回复 (4.27+) | 版本升级后配置变化 | 参考官方文档 FAQ |
| `Cannot find module '@larksuiteoapi/node-sdk'` | 依赖未安装 | 重新执行安装命令 |
