# 知识库每日维护 Cron 脚本

> 2026-07-01 验证通过。在 Hermes cron 环境下执行，无用户交互。

## 前置条件

- `~/Documents/KnowledgeBase` 已 clone 且 git remote 配置正确
- `~/AppData/Local/hermes/memories/MEMORY.md` 和 `USER.md` 存在
- Shell 为 git-bash/MSYS（Windows 环境）

## 执行步骤

### 1. 同步 Hermes 记忆到 Vault

```bash
# ⚠️ 必须用 /bin/cp 绕过 MSYS cp -i 别名
mkdir -p "$HOME/Documents/KnowledgeBase/Obsidian Vault/_hermes/memory"
/bin/cp "$HOME/AppData/Local/hermes/memories/MEMORY.md" \
        "$HOME/Documents/KnowledgeBase/Obsidian Vault/_hermes/memory/MEMORY.md"
/bin/cp "$HOME/AppData/Local/hermes/memories/USER.md" \
        "$HOME/Documents/KnowledgeBase/Obsidian Vault/_hermes/memory/USER.md"
```

### 2. Git 提交

```bash
cd "$HOME/Documents/KnowledgeBase"
git status --short
# 有变更则：
git add -A && git commit -m "chore: 每日自动提交 — 同步 Hermes 记忆/画像" && git push
```

### 3. 悬空 Wikilink 检测

```bash
cd "$HOME/Documents/KnowledgeBase/Obsidian Vault"

# 提取所有 wikilink 目标名
grep -roh '\[\[[^]]*\]\]' --include='*.md' --exclude-dir='.obsidian' . | \
  sed 's/\[\[//;s/\]\]//;s/#.*//;s/|.*//' | sort -u > /tmp/wikilinks.txt

# 列出所有 .md 文件名（不含路径和扩展名）
find . -name '*.md' -not -path './.obsidian/*' | \
  sed 's|.*/||; s|\.md$||' | sort -u > /tmp/md_files.txt

# 对比：wikilink 中有但 .md 文件中没有的 → 可能是悬空链接
# 注意：需人工排除 `...`（语法示例）和空行等误报
while IFS= read -r link; do
  found=$(find . -name "${link##*/}.md" -not -path './.obsidian/*' 2>/dev/null)
  if [ -z "$found" ]; then
    echo "DANGLING: $link"
  fi
done < /tmp/wikilinks.txt
```

### 4. Vault 根目录检查

```bash
cd "$HOME/Documents/KnowledgeBase/Obsidian Vault"
# MOC.md 在根目录是正常的，其他 .md 需要归位
ls *.md 2>/dev/null
```

## 已知误报

| 模式 | 来源 | 处理 |
|------|------|------|
| `...` | 笔记中展示 wikilink 语法的示例 `[[...]]` | 忽略 |
| 空行 | grep 提取 artifact | 忽略 |
| 含 `/` 的 wikilink | `[[子目录/笔记名]]` — 实际指向子目录中的文件 | 用 `${link##*/}` 取文件名后匹配 |
