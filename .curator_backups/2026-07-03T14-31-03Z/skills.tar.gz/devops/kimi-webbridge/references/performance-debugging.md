# 网页性能诊断：完整四层排查法

## 背景

RunningHub 画布卡顿的完整诊断过程——从图片优化 → CSS 优化 → 长任务检测 → CPU Profile，最终定位到 Vue 虚拟 DOM 在大规模画布上的主线程阻塞。

## 层级 1：图片渲染过载

七牛 CDN 的 `imageMogr2` 支持在 URL 上追加参数实现实时图像处理。诊断：

```js
// 统计图片加载情况
(() => {
  const imgs = document.querySelectorAll('img');
  const groups = {};
  imgs.forEach(img => {
    const src = img.src;
    if (src.includes('imageMogr2')) groups.mogr2 = (groups.mogr2||0)+1;
    else if (src.includes('xiaoyaoyou.com')) groups.raw = (groups.raw||0)+1;
    else if (src.startsWith('data:')) groups.dataUri = (groups.dataUri||0)+1;
  });
  const mem = performance.memory || {};
  return JSON.stringify({...groups, heapMB: (mem.usedJSHeapSize/1024/1024).toFixed(1)});
})()
```

修复：对七牛 CDN 图片 URL 追加 `thumbnail/300x/format/webp` 参数。

## 层级 2：DOM 节点过载

图片优化后仍卡→排查 DOM 规模。RunningHub 的 Vue Flow 画布不虚拟化，所有节点留在 DOM。

```js
(() => {
  const nodes = document.querySelectorAll('.vue-flow__node, .react-flow__node');
  const vh = window.innerHeight, vw = window.innerWidth;
  let visible = 0, offscreen = 0;
  nodes.forEach(n => {
    const r = n.getBoundingClientRect();
    (r.bottom > 0 && r.top < vh && r.right > 0 && r.left < vw) ? visible++ : offscreen++;
  });
  return JSON.stringify({
    totalNodes: nodes.length, domElements: document.querySelectorAll('*').length,
    visible, offscreen, heapMB: (performance.memory.usedJSHeapSize/1024/1024).toFixed(1)
  });
})()
```

CSS 缓解：`content-visibility: auto` + `contain: strict` 跳过屏外节点渲染。

## 层级 3：空闲帧率 vs 交互帧率

`requestAnimationFrame` 计数器区分空闲/交互性能：

```js
let frames=0, start=performance.now();
(function tick(){frames++; if(performance.now()-start<2000) requestAnimationFrame(tick);
  else console.log('FPS:', frames/(performance.now()-start)*1000);})()
```

RunningHub 空闲 60fps，交互时大量长任务——问题在 JS 主线程，不是渲染管线。

## 层级 4：PerformanceObserver 长任务检测 ⭐

这是关键转折点——发现卡顿是真·JS 阻塞而非渲染开销：

```js
window.__wbPerfLog = [];
const observer = new PerformanceObserver((list) => {
  for (const e of list.getEntries()) {
    window.__wbPerfLog.push({type: e.entryType, duration: Math.round(e.duration),
      startTime: Math.round(e.startTime), name: e.name?.substring(0,40)});
  }
});
observer.observe({ entryTypes: ['longtask', 'layout-shift'] });
// ... 用户交互 3 秒后 ...
JSON.stringify(window.__wbPerfLog)
```

RunningHub 实测：连续 16 秒、58 个长任务（150-350ms），全部是 `"self"`（JS 执行，非 layout/paint）。

## 层级 5：CDP CPU Profiler 定位热函数 ⭐

用 WebBridge 的 `cdp` 工具启动 Chrome Profiler，抓交互期间的调用栈：

```
# Step 1: Enable + Start
{"action":"cdp","args":{"method":"Profiler.enable"}}
{"action":"cdp","args":{"method":"Profiler.start"}}
# ... 用户交互 3 秒 ...
# Step 2: Stop + 解析
{"action":"cdp","args":{"method":"Profiler.stop"}}
```

返回的 `profile` 含 `samples`（采样点 node ID 序列）+ `timeDeltas`（采样间隔微秒数）+ `nodes`（函数调用帧）。聚合分析脚本：

```python
func_hits = {}
for i, node_id in enumerate(samples):
    if i < len(timeDeltas):
        node = nodes[node_id] if node_id < len(nodes) else {}
        name = node.get("callFrame", {}).get("functionName", "(anon)") or "(anon)"
        func_hits.setdefault(name, {"time":0,"count":0})
        func_hits[name]["time"] += timeDeltas[i]
        func_hits[name]["count"] += 1
# Sort by time descending
top = sorted(func_hits.items(), key=lambda x: x[1]["time"], reverse=True)[:25]
```

### ⚠️ 关键教训：注入脚本会干扰 Profiler 结果

**第一次 Profiler（注入后页面）**结果：

| 占比 | 函数 | 说明 |
|------|------|------|
| 10.0% | `ne` (patch) | Vue 虚拟 DOM diff |
| 5.7% | `patchProp` | 属性补丁 |
| 4.3% | `insertBefore`+`insert` | DOM 插入——**这是注入 img.src 改写导致的** |

改 `img.src` 触发 Vue 重建节点，`insertBefore` 是我们自己制造的。

**第二次 Profiler（纯净页面）**结果才是真根因：

| 占比 | 函数 | 说明 |
|------|------|------|
| 7.9% | `track` | Vue 响应式依赖追踪 |
| 6.8% | `get`/`get value` | 响应式属性读取 |
| 1.6% | `notify` | 响应式变更通知 |
| 0.5% | `setLocalState` | Flow 内部状态 |

**最终结论**：交互时 Vue 响应式系统（`track`+`get`+`notify`）占  **16.3%** 主线程。每次缩放/拖拽，React Flow 更新状态 → Vue 遍历 546 个节点的 watcher/computed 做依赖追踪 → 重渲染。这是 **O(n) 响应式开销**，节点越多越卡。客户端可用的缓解手段是 RAF 30fps 限帧（见下节），根治需 RunningHub 用 `markRaw`/`shallowRef` 隔离画布节点。

> **规则：性能诊断必须先跑纯净页面 Profiler，再跑注入后页面做对照。注入脚本（改 src/改 DOM/加 style）会污染热函数排名。**

## 综合诊断结论

| 层级 | 发现 | 修复方式 | 效果 |
|------|------|---------|------|
| 图片 | 七牛 CDN 缺缩略参数 | DOM 改 src 触发重渲染 → 不可取 | 仅省 ~17MB |
| 图片 | 同上 | `declarativeNetRequest` 网络层重写 URL | 不走主线程 ✅ |
| DOM | 546 节点不虚拟化 | `content-visibility: auto` | 缓解 |
| 帧率 | 空闲 60fps，交互卡 | 不是 GPU 问题 | — |
| 长任务 | 58 个 150-350ms 任务 | 确认 JS 阻塞 | — |
| CPU Profile | **Vue track+get+notify 占 16.3%** | 需 RunningHub 修 | 根因 |

### 客户端缓解：RAF 30fps 限帧

```js
(() => {
  const origRAF = window.requestAnimationFrame;
  let lastRAF = 0;
  window.requestAnimationFrame = function(cb) {
    const now = performance.now();
    if (now - lastRAF < 32) return 0; // ~30fps
    lastRAF = now;
    return origRAF.call(window, cb);
  };
})()
```

效果有限——每次帧的 Vue 响应式计算量不变，但减少了一半帧数。

## qiniu imageMogr2 参数速查

| 参数 | 作用 |
|------|------|
| `thumbnail/300x` | 限定宽度 300px |
| `thumbnail/!30p` | 缩放到原图 30% |
| `format/webp` | 转为 WebP |
| `ignore-error/1` | 处理失败返回原图 |
