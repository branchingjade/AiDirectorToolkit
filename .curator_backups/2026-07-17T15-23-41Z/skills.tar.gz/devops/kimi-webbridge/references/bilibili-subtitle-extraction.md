# Bilibili 视频字幕提取

通过 Kimi WebBridge 在用户已登录的浏览器中提取 B 站视频 AI 字幕。

## 背景

B 站视频字幕 API（`player/v2`）对未登录请求返回空 `subtitles` 数组，且 `subtitle_url` 为空字符串。即使用 `yt-dlp --cookies-from-browser` 也会因 Chrome cookie 数据库锁定而失败。但通过 WebBridge 在用户浏览器内发起 fetch（继承登录 cookie），`player/wbi/v2` 端点会返回带 `auth_key` 的完整字幕 URL。

## 工作流

### 1. 打开视频页

```json
{"action":"navigate","args":{"url":"https://www.bilibili.com/video/BV.../","newTab":true,"group_title":"B站视频"},"session":"bilibili-sub"}
```

### 2. 在浏览器内调用 wbi/v2 端点获取字幕 URL

**关键**：必须用 `player/wbi/v2`（不是 `player/v2`），且 `fetch` 在页面上下文中执行以携带 cookie。

```js
fetch('https://api.bilibili.com/x/player/wbi/v2?bvid=<BV_ID>&cid=<CID>', {credentials: 'include'})
  .then(r => r.json())
  .then(d => d.data.subtitle.subtitles)
```

返回的每个字幕对象包含 `subtitle_url`（带 `auth_key` 的 CDN 地址）。

### 3. 获取字幕 JSON

AI 字幕 URL 格式：`//aisubtitle.hdslb.com/bfs/ai_subtitle/prod/<aid><cid><hash>?auth_key=...`

补上 `https:` 前缀后用 curl 拉取：

```bash
curl -s "https://aisubtitle.hdslb.com/bfs/ai_subtitle/prod/..." \
  -H "User-Agent: Mozilla/5.0" \
  -H "Referer: https://www.bilibili.com"
```

### 4. 解析

```python
import json, sys
data = json.load(sys.stdin)
for item in data['body']:
    print(f"[{item['from']:.1f}s-{item['to']:.1f}s] {item['content']}")
```

## 字幕类型

| type | 说明 |
|------|------|
| 0 | 用户上传/CC 字幕（`aisubtitle.hdslb.com/bfs/subtitle/`） |
| 1 | AI 自动生成字幕（`aisubtitle.hdslb.com/bfs/ai_subtitle/prod/`） |

多数视频有 AI 字幕（type=1, lan="ai-zh"），优先使用。

## CID 获取

视频信息 API（无需登录）返回 `cid`：

```bash
curl -s -H "User-Agent: Googlebot/2.1" \
  "https://api.bilibili.com/x/web-interface/view?bvid=<BV_ID>"
```

## 陷阱

- `player/v2` 端点不返回 `subtitle_url`，必须用 `player/wbi/v2`
- 字幕 CDN 直接 curl 是 403，需要 URL 里附带的 `auth_key` 参数
- `yt-dlp` 的 `--cookies-from-browser` 在 Windows 上大概率失败（Chrome DB 锁定）
- 浏览器 CDP profile（未登录）的 fetch 同样返回空 subtitles——必须走 WebBridge（用户主浏览器）
