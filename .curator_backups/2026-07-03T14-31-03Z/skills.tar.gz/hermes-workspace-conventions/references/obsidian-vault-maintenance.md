# Obsidian Vault 维护约定

> 知识库路径：`C:\Users\HMSJ\Documents\KnowledgeBase\Obsidian Vault\`
> Git 仓库：`branchingjade/knowledge-base`（私有）
> 版本：master 唯一主分支

## 架构

```
Obsidian Vault/
├── MOC.md                     # 总索引，[[wikilinks]] 链接所有子目录
├── _hermes/                    # Hermes 配置、运维、方法论
├── 技术/                       # 通用技术笔记，按主题分子目录
├── <项目名>/                   # 项目产出（犬子无双/ 等）
└── 日志/                       # 按日期归档的会话总结
```

## 笔记规范

### Frontmatter（每篇必加）

```yaml
---
tags: [tag1, tag2, tag3]
date: YYYY-MM-DD
related: [[笔记A]] · [[笔记B]]      # 可选，双向链接
---
```

### [[wikilinks]]

- 目录内互链：`[[笔记名]]`（不含路径）
- 跨目录：`[[子目录/笔记名]]`
- MOC 必须链接所有活跃笔记

### 文件命名

- 中文名，简洁（去掉冒号、日期前缀等）
- 例：`备份迁移.md` 而非 `Hermes备份迁移记录.md`

## 维护节奏

- 每次完成技术决策/排查/迁移/配置变更后 → 同步写一篇笔记
- 笔记写完即 `git commit` + `git push`
- 发现过时内容 → 就地更新 frontmatter `date` 和内容

## 目录规则

| 目录 | 放什么 | 不放什么 |
|------|--------|---------|
| `_hermes/` | Hermes 自身的配置、运维、方法论 | 项目产出 |
| `技术/` | 通用技术研究、工具对比、踩坑 | Hermes 专属内容 |
| `<项目>/` | 项目产出（调色分析、剧本等） | 跨项目通用 |
| `日志/` | 按日期归档的会话总结 | 技术笔记 |

## Git 工作流

```bash
cd ~/Documents/KnowledgeBase
git add -A
git commit -m "<type>: <描述>"
git push
```

- type：`docs`（新笔记）、`refactor`（重组架构）、`fix`（更正过时内容）
- 单分支 `master`，不分支开发
