# RunningHub 性能诊断案例 (2026-06-26)

## 问题
用户在 RunningHub (rhtv.runninghub.ai) 节点式画布上操作（缩放/拖拽）时严重卡顿。

## 诊断路径

### 第一阶段：图片优化（偏了）
- 发现 143 张图片，44 张为 4K-5.5K 原图当缩略图用
- CDN 为七牛 `imageMogr2`，支持实时缩略但 RunningHub 没加参数
- 注入脚本：`img.src` 加 `imageMogr2/thumbnail/300x/format/webp`
- **结果**：省 17MB 内存，但流畅度无明显改善

### 第二阶段：CSS/GPU 优化（偏了）
- `content-visibility: auto`、`contain: strict`、kill backdrop-filter/box-shadow
- 强制 GPU 合成（`will-change: transform`、`translateZ(0)`）
- **结果**：`contain: strict` 导致节点消失，其余边际改善

### 第三阶段：事件节流（边际）
- RAF 降到 30fps、pointermove/wheel throttle
- **结果**：用户反馈"好一点"，但不解决根本问题

### 第四阶段：CPU Profiling（找到根因）

#### 方法
1. `cdp` → `Profiler.enable` → `Profiler.start`
2. 用户交互 3-5 秒
3. `Profiler.stop` → 按 timeDeltas 聚合函数调用

#### 纯净页面 Profile 结果
| 函数 | 占比 | 说明 |
|------|------|------|
| `track` | 7.9% | Vue 响应式依赖追踪 |
| `get` / `get value` | 6.8% | 响应式 getter |
| `notify` | 1.6% | 响应式通知 |
| **合计** | **16.3%** | 主线程被 Vue 响应式占满 |

#### PerformanceObserver 长任务
连续 16 秒 58 个长任务，每个 150-350ms，类型均为 `"self"`（JS 执行）。

#### 注入脚本对比
注入改 `img.src` 后出现 `insertBefore`(2.8%) + `insert`(1.5%)——DOM 操作因图片换源触发重渲染，加重卡顿。

### 根因
**Vue 3.5.13 响应式系统在 546 个 Vue Flow 节点上的 O(n) 开销。**

交互时的链式反应：
```
pointermove → Vue Flow setLocalState → Vue track() 遍历 546 节点
    → getter 重算 → notify 通知 → 重渲染 → 主线程阻塞 150-350ms
```

## 客户端可行方案（渐进式）

1. **图片缩略**（省内存，不解决卡顿）
2. **RAF 30fps 节流**（边际改善）
3. **declarativeNetRequest 缓存**（加速首屏，不影响交互流畅度）
   - 250 个资源全部走网络（0 缓存），主 bundle 3.3MB 每次都重下
   - `modifyHeaders` + `Cache-Control` 可强制缓存 JS/CSS/字体
   - 但不能缓存 API 请求——会导致数据过期
4. **本地代理 patch bundle**（已实现框架，rh-proxy）：
   - Python 代理服务器（`localhost:9999`）拦截 `_nuxt/*.js`
   - 下载原始 bundle → regex patch → 缓存 → 返回修补版
   - DNR 规则将 runninghub.ai 的 JS 请求重定向到代理
   - 需启用 `chrome://flags/#allow-insecure-localhost`
   - 首个 patch：`track(e){if(window.__wb_skip_track||!ke)...}`（可控跳过响应式）
   - 代码位置：`~/Documents/Hermes/Projects/rh-proxy/proxy.py`
   - 配套扩展：`%TEMP%/rh-proxy-ext/`（DNR 重定向规则）

### Bundle 逆向分析

- `addNodes` 在位置 2645353：`NFe(e)` 包装每个节点（非响应式包装，而是 change event 包装）
- `NFe` 定义：`function NFe(e){return{item:e,type:"add"}}`（仅事件包装）
- 真正的响应式入口在 `e.nodes`（Vue Flow 的 `ref([])`），赋值处：`p=t=>{...e.nodes=gHe(n,a,e.hooks.error.trigger)}`
- `nodes.value` 6 次引用，`updateNode` 31 次
- `markRaw` 0 次使用——RunningHub 完全没有对节点做响应式隔离

## 关键数据点

- Framework: Nuxt (Vue 3.5.13 SSR)
- Main bundle: `_nuxt/DHNn5kIh.js` (3.3MB)
- App root: `#appVue`
- Flow library: Vue Flow (58 occurrences in bundle)
- CDN: `*.xiaoyaoyou.com` (七牛 imageMogr2)
