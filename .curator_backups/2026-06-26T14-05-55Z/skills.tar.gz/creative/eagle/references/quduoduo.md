# 曲多多（haifanwu.com）平台说明

## 平台身份

- haifanwu.com = 曲多多 = 嗨翻屋，同一平台
- Eagle 中版权音乐文件名格式：`曲多多_<数字ID>_<英文名>.wav`
- 平台用数字 ID 标识曲目（如 `4776764`）
- 站点是 **Nuxt 2.x SPA**，路由见 `window.$nuxt.$router.options.routes`

## 提取元数据：CDP 浏览器方案（可行✓）

### 路由
曲目详情页路由为 `/song-detail/:id`，通过 Nuxt router 导航：

```javascript
// browser_console 中执行
window.$nuxt.$router.push('/song-detail/4776972')
```

URL 导航（hash、query）不生效，必须走 router。

### 可提取的字段

| 字段 | 页面位置 | 示例 |
|------|---------|------|
| BPM | 标题下方 | `BPM:103` |
| 时长 | 播放器 | `03:09` |
| 表演者 | 歌曲基本信息 | Charlotte Jones |
| 作曲 | 歌曲基本信息 | Charlotte Jones |
| 所属专辑 | 歌曲基本信息 | 云走得慢的地方 |
| 所属曲库 | 歌曲基本信息 | 特价曲库 |
| 使用场景 | 标签区 | 自媒体/短视频, 影视配乐 |
| 流派 | 标签区 | 轻音乐(Easy Listening) |
| 情绪 | 标签区 | 怀念/回忆, 悲伤(Sad) |
| 特征 | 标签区 | 舒缓 |
| 器乐 | 标签区 | 弦乐, 钢琴 |
| 关键词 | 标签区 | 海峰音乐 |

### 提取 JS（browser_console 运行）

```javascript
(function(){
var text=document.body.innerText;
var lines=text.split('\n').map(l=>l.trim());
var infoIdx=lines.lastIndexOf('歌曲基本信息');
var durMatch=text.match(/(\d{2}:\d{2})/);
var fields=['所属曲库','表演者','作词','作曲','歌词','所属专辑'];
var values={};
for(var j=infoIdx;j<Math.min(infoIdx+25,lines.length);j++){
    var l=lines[j];
    for(var f=0;f<fields.length;f++){
        if(l===fields[f]+'：'||l===fields[f]+':'){
            var vals=[];
            for(var k=j+1;k<lines.length;k++){
                var nl=lines[k];
                if(nl=='查看专辑'||nl=='歌曲标签')break;
                if(nl.indexOf('：')>0||nl.indexOf(':')>0)break;
                if(nl&&nl!=='-')vals.push(nl);
            }
            values[fields[f]]=vals.join('; ');
        }
    }
}
var sections={使用场景:[],流派:[],情绪:[],特征:[],器乐:[],关键词:[]};
var current=null;
for(var m=infoIdx;m<lines.length;m++){
    var line=lines[m];
    if(line=='我们的优势')break;
    if(sections.hasOwnProperty(line)){current=line;continue;}
    if(current&&line&&line!=='查看专辑'&&line!=='歌曲标签'){
        var isF=false;
        for(var n=0;n<fields.length;n++){if(line===fields[n]+'：'||line===fields[n]+':'){isF=true;break;}}
        if(!isF)sections[current].push(line);
    }
}
var d={duration:durMatch?durMatch[1]:'',performer:values['表演者']||'',composer:values['作曲']||'',
  album:values['所属专辑']||'',libraries:values['所属曲库']||'',tags:{}};
for(var s in sections){if(sections[s].length)d.tags[s]=sections[s].join('; ');}
return JSON.stringify(d);
})()
```

### 批量提取流程

1. `browser_navigate` 到 haifanwu.com 首页，**用 JS 检测登录态**（不要凭快照文字）
2. 从 Eagle 获取待处理曲目 ID 列表
3. **直接 SSR 导航**：`browser_navigate` → `https://haifanwu.com/song-detail/<ID>`（每首 ~2 秒）
4. `browser_console` 运行提取 JS
5. 写入 Eagle 用 `execute_code` + Python urllib
6. 默认串行，≤20 首不用子 agent

### 已验证的速度（实测）

- SSR 直链导航：每首 ~2 秒（连续 3 首全部成功）
- Nuxt router.push：不稳定，多次调用后需回首页重置，平均 ~5-8 秒

### 回写 Eagle（必须 Python，禁止 shell curl）

Shell curl 传中文会损坏编码。用 `execute_code` + Python `urllib.request`：

```python
import json, urllib.request

payload = json.dumps({
    "id": "<EAGLE_ITEM_ID>",
    "tags": ["版权音乐","曲多多","haifanwu"] + tag_list,
    "annotation": "表演者: xxx\n作曲: xxx\n专辑: xxx\n...",
    "url": "https://haifanwu.com/#/song-detail/<TRACK_ID>"
}, ensure_ascii=False).encode('utf-8')

req = urllib.request.Request("http://localhost:41595/api/item/update",
    data=payload, headers={'Content-Type': 'application/json; charset=utf-8'})
```

## 不可行的方式（已验证）

| 方式 | 结果 |
|------|------|
| `curl` API 直调 | 阿里云 WAF 返回 JS 挑战页 |
| URL hash 路由 `/#/music/<ID>` | SPA 不识别 |
| 搜索框程序化输入+提交 | SPA 事件不触发 |
| 浏览器 `fetch` API（跨域） | WAF 拦截 |

**注意**：`browser_navigate` 到完整 SSR URL（`/song-detail/<ID>`）是可行的——这走服务端渲染，不是 hash/query 路由。
