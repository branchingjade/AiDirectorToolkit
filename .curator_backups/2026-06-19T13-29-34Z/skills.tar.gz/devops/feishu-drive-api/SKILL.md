---
name: feishu-drive-api
description: "飞书云盘 API 操作：文件夹权限管理、协作者添加、token 获取。涵盖常见坑点和最佳实践。"
version: 1.0.0
author: hermes-agent
tags: [feishu, lark, drive, api, permissions, collaboration]
platforms: [windows, linux, macos]
metadata:
  hermes:
    tags: [feishu, drive, api]
---

# 飞书云盘 API 操作指南

## 关键限制

### 文件夹不能直接添加应用为协作者
飞书官方文档明确说明：**不支持将应用直接添加到文件夹作为协作者（添加成功后实际仍然没有权限）**。

### 授权方式（按可靠性排序）

**方式一：直接分享给应用（推荐，但飞书客户端可能不支持搜索应用）**
在飞书客户端打开文件夹 → 分享 → 搜索应用名称 → 设置权限

**方式二：通过群组间接授权（不稳定，实测可能无效）**
1. 创建一个飞书群
2. 将应用作为**群机器人**添加到群内
3. 将文件夹分享给该群，权限设置为「可管理」
4. 应用可通过 `tenant_access_token` 访问文件夹

⚠️ **Pitfall**：用户实测反馈「群权限根本没用」。群组授权方式在某些情况下无法让应用获得文件夹的实际访问权（API 返回 403）。如果群组方式无效，需要使用方式三。

**方式三：使用 user_access_token（以用户身份操作，最可靠）**
通过 Feishu-MCP 的 `FEISHU_AUTH_TYPE=user` 模式，以用户身份访问文件夹。需要 OAuth 授权流程。详见 `references/user-auth-mode.md`。

### 添加协作者 API 的额外限制
即使应用通过群组获得了文件夹访问权，调用 `POST /drive/v1/permissions/:token/members` 仍可能返回 `1063002 Permission denied`。

这是因为该 API 需要调用身份有**添加协作者**的权限，而非仅仅是阅读/编辑权限。需要在文件夹的权限设置中调整「谁可以添加协作者」选项。

## 方案二：OAuth user_access_token（推荐）

群组授权方案受限——无法添加协作者，且部分操作仍被拒。更可靠的方式是用 **user_access_token**（以用户身份操作）。

### 配置步骤

1. **修改 Hermes config.yaml** 中 Feishu-MCP 的环境变量：
   ```yaml
   mcp_servers:
     feishu-mcp:
       env:
         FEISHU_AUTH_TYPE: user          # 改 tenant → user
         FEISHU_APP_SECRET: <your_secret> # user 模式必须有 secret
   ```

2. **飞书开放平台配置重定向 URL**：
   - 打开 https://open.feishu.cn/app/<app_id>
   - 左侧「安全设置」→「重定向 URL」→ 添加 `http://localhost:3333/callback`

3. **重启网关** → 调用任意 Feishu-MCP 工具 → 返回授权链接 → 用户在浏览器完成授权

4. token 缓存在 `~/.cache/feishu-mcp/user_token_cache.json`，支持自动刷新。

### 注意事项
- `offline_access` scope 必须包含，否则 refresh_token 不下发
- Feishu-MCP 在 stdio 模式下也会启动 localhost:3333 用于 OAuth 回调
- 飞书管理后台的重定向 URL 必须与回调地址完全一致

## 文件夹/文档访问权限的根本解法

### tenant_access_token 的权限天花板
`tenant_access_token`（应用身份）访问文件夹受限于：
- 文件夹必须通过群组间接授权给应用
- 添加协作者 API 需要文件夹「谁可以添加协作者」=「所有可阅读的人」
- 某些操作即使有权限也会 403

### ✅ 根本解法：切换到 user 模式（OAuth）
Feishu-MCP 支持 `user` 模式，以**用户身份**操作，权限等同于用户本人。

**配置步骤：**

1. **修改 `~/.hermes/config.yaml`** — mcp_servers.feishu-mcp.env 部分：
   ```yaml
   env:
     FEISHU_APP_ID: cli_xxx
     FEISHU_APP_SECRET: xxx          # 必须加上，user 模式需要
     FEISHU_AUTH_TYPE: user           # 从 tenant 改为 user
     FEISHU_BASE_URL: https://open.feishu.cn/open-apis
     FEISHU_ENABLED_MODULES: document,drive
   ```

2. **飞书开放平台配置重定向 URL**：
   - 打开 https://open.feishu.cn/app/<app_id>
   - 安全设置 → 重定向 URL → 添加 `http://localhost:3333/callback`

3. **重启网关**：`hermes gateway restart`（从外部终端）

4. **完成 OAuth 授权**：
   - 调用任意 Feishu-MCP 工具，会返回授权链接
   - 在浏览器打开链接 → 飞书授权页面点「授权」
   - 跳转到 localhost:3333/callback 显示「授权成功」
   - Token 自动缓存到 `~/.cache/feishu-mcp/user_token_cache.json`

**Pitfalls：**
- 切换 auth type 后**必须**重启网关，否则 MCP 进程仍用旧配置
- **网关缓存 config.yaml**：网关进程启动时读取 config.yaml 并缓存在内存中。修改 config.yaml 后，网关 spawn 的 MCP 子进程仍然使用旧环境变量。**必须从外部终端运行 `hermes gateway restart`**，在网关内部运行会被拒绝（"Refusing to restart the gateway from inside the gateway process"）
- **App Secret 不一致**：config.yaml 的 `env.FEISHU_APP_SECRET` 和 Feishu-MCP 工作目录的 `.env` 文件可能有不同的值。MCP 优先读 config.yaml env（通过 Hermes 传入），dotenv 不覆盖已有环境变量。如果授权时返回 `invalid_client`（错误码 20002），说明 secret 错误——对比 config.yaml 和 `.env` 文件中的值
- `FEISHU_APP_SECRET` 在 tenant 模式下可省略，user 模式下**必须配置**
- 授权后首次调用可能仍需几秒，等 token 写入缓存
- Token 有有效期，Feishu-MCP 支持自动刷新（需 offline_access scope）
- **终端截断 base64**：长 base64 字符串在终端输出中会被插入 `...` 截断显示，这不是实际内容的一部分。验证 URL 完整性时用 Python `hex()` 或检查文件字节数
- **诊断 state 中的 secret**：授权 URL 的 `state` 参数是 base64 编码的 JSON，包含 `appId`、`appSecret`、`clientKey` 等。用 Python `base64.b64decode(state)` 可以验证 MCP 实际使用的是哪个 secret，避免盲猜
- **Windows 打开授权链接**：如果 `powershell.exe Start-Process` 无法打开浏览器，可以创建 `.url` 快捷方式文件到桌面：`[InternetShortcut]\nURL=<完整授权URL>`，用户双击即可打开

## API 调用模式（Windows 兼容）

### ❌ 避免：bash curl（Windows 上引号转义问题多）
```bash
# 这种方式在 Windows git-bash 中经常出问题
curl -s -X POST 'https://...' -H "Authorization: Bearer $TOKEN" -d '{"key":"value"}'
```

### ✅ 推荐：Python urllib（execute_code 中使用）
```python
import json, os, urllib.request

# 1. 读取凭证
env_path = os.path.expanduser('~/.hermes/.env')
app_id = app_secret = None
with open(env_path) as f:
    for line in f:
        line = line.strip()
        if '=' in line and not line.startswith('#'):
            k, v = line.split('=', 1)
            if k == 'FEISHU_APP_ID':
                app_id = v
            elif k == 'FEISHU_APP_SECRET':
                app_secret = v

# 2. 获取 tenant_access_token
data = json.dumps({"app_id": app_id, "app_secret": app_secret}).encode()
req = urllib.request.Request(
    'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
    data=data,
    headers={"Content-Type": "application/json"}
)
resp = json.loads(urllib.request.urlopen(req).read())
token = resp['tenant_access_token']

# 3. 调用 API（关键：用变量拼接 auth header，避免 secret redaction）
auth = "Bearer " + token
req2 = urllib.request.Request(
    'https://open.feishu.cn/open-apis/drive/v1/files?folder_token=YOUR_TOKEN',
    headers={"Authorization": auth, "Content-Type": "application/json"}
)
resp2 = json.loads(urllib.request.urlopen(req2).read())
```

## Pitfalls

1. **Secret Redaction**：Hermes 会自动替换输出中的 API key/token。在 `execute_code` 中，如果 `Authorization` header 直接包含 token 字符串，会被替换为 `***` 导致 400 错误。解决：用变量拼接 `"Bearer " + token`。

2. **Token 有效期**：`tenant_access_token` 有效期约 2 小时，过期需重新获取。

3. **文件夹 vs 文档的权限模型不同**：
   - 文档：可通过页面「...」→「更多」→「添加文档应用」直接授权
   - 文件夹：只能通过群组间接授权

4. **Windows 路径**：`execute_code` sandbox 中用 `os.path.expanduser('~/.hermes/.env')` 而非 POSIX 路径。

## 读取飞书文档内容
当 `get_feishu_document_blocks` 输出被截断时，用浏览器控制台 `document.body.innerText` 分段提取。详见 `references/reading-long-documents.md`。

## 常用 API 端点

| 操作 | 方法 | 端点 |
|------|------|------|
| 获取 token | POST | `/open-apis/auth/v3/tenant_access_token/internal` |
| 列出文件夹 | GET | `/open-apis/drive/v1/files?folder_token=TOKEN` |
| 添加协作者 | POST | `/open-apis/drive/v1/permissions/TOKEN/members?type=folder` |
| 批量添加协作者 | POST | `/open-apis/drive/v1/permissions/TOKEN/members/batch_create?type=folder` |
