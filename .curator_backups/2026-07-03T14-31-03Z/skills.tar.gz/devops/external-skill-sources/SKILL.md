---
name: external-skill-sources
description: Manage external GitHub repos as Hermes skill sources — install, sync, pin, and patch skills from third-party repos. Use when the user wants to add skills from a GitHub repo, keep them updated, or handle .skill ZIP format repos.
---

# External Skill Sources

Install skills from any public GitHub repo and keep them auto-updated via cron.

## Quick Reference

| Step | Command |
|------|---------|
| Add tap | `hermes skills tap add <repo-url>` |
| Install from tap | `hermes skills install <identifier> -y` |
| Pin skill | `hermes curator pin <name>` |
| List taps | `hermes skills tap list` |

## Installing Skills

### Normal method (preferred)

```bash
hermes skills tap add https://github.com/owner/repo
hermes skills install "https://raw.githubusercontent.com/owner/repo/main/path/to/SKILL.md" -y
```

### Fallback: clone + copy

When `hermes skills install` times out or hits API rate limits, clone and copy:

```bash
git clone --depth 1 <repo-url> /tmp/skills-tmp
# For repos with SKILL.md directories:
cp -r /tmp/skills-tmp/skills/<category> "$HOME/AppData/Local/hermes/skills/<prefix>-<category>"
# For repos with .skill ZIP files:
cd /tmp/skills-tmp
for f in *.skill; do
    name="${f%.skill}"
    mkdir -p "$name" && unzip -o "$f" -d "$name"
    # Copy SKILL.md to appropriate target directory
done
```

Skills are at `$HOME/AppData/Local/hermes/skills/` on Windows, `~/.hermes/skills/` on Linux/Mac.

After copying, `/reload-skills` or start a new session.

## Auto-Sync with Cron

Create a sync script and schedule it:

```bash
# 1. Write sync script to $HOME/AppData/Local/hermes/scripts/sync-skills.sh
# 2. Create cron:
cronjob(action='create', name='Sync skills', schedule='0 9 * * *',
         script='scripts/sync-skills.sh', no_agent=true, deliver='origin,feishu')
```

Scripts go under `~/AppData/Local/hermes/scripts/` (Windows). Use `no_agent=true` so the script's stdout is delivered verbatim without LLM processing.

## Handling .skill ZIP Files

Some repos (e.g. branchingjade/AI-Skills) distribute skills as `.skill` files (ZIP archives containing SKILL.md). Extract with `unzip` and map to target directories:

```bash
unzip -o "$f" -d "$tmpd"
case "$name" in
    SkillName-*)
        dst="$SKILLS_DST/target-dir"
        mkdir -p "$dst"
        cp "$tmpd/SKILL.md" "$dst/"
        ;;
esac
```

## Custom Patches on Synced Skills

When a synced skill needs permanent modifications (e.g. narrowing triggers), add a `sed` patch in the sync script after the copy step. This ensures the patch survives future syncs:

```bash
cp "$tmpd/SKILL.md" "$dst/"
sed -i 's/original text/replacement text/' "$dst/SKILL.md"
```

## Delivery Targets

- `origin` — current chat
- `feishu` — Feishu home channel (set via `/sethome` in Feishu DM)
- `origin,feishu` — both

## Pitfalls

- `hermes skills install` may time out on slow networks — use clone+copy as fallback
- `hermes skills install` uses GitHub API; unauthenticated limit is 60/hr. Set `GITHUB_TOKEN` in `.env`
- After copying skills manually, run `/reload-skills` or restart session
- Sync scripts use `no_agent=true` — stdout is the delivered message, keep it clean
- On Windows, skill paths use `$HOME/AppData/Local/hermes/skills/`
