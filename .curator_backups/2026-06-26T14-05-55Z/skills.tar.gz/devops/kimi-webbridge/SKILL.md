---
name: kimi-webbridge
description: Kimi WebBridge — 通过本地守护进程+Chrome扩展控制用户真实浏览器（含登录态）。触发词：Kimi WebBridge、webbridge、用我的浏览器打开、在我浏览器里操作、用我登录的账号。
version: 1.1.0
---

# Kimi WebBridge

通过 `kimi-webbridge` 守护进程（`localhost:10086`）控制用户真实 Chrome，保留其所有网站的登录态。与 Hermes 自带的 CDP 浏览器工具互补——WebBridge 操作**用户主浏览器会话**，Hermes CDP 操作**独立无头 profile**。

## 架构

```
Agent → HTTP API (localhost:10086) → 守护进程 → CDP → Chrome 扩展 → 用户真实 Chrome
```

三层协作：守护进程 (`~/.kimi-webbridge/bin/kimi-webbridge.exe`) 常驻后台，扩展基于 Chrome DevTools Protocol，Agent 通过 curl 发 JSON 指令。**所有执行在本地完成，登录态不离开设备。**

## 触发时机

- 用户明确说"用 Kimi WebBridge"、"webbridge"
- 任务需要操作已登录的网站（用户主 Chrome 的 session）
- 用户说"在我浏览器里打开/操作"
- 需要截图用户正在看的页面

**不与 Hermes browser 工具混淆**：Hermes `browser_navigate` 等操作独立 CDP profile，不共享用户登录态。当用户说"用我浏览器"时，应走 WebBridge；当说"后台爬一下"时，走 Hermes CDP。

## 状态检查

```bash
~/.kimi-webbridge/bin/kimi-webbridge.exe status
# → {"extension_connected":true, "port":10086, "running":true, "version":"v1.10.0"}
```

守护进程未运行时启动它（安全幂等，已在运行则 no-op）：

```powershell
& "$env:USERPROFILE\.kimi-webbridge\bin\kimi-webbridge.exe" start
```

## 工具速查

所有调用通过 `terminal` 发 curl 到 `http://127.0.0.1:10086/command`。Windows 下**必须用文件体模式**（见下节）。

| 工具 | 核心参数 | 说明 |
|------|---------|------|
| `navigate` | `url`, `newTab`, `group_title` | 打开页面。首次调用开标签。`group_title` 设分组名 |
| `find_tab` | `url`, `active` | 切换到已有标签。`active:true` 选取用户当前正在看的 |
| `snapshot` | — | 可访问性树，元素带 `@e` 引用 |
| `click` | `selector` | 合成点击，支持 `@e` 引用或 CSS |
| `fill` | `selector`, `value` | 填表。支持 `<input>`/`<textarea>` + 富文本编辑器 |
| `evaluate` | `code` | 执行 JS（支持 async/await） |
| `cdp` | `method`, `params` | 原始 CDP 透传（逃生舱） |
| `screenshot` | `format`, `quality`, `selector`, `path` | 截图存文件，返回路径 |
| `save_as_pdf` | `paper_format`, `landscape`, `scale` | 导出 PDF |
| `network` | `cmd`(start/stop/list/detail) | 网络请求监控 |
| `upload` | `selector`, `files` | 文件上传 |
| `list_tabs` | — | 列出所有标签 |
| `close_tab` | — | 关闭当前标签 |
| `close_session` | — | 关闭任务所有标签 |

## Windows 调用：execute_code 模式（推荐）

**首选 `execute_code`**（Python `subprocess`），一次调用完成写文件→curl→删文件，零路径解析问题：

```python
import json, subprocess, os

payload = {
    "action": "navigate",
    "args": {"url": "https://example.com", "newTab": True, "group_title": "任务名"},
    "session": "my-task"
}

tmpfile = os.path.join(os.environ["TEMP"], f"wb-req-{os.urandom(4).hex()}.json")
with open(tmpfile, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False)

result = subprocess.run(
    ["curl.exe", "-s", "-X", "POST", "http://127.0.0.1:10086/command",
     "-H", "Content-Type: application/json", "--data-binary", f"@{tmpfile}"],
    capture_output=True, text=True, timeout=30
)
os.remove(tmpfile)
print(result.stdout)
```

备选 `terminal` 直调（仅当 payload 纯 ASCII，如 snapshot/list_tabs 请求）：

```bash
curl.exe -s -X POST http://127.0.0.1:10086/command \
  -H "Content-Type: application/json" \
  -d '{"action":"snapshot","session":"my-task"}'
```

**为什么必须文件体模式？** 中文等非 ASCII 字符经 shell 管道到 daemon 时变成 `?`。`execute_code` 用 Python `json.dump` 写 UTF-8 文件再 `--data-binary @file`，彻底绕过 shell 编码问题。

## Session 和标签管理

**一个任务 = 一个 session = 一个标签组。** Session 名是请求体的顶级字段（不在 `args` 里）。任务全程用同一个 session 名，不要按网站切换。

```json
{"action":"navigate","args":{"url":"https://example.com","newTab":true,"group_title":"任务中文名"},"session":"task-name"}
```

- `group_title` 用用户语言写，仅在首次 `navigate` 设置
- 任务完成后如用户可能后续查看，**不关 session**；确认不再需要再 `close_session`
- `find_tab` 选已有标签时用完整 URL，不要只用根域名

## 截图

daemon 存文件返回 `{format, path, sizeBytes, mimeType}`，用 `vision_analyze` 或 `read_file` 查看：

```json
{"action":"screenshot","args":{}}  // PNG 全视口
{"action":"screenshot","args":{"format":"jpeg","quality":60}}
{"action":"screenshot","args":{"selector":"@e123"}}
```

## evaluate 提示

- 用 `JSON.stringify(data)` 紧凑输出，不要加缩进（`null, 2` 会膨胀数倍导致截断）
- 多次 evaluate 共享 JS 域，`const`/`let` 重复声明报错 → 包 IIFE：`(() => { const x = ...; return x; })()`

## fill 行为

`fill` 是**清空后填入**。如需追加：先 `evaluate` 读当前值 → 拼接 → `fill` 完整内容。

## 与 Hermes browser 工具的关系

| 维度 | Kimi WebBridge | Hermes CDP browser |
|------|---------------|-------------------|
| 浏览器实例 | 用户主 Chrome | 独立 `chrome-cdp-profile` |
| 登录态 | 继承用户所有已登录网站 | 独立 profile，需单独登录 |
| 协议 | HTTP API（curl） | 工具函数（browser_navigate 等） |
| 可见性 | 用户浏览器窗口 | 默认无头 |
| 适用场景 | 操作已登录网站、日常浏览器任务 | 后台自动化、数据爬取、测试 |
| 安装 | `irm ... \| iex` | agent-browser npm + CDP Chrome |

**选择规则**：用户说"在我浏览器里"→ WebBridge；"后台跑一下"→ Hermes CDP。

## 性能诊断

WebBridge 可用于系统化网页性能诊断。完整五层排查法见 `references/performance-debugging.md`：

| 层级 | 工具 | 发现 |
|------|------|------|
| 1. 图片过载 | `evaluate` 统计 img | 七牛 CDN 缺缩略参数 |
| 2. DOM 过载 | `evaluate` 统计节点 | Flow 画布无虚拟化 |
| 3. 帧率 | `evaluate` RAF 计数 | 空闲 60fps，交互卡 |
| 4. 长任务 | `evaluate` PerformanceObserver | 58 个 150-350ms JS 阻塞 |
| 5. 热函数 | **`cdp` Profiler** | `patch`+`insertBefore` 占 20% |

七牛 CDN imageMogr2 缩略参数速查见 `references/qiniu-image-optimization.md`。\n\n### 扩展模板：declarativeNetRequest 缓存\n\n`templates/declarative-net-request-cache.json` 包含 manifest + 规则模板：\n- **缓存加速**：强制 JS/CSS/字体走本地缓存（`modifyHeaders` + `Cache-Control`）\n- **图片优化**：网络层 URL 重写（`regexSubstitution` + 缩略参数）\n- 复制 `_manifest_template` 和规则到独立目录，`chrome://extensions` 加载已解压即可

### CDP 性能分析 ⭐

用 `cdp` 工具调用 Chrome Profiler 抓交互期间的 CPU Profile：

```python
# 启动
{"action":"cdp","args":{"method":"Profiler.enable"}}
{"action":"cdp","args":{"method":"Profiler.start"}}
# ... 用户交互 3 秒 ...
# 停止
{"action":"cdp","args":{"method":"Profiler.stop"}}
```

## 网络缓存诊断

检测页面资源缓存率——所有请求走网络还是命中缓存：

```js
(() => {
  const entries = performance.getEntriesByType('resource');
  let cached = 0, network = 0;
  entries.forEach(e => {
    (e.transferSize === 0 && e.decodedBodySize > 0) ? cached++ : network++;
  });
  return JSON.stringify({total: entries.length, cached, network});
})()
```

若缓存率 0（如 RunningHub 的 250 资源全部走网络），可用 `declarativeNetRequest` + `modifyHeaders` 强制加 `Cache-Control` 头。模板见 `templates/declarative-net-request-cache.json`。

## 陷阱

### Windows 中文乱码
在 curl 命令行内联含中文的 JSON → daemon 收到 `?`。**必须文件体模式**（或直接用 execute_code）。

### PowerShell curl 别名
`curl` 在 PowerShell 里是 `Invoke-WebRequest` 的别名，行为不同。**必须用 `curl.exe`**。

### 版本不匹配
工具返回 "Please update the Kimi WebBridge extension" → 扩展版本低于 skill。告知用户更新扩展，不要重试。

### isTrusted 限制
部分网站（银行、验证码）严格检查 `event.isTrusted`，合成事件（`isTrusted: false`）被忽略。需告知用户手动操作。

### 会话/标签生命周期

- 用户关闭标签后，session 下的所有 evaluate/snapshot 请求返回 `"session tab was closed"`——必须重新 `navigate`。
- `find_tab` 可能返回不同 tabId（Chrome 标签 ID 会变），以返回值为准，不要缓存旧 tabId。
- 长时间不操作可能导致 session 过期，操作前先 `list_tabs` 确认。

### write_file MSYS2 路径解析（已弃用）
`write_file` 写 MSYS2 路径（`/c/Users/...`）会解析成 `C:\c\Users\...`，文件写到错误位置。**直接用 `execute_code` 的 Python `open()` + `os.environ["TEMP"]` 替代 write_file + terminal 两步式。**
