---
name: windows-shell
description: |
  Safe PowerShell and Windows command patterns when running through bash (MSYS/git-bash)
  on this Windows host. Covers escaping, process management, and tool installation pitfalls.
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [windows, powershell, bash, msys, git-bash, escaping]
    category: devops
---

# Windows Shell Patterns (bash → PowerShell)

On this host, the `terminal` tool runs **bash** (git-bash / MSYS), NOT PowerShell or cmd.exe.
Many Windows-native tools require PowerShell commands. Passing those through bash
introduces escaping traps that look like silent success but corrupt the command.

## The cardinal rule: `$env:VAR` → `\$env:VAR`

Bash interprets `$env` as a shell variable (expanding to empty string). When a
PowerShell variable reference passes through bash unescaped, PowerShell receives
garbage like `:USERPROFILE` and fails with misleading errors.

**Always** backslash-escape the dollar sign:

```bash
# WRONG — bash eats $env, PowerShell sees garbage
powershell -NoProfile -Command "Get-Item '$env:USERPROFILE\.foo'"

# RIGHT — bash passes $env:USERPROFILE through intact
powershell -NoProfile -Command "Get-Item \"\$env:USERPROFILE\.foo\""
```

The same applies to any PowerShell variable: `\$HOME`, `\$PWD`, `\$PROFILE`, etc.

## Safe PowerShell invocation template

```bash
powershell -NoProfile -Command "<PowerShell code with all \$ escaped>"
```

Flags:
- `-NoProfile` — skips profile scripts, faster and avoids side effects
- `-ExecutionPolicy Bypass` — only when running downloaded scripts via `iex`
- `-Command "..."` — the command string; use double-quotes so `\$` works

## Process management on Windows

```bash
# Check if a process is running
powershell -NoProfile -Command "Get-Process 'process-name' -ErrorAction SilentlyContinue"

# Kill a process
powershell -NoProfile -Command "Get-Process 'process-name' -ErrorAction SilentlyContinue | Stop-Process -Force"

# Check for scheduled tasks (auto-restart culprits)
powershell -NoProfile -Command "Get-ScheduledTask -TaskName '*pattern*' -ErrorAction SilentlyContinue"
```

## Multi-step scripts

For multi-step PowerShell, assign a variable first then reference it —
fewer `\$` to sprinkle:

```bash
powershell -NoProfile -Command "\$dir = \"\$env:USERPROFILE\\.foo\"; Remove-Item -Recurse -Force \$dir -ErrorAction SilentlyContinue; New-Item -ItemType Directory -Path \"\$dir\\bin\" -Force | Out-Null"
```

Note: `\\` for literal backslash in directory separators inside double-quoted PowerShell strings.

## Common pitfalls

| Symptom | Cause | Fix |
|---------|-------|-----|
| "不支持给定路径的格式" / path format not supported | `$env` was eaten by bash; path became `:USERPROFILE\...` | Escape with `\$env:USERPROFILE` |
| Move-Item fails with "文件已存在" / file exists | Target file locked by running process | Kill the process first, then Move-Item |
| Process reappears after kill | Auto-restart mechanism (scheduled task, parent process, startup entry) | Check `Get-ScheduledTask`, `HKCU:\...\Run`, stop the parent first |
| `2>$null` redirect fails | bash interprets `2>` as its own redirect | Use PowerShell-native `-ErrorAction SilentlyContinue` instead |

## .env 文件加载（git-bash）

```bash
# 可靠方式：set -a 自动导出所有变量
set -a && source /path/to/.env && set +a

# 不可靠：单独 source（变量仅在子 shell 生效）
source /path/to/.env    # ❌

# 不可靠：直接 export KEY=value（Hermes 会脱敏）
export GH_TOKEN=xxx     # ❌ 输出被脱敏
```

脚本中用绝对路径执行，放在工作目录下。

## curl + non-ASCII content: always use file body

Windows git-bash corrupts non-ASCII characters (Chinese, emoji, etc.) in inline
`-d`/`--data` strings. The content reaches the server as `?` and is unrecoverable.

**Never inline non-ASCII JSON.** Always write to a temp file with Python (not shell
echo/heredoc, which corrupts the same way), then POST with `--data-binary @file`:

```bash
python3 -c "
import json
payload = {'key': '中文值', 'tags': ['标签1', '标签2']}
with open('/tmp/req.json', 'w', encoding='utf-8') as f:
    json.dump(payload, f, ensure_ascii=False)
"
curl.exe -s -X POST http://... -H 'Content-Type: application/json' --data-binary @/tmp/req.json
```

Use `curl.exe` (not bare `curl`, which PowerShell aliases to `Invoke-WebRequest`).

This pattern applies to **any API that accepts non-ASCII content** — Eagle API,
Kimi WebBridge, Feishu, etc. — not just WebBridge.

### curl `-u` Basic Auth with non-ASCII usernames → 401

`curl -u 用户名:密码` encodes credentials via base64 internally. In MSYS/bash,
non-ASCII usernames (e.g. Chinese `妖玉`) are mangled before encoding, producing
a wrong base64 token. The server receives garbled credentials and returns 401 —
even though the password is correct.

**Verification test** (use explicit base64 encoding):

```bash
# WRONG — MSYS mangling → 401
curl -u 妖玉:Huan1120 -X PROPFIND http://localhost:5244/dav/

# RIGHT — explicit base64 with known-good encoding
curl -H "Authorization: Basic $(echo -n '妖玉:Huan1120' | base64)" \
  -X PROPFIND http://localhost:5244/dav/
```

**Windows native clients are NOT affected** — Windows credential system handles
UTF-8 Basic Auth correctly. This is purely a git-bash/MSYS `curl` issue. When
testing WebDAV auth from the terminal, always use the explicit base64 form.

## When the installer script fails

Many Windows tools ship a `irm ... | iex` one-liner installer. When it fails
(move errors, process locks), the fallback is:

1. Kill any running instances of the tool
2. Delete the tool's install directory
3. Download the binary directly with `Invoke-WebRequest -OutFile`
4. Start the daemon and run post-install commands manually

See `references/kimi-webbridge.md` for a worked example.

## References

- `references/browser-agent-cdp-windows.md` — **Agent-Browser CDP mode**: `--session` hangs on Windows, use `--cdp <port>` with Chrome `--remote-debugging-port` instead. Covers persistent login profiles, form interaction via eval, and Hermes integration limitations.
- `references/kimi-webbridge.md` — Kimi WebBridge installation: full workflow, pitfalls, and verification
- `references/github-cli-windows.md` — GitHub CLI on Windows: config path, keyring token storage, backup workaround
- `references/desktop-window-investigation.md` — **Desktop window investigation**: enumerate visible windows via Python ctypes Win32 API, capture screenshots, and identify unknown desktop windows. Use when the user asks about a mysterious window on their desktop.
