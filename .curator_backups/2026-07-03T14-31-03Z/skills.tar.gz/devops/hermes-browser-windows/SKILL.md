---
name: hermes-browser-windows
description: Hermes browser 工具在 Windows 上的 CDP 模式配置——绕过 agent-browser --session 死锁。
version: 1.0.0
platforms: [windows]
metadata:
  hermes:
    tags: [hermes, browser, windows, cdp, troubleshooting]
---

# Hermes Browser — Windows CDP 配置

Hermes browser 工具底层依赖 `agent-browser` CLI（npm 包）。`agent-browser --session` 在 Windows 上存在死锁 bug，导致每次调用卡死。

**修复方案：通过 `BROWSER_CDP_URL` 环境变量切换为 CDP 模式**，绕过 `--session`。

## 前置条件

- Chrome 已安装（`C:\Program Files\Google\Chrome\Application\chrome.exe`）
- `agent-browser` 已全局安装：`npm install -g agent-browser`

## 配置步骤

### 1. 设置环境变量

在 `~/.hermes/.env` 中添加：

```
BROWSER_CDP_URL=http://localhost:9222
```

Hermes 的 `_get_cdp_override()` 自动读取此变量，将 `--session` 切换为 `--cdp <port>`。

### 2. 独立 Chrome Profile（推荐）

Chrome 主 profile 可能已在运行，且 Windows 下 `taskkill /F` 无法可靠 kill Chrome（后台驻留自动复活）。使用独立 profile 避免冲突：

```
--user-data-dir=C:\Users\<user>\.hermes\chrome-cdp-profile
```

### 3. 启动 Chrome CDP

```bash
"C:\Program Files\Google\Chrome\Application\chrome.exe" \
  --remote-debugging-port=9222 \
  --user-data-dir=C:\Users\<user>\.hermes\chrome-cdp-profile
```

验证：
```bash
curl -s http://localhost:9222/json/version
# → {"Browser": "Chrome/...", "webSocketDebuggerUrl": "ws://..."}
```

### 4. 开机自启

创建 VBS 脚本放入 Windows Startup 文件夹（`shell:startup`）：

```vbscript
Set WshShell = CreateObject("WScript.Shell")
WshShell.Run """C:\Program Files\Google\Chrome\Application\chrome.exe"" --remote-debugging-port=9222 --user-data-dir=C:\Users\<user>\.hermes\chrome-cdp-profile", 1, False
```

`1` = 正常窗口（可见），`0` = 隐藏。

## 验证

`/reset` 后测试：

```
browser_navigate → 秒返，不卡死
browser_console  → JS 正常执行
browser_click    → 交互正常
```

## 登录态持久化

独立 profile 保存所有 cookie/localStorage。首次在 CDP Chrome 窗口中登录后，重启 Chrome/Hermes 登录态不丢。

## 清理后台

Chrome 的 `taskkill /F /IM chrome.exe` 在 Windows 上不可靠（后台驻留自动复活）。如需彻底关闭，用 PowerShell：

```powershell
Get-Process chrome -ErrorAction SilentlyContinue | Stop-Process -Force
```

## 陷阱

- **不要用 `terminal(background=true)` 启动 Chrome** — 窗口不可见且 Hermes 后台任务列表会累积
- **不要用 `execute_code` 的 `subprocess.Popen` 启动 Chrome** — 沙箱环境可能无法创建可见窗口
- **Chrome 窗口可见性**：用 `cmd //c start ""` 或 VBS `Run(..., 1, False)` 确保窗口可见
- **`BROWSER_CDP_URL` 需要 `/reset` 生效** — 环境变量在会话启动时加载
- **端口冲突**：确认 9222 端口未被占用（`netstat -ano | findstr 9222`）
