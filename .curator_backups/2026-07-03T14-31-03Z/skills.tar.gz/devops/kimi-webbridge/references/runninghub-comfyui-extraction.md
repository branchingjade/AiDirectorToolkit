# 通过 Kimi WebBridge 从 RunningHub 提取 ComfyUI 工作流数据

RunningHub 的 ComfyUI 画布内嵌在 `<iframe>` 中，和父页面同源。通过 WebBridge 的 `evaluate` 可直接访问 `iframe.contentWindow.app.graph`。

## 快速参考

```javascript
// 获取所有节点数据
const iframe = document.querySelector('iframe');
const app = iframe.contentWindow.app;
const nodes = Object.values(app.graph._nodes);
nodes.map(n => ({id: n.id, type: n.type, title: n.title, widgets: n.widgets_values}));

// 获取连线：[link_id, from_node, from_slot, to_node, to_slot, type]
const links = app.graph.serialize().links;

// 列出 graph 方法
Object.getOwnPropertyNames(Object.getPrototypeOf(app.graph))
    .filter(m => typeof app.graph[m] === 'function');
```

## 关键方法

| 方法 | 返回 | 用途 |
|------|------|------|
| `serialize()` | 编辑器格式对象 | 含 nodes, links, groups, config |
| `asSerialisable()` | 结构类似 | 备选 |
| `graphToPrompt()` | API 格式（RH 可能为空） | 标准导出 |
| `getNodeById(id)` | 单节点 | 按 ID 查找 |

## 注意事项

- 同源 iframe → `contentWindow.app` 可直接访问
- SPA 需等渲染完成（iframe 加载 + 画布显示节点）
- `serialize().links` 格式：`[link_id, from, from_slot, to, to_slot, type]`
- `graphToPrompt()` 在 RH 环境可能返回空 `{}`
