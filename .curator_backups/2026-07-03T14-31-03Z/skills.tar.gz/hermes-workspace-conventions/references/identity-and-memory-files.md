# SOUL.md / USER.md / MEMORY.md — 三文件角色区分

三个文件都在 `$HERMES_HOME` 下，但注入位置和作用完全不同。

## 文件对照

| 文件 | 路径 | 作用 | System Prompt 层级 | 修改方式 |
|------|------|------|-------------------|---------|
| **SOUL.md** | `~/.hermes/SOUL.md` | 替换 agent 基础人格（你是谁） | stable tier（缓存） | 直接编辑文件 |
| **USER.md** | `~/.hermes/memories/USER.md` | 描述用户（用户是谁） | volatile tier（每次重建） | `memory(target='user')` |
| **MEMORY.md** | `~/.hermes/memories/MEMORY.md` | Agent 笔记（环境/约定/坑） | volatile tier（每次重建） | `memory(target='memory')` |

## SOUL.md

- 替换硬编码的 `DEFAULT_AGENT_IDENTITY`（"You are Hermes Agent..."）
- 如果有内容且非空，注入到 system prompt 的 stable tier slot #1
- 如果没有或为空，使用默认身份
- 默认内容就是原文照抄，**等于没改——只有自定义后才有效果**

## USER.md（用户画像）

- 通过 `memory.user_profile_enabled: true` 控制（默认 true）
- 描述用户偏好、身份、风格、禁忌
- 显示为 `USER PROFILE (who the user is) [X% — N/N chars]` 块

## MEMORY.md（Agent 笔记）

- 通过 `memory.memory_enabled: true` 控制（默认 true）
- Agent 记录的环境信息、约定、工具坑
- 显示为 `MEMORY (your personal notes) [X% — N/N chars]` 块

## 关键区分

- SOUL.md 改的是 **"我是谁"**（agent identity）
- USER.md 改的是 **"你是谁"**（user facts）
- MEMORY.md 改的是 **"我知道什么"**（agent knowledge）
