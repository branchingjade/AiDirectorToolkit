---
name: hermes-backup
description: >
  将 Hermes 配置、技能、记忆、会话数据及 Obsidian Vault 备份到云存储（坚果云/OneDrive 等）。
  以 robocopy 增量同步为核心，覆盖 config/skills/memories/cron/state.db/Obsidian Vault。
  Trigger when: user asks to backup Hermes, migrate Hermes data, set up cloud sync,
  recover from lost data, or any mention of "备份" + Hermes.
---

# Hermes 云备份

将 Hermes 所有持久化数据备份到云存储目录，使用 robocopy 增量同步，只传输变化部分。

## 备份内容

| 数据 | 路径 | 说明 |
|------|------|------|
| Hermes 配置/技能/记忆/cron | `~/.hermes/` | 含 `.env`（密钥随备份上传） |
| 会话数据库 | `~/AppData/Local/hermes/state.db` | 变化 |
| Obsidian Vault | `~/Documents/KnowledgeBase/Obsidian Vault/` | Hermes 相关笔记 |

**排除：** `~/.hermes/.webdav-cred`、`.obsidian`、`logs/`、`cache/`、`.git/`、`*.log`、`*.tmp`、`*.lock`

## 步骤

### 1. 确认云盘路径

坚果云同步目录在 Nutstore SQLite 数据库中：
```
~/AppData/Roaming/Nutstore/db1/nutstore.db → sndconfig* 表 → localAbsPath
```
默认路径：`~/Nutstore/1/我的坚果云`

对其他云盘（OneDrive/Dropbox），直接用已知路径即可。

### 2. 运行备份脚本

直接执行技能自带的备份脚本：
```bash
bash "$(dirname "$(skill_view name='hermes-backup' file_path='scripts/backup-hermes.sh')")/scripts/backup-hermes.sh"
```
或将脚本复制到本地运行：
```bash
cp "$SKILL_DIR/scripts/backup-hermes.sh" ~/Documents/Hermes/scripts/
bash ~/Documents/Hermes/scripts/backup-hermes.sh
```

或手动 robocopy：
```bash
MSYS_NO_PATHCONV=1 robocopy \
  "$(cygpath -w ~/.hermes)" \
  "$(cygpath -w ~/Nutstore/1/我的坚果云/Hermes备份/.hermes)" \
  /MIR /NP /NDL /NFL /R:2 /W:3 \
  /XD logs cache __pycache__ .git \
  /XF "*.log" "*.tmp" "*.lock"
```

脚本自动处理增量同步和备份验证。

### 3. 设置定时备份（可选）

用 cronjob 每天自动备份：
```
cronjob action=create schedule="0 3 * * *" prompt="运行 backup-hermes.sh 脚本备份 Hermes 数据"
```

## 恢复

从云端恢复只需反向复制：
```bash
cp -r ~/Nutstore/1/我的坚果云/Hermes备份/.hermes ~/
cp ~/Nutstore/1/我的坚果云/Hermes备份/AppData/state.db ~/AppData/Local/hermes/
```

## Mode B — WebDAV 直传（curl）

适用于无本地同步文件夹的场景（如只用 WebDAV 密钥连接坚果云）。
凭据存放在 `~/.hermes/.webdav-cred`（chmod 600）：

```
WEBDAV_USER="branchingjade@qq.com"
WEBDAV_PASS="<应用密码>"
```

**Windows 推荐 Python 版**（`backup-hermes-webdav.py`），避免 bash-on-PATH 问题：
1. 调用 GNU tar（`C:\Program Files\Git\usr\bin\tar.exe`）打包，与 bash 版 tar 行为完全一致
2. curl subprocess 上传
3. 本地保留最近 7 个备份

手动运行：
```bash
python ~/AppData/Local/hermes/scripts/backup-hermes-webdav.py
```

设置定时备份（no_agent 模式）：
```
cronjob action=create schedule="0 8 * * *" name="Hermes WebDAV 备份"
  script="backup-hermes-webdav.py" no_agent=true deliver="origin"
```

也可以使用 bash 版（`backup-hermes-webdav.sh`），但需要确保 `bash` 在 Windows PATH 中（见 Pitfalls）。

详见 `references/webdav-nutstore.md`、`references/python-backup-pitfalls.md` 和 `references/baidu-webdav-migration.md`。

## Pitfalls

- **Windows cron `.sh` 脚本：bash 必须在 PATH 中**：Hermes cron 运行器不走 Git Bash 环境。**推荐：改写为 Python 脚本**，调用 GNU tar（`C:\Program Files\Git\usr\bin\tar.exe`）打包、curl 上传，避免 bash 依赖。备选：将 `C:\Program Files\Git\bin` 加到用户 PATH 后重启 Hermes，但实测此方案不一定生效（cron 环境继承链不确定）。
- **Python `Path.rglob` 打包陷阱**：用 `tarfile` 遍历目录逐个 `tar.add()` 会导致文件重复打包（实测 1935 个不同文件 → 9326 个 tar 条目，体积膨胀 4 倍）。**正确做法**：用 `subprocess` 调用 GNU tar.exe 打包。
- **MSYS2 二进制路径格式**：Git for Windows 的 GNU 工具（`tar.exe` 等）不接受 Windows 风格路径（`C:\Users\...`）。`subprocess` 调用时需转换为 MSYS 格式：`/c/Users/...`（`s.replace(chr(92), '/')`，盘符 `C:` → `/c`）。
- **Cron 脚本 120s 超时**：`no_agent: true` 脚本有 120s 硬超时。大体积备份（>200MB 上传）可能超时，需控制体积。
- **Cron job 脚本路径**：`script` 参数解析到 `~/AppData/Local/hermes/scripts/<文件名>`，不是 skill 目录。
- **robocopy 在 git-bash/MSYS 下路径转换**：必须设置 `MSYS_NO_PATHCONV=1` 并用 `cygpath -w` 转为 Windows 路径，否则 `/MIR` 等参数会被错误转换
- **robocopy 返回码**：1-7 均为成功（1=有文件复制，0=无变化），不要用 `set -e`，需手动检查 `$? -le 7`
- **WebDAV 中文路径**：curl 不自动 URL-encode，目录名用纯 ASCII 避免 400 错误
- **WebDAV 中文用户名认证**：curl `-u "中文:密码"` 在 bash/MSYS 环境 base64 编码错误 → 401。**正确做法**：Python 里 `base64.b64encode("用户名:密码".encode("utf-8"))`，curl 用 `-H "Authorization: Basic <b64>"` 替代 `-u`。
- **WebDAV 目录创建**：上传前需 MKCOL 创建目标目录，已存在则返回 405（可忽略）
