---
name: feishu-gateway-setup
description: "Configure Feishu (飞书) as a messaging platform in Hermes gateway — lark-cli installation, identity binding, auth, display formatting, and autonomous reply settings."
version: 1.5.0
tags: [feishu, lark, gateway, setup, display, messaging]
---

# Feishu Gateway Setup for Hermes

Complete workflow for setting up Feishu (飞书) as a messaging platform in Hermes gateway with clean, concise message formatting.

## Architecture

```
┌─────────────┐     WebSocket + REST      ┌──────────────┐
│   Hermes    │ ◄──────────────────────► │  飞书 API    │
│ adapter.py  │   bot-level operations    │              │
│             │   (消息/文档/评论/群组)    │              │
└─────────────┘                           └──────────────┘
                                             ▲
┌─────────────┐   OAuth user_access_token    │
│  lark-cli   │ ────────────────────────────┘
│  --as user  │   仅在需要「以用户身份」操作时使用
└─────────────┘   (发消息/日历/邮箱/个人文档)
```

**Hermes adapter.py** handles all bot-level Feishu operations natively — messages (WebSocket), docs, comments, groups. Does NOT depend on lark-cli, OpenClaw, or any lark-* skills.

lark-cli is a lightweight supplementary tool used ONLY when you need to operate as your user identity (send messages as yourself, access personal calendar/mail). lark-cli is NOT involved in bot messaging at all.

See `references/lark-cli-token-management.md` for token lifetimes, auto-refresh behavior, and required OAuth scopes.

## Document Operations

lark-cli can read and export Feishu documents without needing a browser login — use this when the user asks about content in their Feishu docs.

**Read a doc:** `lark-cli drive +inspect --url <url>` → get token + type
**Export for analysis:** `lark-cli drive +export --token <t> --doc-type docx --file-extension markdown --output-dir . --overwrite`

Full reading workflow and gotchas: `references/feishu-doc-reading.md`

**Edit/write a doc (block-level API):** Use `lark-cli api` to GET block structure, DELETE old blocks, POST new blocks — no browser needed. Covers block types (heading, bullet, text), link creation, and Python subprocess calling patterns.

Full editing workflow and pitfalls: `references/feishu-doc-editing.md`

**Enriching docs with external data**: When a Feishu doc contains links that don't preview (e.g. Bilibili space URLs), pull the data via public APIs to build structured content directly. For Bilibili-specific API access patterns (mobile UA bypass, Googlebot UA, WBI signing): `references/bilibili-api-access.md`.

## Prerequisites

- Feishu app with Bot capability enabled (App ID + App Secret from https://open.feishu.cn)
- Hermes installed and running

## Step 1 — Install lark-cli (for OAuth only)

```bash
npm install -g @larksuite/cli
```

lark-cli is needed ONLY for user-level OAuth authorization (Steps 4-5). Hermes core (bot messaging, WebSocket, doc reading) uses its own built-in `adapter.py` — does NOT depend on lark-cli.

**Do NOT install lark-* skills or OpenClaw.** Hermes has built-in Feishu tools (`feishu_doc_tool.py`, `feishu_drive_tool.py`).

## Step 2 — Ask Identity

Present the user with two options:
- **以机器人身份** (bot-only) — robot identity, suitable for group chats and shared docs
- **以用户身份** (user-default) — user identity, requires OAuth authorization

Include this warning for user-default:
> **⚠️ 如果你选「以用户身份」：请勿将此机器人分享给他人或拉入群聊中使用 —— 它能访问你的个人飞书数据。**

## Step 3 — Configure .env

Add to `~/.hermes/.env`:
```
FEISHU_APP_ID=<app_id>
FEISHU_APP_SECRET=<app_secret>
FEISHU_CONNECTION_MODE=websocket
FEISHU_GROUP_POLICY=open
```

Note: `FEISHU_GROUP_POLICY=open` is REQUIRED for group messages to work. The feishu adapter reads this from env vars, NOT from config.yaml. Without it, all group messages are silently rejected.
The secret redaction feature may obscure displayed values — use `wc -c` to verify correct length instead of reading the value.

## Step 4 — Bind Identity

```bash
lark-cli config bind --identity <bot-only|user-default>
```

If multi-account error: show candidates from `error.hint`, let user pick, then:
```bash
lark-cli config bind --identity <IDENTITY> --app-id <chosen_app_id>
```

## Step 5 — Auth Login (user-default only)

Skip for bot-only.

First call — get auth URL with required scopes:
```bash
lark-cli auth login --recommend --scope "im:message.send_as_user" --no-wait --json
```

**⚠️ `im:message.send_as_user` must be explicitly requested.** The `--recommend` flag alone does NOT include it. Without this scope, `lark-cli --as user im +messages-send` fails with `missing_scope`.
Extract `verification_url` from JSON output. Send to user as markdown autolink: `<https://...>`.
**Never** open the URL yourself (sandbox browser can't complete auth).
Save `device_code` for next step.

After user confirms authorization:
```bash
lark-cli auth login --device-code <device_code>
```

See `references/lark-cli-oauth-lifecycle.md` for token lifetime, auto-refresh mechanism, and the reminder cron setup.

## Step 6 — Verify

```bash
lark-cli auth status
```

Check: `identity` matches, `tokenStatus` is `valid` or `needs_refresh` (not `expired`).

## Step 7 — Enable Gateway Platform

```bash
hermes config set platforms.feishu.enabled true
pip install websockets   # required for websocket mode
```

## Step 8 — Clean Display Format (CRITICAL)

**The user prefers clean, OpenClaw-like responses — no tool progress, no reasoning, no footer.**

```bash
hermes config set display.platforms.feishu.tool_progress false
hermes config set display.platforms.feishu.interim_assistant_messages false
hermes config set display.platforms.feishu.show_reasoning false
hermes config set display.platforms.feishu.require_mention true
hermes config set display.platforms.feishu.system_prompt "始终使用中文回复。简洁直接，不要冗长。"
```

Runtime footer is global; disable it:
```bash
hermes config set display.runtime_footer.enabled false
```

## Step 9 — Autonomous Reply in Specific Groups

**CRITICAL**: `free_response_channels` does NOT work for the Feishu platform. Use `group_rules` instead.

### 9a — Bridge `group_rules` in gateway/config.py (APPLIED 2026-07-15)

The feishu adapter reads per-group rules from `extra.get("group_rules")`, but the config bridge does not forward `group_rules`. This fix was applied on 2026-07-15. If upgrading Hermes, verify the bridge is still present. Add to `~/.hermes/hermes-agent/gateway/config.py`, after the `group_user_allowed_commands` bridge:

```python
if "group_rules" in platform_cfg:
    bridged["group_rules"] = platform_cfg["group_rules"]
```

Without this fix, `hermes config set platforms.feishu.group_rules.oc_XXX.require_mention false` has NO effect — the adapter never sees the setting and always falls back to the global `require_mention`.

### 9b — Set per-group rules

For groups that should get free responses (no @mention needed):

```bash
hermes config set platforms.feishu.group_rules.oc_CHAT_ID.require_mention false
hermes config set platforms.feishu.require_mention true    # other groups still need @
```

For per-channel prompts:
```bash
hermes config set platforms.feishu.channel_prompts.oc_CHAT_ID "始终使用中文回复，简洁直接。"
```

### Why `free_response_channels` doesn't work on Feishu

The Feishu platform adapter reads its per-group rules from `extra.get("group_rules")`, not from `free_response_channels`. The `free_response_channels` value **is** bridged to the platform config (gateway/config.py line 1207-1208) but is never processed into group rules by the feishu adapter (zero references to `free_response_channels` in adapter.py). This is different from Discord/Slack where `free_response_channels` is explicitly handled.

## Step 10 — Markdown Rendering

Messages are sent as `post` type (markdown-capable) ONLY when they contain markdown syntax. Plain-text messages are sent as `text` type (no rendering). The gateway's `_build_outbound_payload` uses `_MARKDOWN_HINT_RE` to detect markdown (headings, lists, bold, links, code fences, etc.) — if no markdown syntax is present, the message degrades to plain text.

**Workaround**: Add a per-platform system prompt that instructs the agent to use markdown (see below). See `references/markdown-rendering-fix.md` for the full code analysis and trigger patterns.

### System prompt format requirement (THE ACTUAL WORKING METHOD)

**⚠️ `~/.hermes/SOUL.md` is NOT loaded by Hermes** (verified 2026-07-02: zero references in hermes-agent source code). The correct way to inject format instructions is the per-platform system prompt:

```bash
hermes config set display.platforms.feishu.system_prompt "始终使用中文回复。简洁直接，不要冗长。回复尽量包含 markdown 格式元素（**粗体**、- 列表、## 标题等）。无推理过程、无工具进度、无底栏。"
hermes gateway restart
```

This is already set up in Step 8. Verify with `hermes config show` (check display.platforms.feishu.system_prompt). No separate file needed.

### Verified working (tested 2026-06-24)

| Feature | Status |
|---------|--------|
| Bold, italic, strikethrough | ✅ |
| Links (inline + in tables) | ✅ |
| Headings, lists, blockquotes | ✅ |
| Tables (3+ columns, links in cells) | ✅ (fixed 2026-07-10 — _MARKDOWN_TABLE_RE force-text block removed from _build_outbound_payload in adapter.py) |
| Code blocks (fenced, with language) | ✅ |
| Inline code | ✅ |
| Multi-paragraph messages | ✅ (after `_build_markdown_post_rows` fix — see `references/markdown-rendering-fix.md`) |
| Columns / multi-column layout | ❌ (need card messages) |
| Buttons / interactive elements | ❌ (need card messages) |

### Strategy

- **Normal messages**: post+md — covers all standard Markdown
- **Interactive needs** (buttons, multi-column): fall back to Feishu card messages
- Transition trigger: auto-detect when post+md can't express the required component

### Pitfall: entire message in code block

If the assistant wraps the entire response in ``` (triple backticks), Feishu renders the WHOLE message in monospace. Instead:
- Use `##` headings, `-` bullets, `**bold**` for structure — these render correctly in Feishu post format
- Only use ``` for actual code snippets within the message
- Never put structure/headings inside code fences

## Step 11 — Set Home Channel & Restart

In the Feishu DM/group, send `/sethome` to set the home channel. Then:

```bash
hermes gateway restart
```

Wait ~10s, verify connection:
```bash
# Use hermes config path to find logs portably (avoids ~/.hermes/logs which doesn't exist on Windows GUI installs)
LOG_DIR="$(dirname "$(hermes config path)")/logs"
grep "feishu connected" "$LOG_DIR/gateway.log" | tail -1
```

## Step 12 — Multi-User Memory Isolation (CRITICAL)

If the Feishu bot is added to group chats or open to DMs from multiple users, **built-in memory (MEMORY.md + USER.md) is SHARED across all users of the same profile**. Sessions are isolated per user, but memory is profile-level — a memory saved during another user's conversation will appear in your sessions too.

**⚠️ SOUL.md personality gating does NOT work.** `~/.hermes/SOUL.md` is not loaded by Hermes (zero references in source code, verified 2026-07-02). The "Selective Write via SOUL.md" approach documented in `references/multi-user-memory-isolation.md` is invalid.

### Working solutions (ranked)

1. **Restrict bot visibility** — In Feishu Developer Console → Security Settings, set visibility to "仅应用管理员可见". Blocks at the source. Zero code changes.

2. **Disable memory toolset on feishu** — Hard block, your own feishu DM also can't write:
   ```bash
   hermes tools disable memory --platform feishu
   hermes gateway restart
   ```

3. **`agent.system_prompt` (soft, universal)** — Inject memory write rules into ALL sessions via config.yaml. Agent sees `**User:**` / `**Session type:**` from `build_session_context_prompt()` and gates writes:
   ```bash
   hermes config set agent.system_prompt "# 记忆写入规则\n\n仅当系统提示中「**User:**」行显示为「妖玉」且「**Session type:**」不包含 Multi-user 时，方可调用 memory 工具写入记忆。其他用户或群聊均禁止写入。\n\n记忆读取不受此限制——所有会话均可引用已有记忆和用户画像。"
   hermes gateway stop && hermes gateway start
   ```
   **How it works**: `_load_ephemeral_system_prompt()` in `gateway/run.py` reads `agent.system_prompt` → combined with session context from `build_session_context_prompt()` (which includes `**User:** 妖玉` or `**Session type:** Multi-user session`) → injected as `ephemeral_system_prompt` into AIAgent. Universal across all platforms, not just feishu.

4. **`display.platforms.feishu.system_prompt` (soft, feishu-only)** — Same personality approach but scoped to feishu platform only. Set via Step 8 command. Less universal than `agent.system_prompt`.

5. **Separate profile** — `hermes profile create feishu-bot --clone-from default --clone`. Complete isolation.

Full breakdown of all strategies: `references/multi-user-memory-isolation.md`

## Pitfalls

- **Don't use browser to access Feishu docs**: Feishu doc URLs redirect to a login page in CDP/headless browsers (captcha + QR code). The agent cannot complete this login. Use `lark-cli drive +export` (see Document Operations above and `references/feishu-doc-reading.md`) instead — it uses existing OAuth tokens and works instantly.
- **⚠️ FEISHU_GROUP_POLICY IS AN ENV VAR, NOT CONFIG**: The feishu adapter reads `FEISHU_GROUP_POLICY` from environment variables (default: `"allowlist"`) at line 1527 of `adapter.py`, NOT from `platforms.feishu.group_policy` in config.yaml. If this env var is not set to `"open"`, ALL group messages are silently rejected with the rejection reason `"group_policy_rejected"`. This was the root cause of "群里不回消息" after all other settings were correct. Fix: `echo "FEISHU_GROUP_POLICY=open" >> ~/.hermes/.env` then restart gateway. Even if `platforms.feishu.group_policy: open` is in config.yaml, the code ignores it.
- **config.yaml NOT .env**: `hermes config set` writes to config.yaml. For env vars (FEISHU_APP_ID, FEISHU_APP_SECRET, FEISHU_GROUP_POLICY), manually write to .env via terminal.
- **Secret redaction**: The security.redact_secrets feature obscures displayed secret values. Use character count (`wc -c`) to verify correctness instead of reading values.
- **Gateway restart timing**: `hermes gateway restart` may report "no process detected after 6s" — this is often a false alarm; check logs for actual connection.
- **WS disconnected after restart**: The gateway cleanly disconnects and reconnects; the old session in Feishu may show "disconnected" briefly. Wait 10-15s.
- **`final_response_markdown` is CLI-only**: The `display.final_response_markdown` config setting (`render` / `strip` / `raw`) only affects the CLI/TUI terminal output, NOT the gateway. Changing it will have zero effect on Feishu message formatting. If Feishu messages aren't rendering Markdown, the issue is in the Feishu adapter's `_build_outbound_payload`, not this config setting.
- **Config changes need restart**: Any platform or display config changes require `hermes gateway restart` to take effect.
- **`hermes config unset` does not exist**: Hermes CLI has no `unset` subcommand. To remove a config key (e.g. `channel_overrides`), edit `config.yaml` directly via Python `yaml.safe_load`/`yaml.dump`. The `patch` tool also refuses to write to `config.yaml` — use terminal Python as the workaround for both.
- **Gateway restart/stop may timeout**: `hermes gateway stop` and `hermes gateway restart` can hang for 30s+ when the gateway process is stuck (e.g., agent in infinite API wait). Force-kill: `powershell.exe -Command "Stop-Process -Id <PID> -Force"` then `hermes gateway start`.
- **pip 安装到错误的 Python 环境**：系统有两个 Python——系统 Python 3.12（`C:\Users\HMSJ\AppData\Local\Programs\Python\Python312\`）和 Hermes venv Python 3.11（`C:\Users\HMSJ\AppData\Local\hermes\hermes-agent\venv\`）。`which pip` 指向系统 Python 的 pip，但 Hermes gateway 使用 venv。直接 `pip install` 会装到系统 Python，gateway 看不到。**正确做法**：用 venv 的 python.exe -m pip 安装——`/c/Users/HMSJ/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe -m pip install <package>`。安装后用 venv 的 python 验证版本：`venv/Scripts/python.exe -c "import importlib.metadata; print(importlib.metadata.version('<package>'))"`。
- **lark-oapi SDK 版本**：当前使用 lark-oapi（飞书官方 Python SDK）。检查版本：`/c/Users/HMSJ/AppData/Local/hermes/hermes-agent/venv/Scripts/python.exe -c "import importlib.metadata; print(importlib.metadata.version('lark-oapi'))"`。更新时必须用 venv 的 pip（见上条）。GitHub 无 CHANGELOG，版本对比用 `https://github.com/larksuite/oapi-sdk-python/compare/vX.Y.Z...vA.B.C`。
- **`LOG_LEVEL=DEBUG` in .env does NOT affect gateway**: The gateway's log verbosity is controlled by CLI flags (`-v`/`-vv` on `hermes gateway run`), not environment variables. To debug feishu message admission/dropping: stop background service → `hermes gateway run -vv --force 2>&1` → trigger the issue → inspect stderr output. The log file only records INFO and above during normal `hermes gateway start` runs.
- **`free_response_channels` doesn't work on Feishu**: The feishu adapter reads per-group rules from `platforms.feishu.group_rules`, NOT from `free_response_channels`. Use `hermes config set platforms.feishu.group_rules.<chat_id>.require_mention false` instead. This was discovered via source-code inspection of `adapter.py:_admit()` and `_require_mention_for()` — they use `self._group_rules` (populated from `extra.get("group_rules")`), never from `free_response_channels`.
- **`group_rules` bridge (FIXED 2026-07-15)**: `gateway/config.py` bridge 函数漏掉了 `group_rules` 的转发，导致 config.yaml 中 `platforms.feishu.group_rules.<chat_id>.require_mention: false` 永远传不到 adapter。adapter 只能用全局 `require_mention: true`，所有群消息（含话题回复）没 @ 都被拒。修复：在 bridge 函数 `group_user_allowed_commands` 块后添加 `if "group_rules" in platform_cfg: bridged["group_rules"] = platform_cfg["group_rules"]`。如果此问题复现，检查 config.py 是否有这行 bridge。
- **Feishu sessions hidden from Desktop sidebar**: The Desktop GUI's session list in `cli.py:_list_recent_sessions` hardcodes `source="cli"` and `include_all_sources=False`, which hides all gateway-originated sessions (including feishu) from the sidebar and `/sessions` slash command. Fix: change to `include_all_sources=True` and remove the `source="cli"` filter. After this fix, `/sessions` shows all sessions including feishu ones. The Desktop sidebar's "Messaging" section (fed by `refreshMessagingSessions()` in `desktop-controller.tsx`) already includes feishu but in a separate collapsed section — users may need to expand it.
- **Audio sending via lark-cli**: The `--audio` flag rejects WAV files with "file type
  does not match the type of message being sent" (code 230055). Use `--file` instead
  to send audio as a downloadable file attachment. The recipient can click to play.
- **飞书不支持原生语音气泡**：`msg_type="audio"` 本质是文件附件（带播放按钮的音频文件），不是 Telegram/Discord 那种内联语音条。这是平台限制，非 Hermes 问题。详见 `references/voice-audio-capabilities.md`。
- **Bot can't DM users**: If the bot hasn't been added to a user's P2P chat,
  sending via `--as bot --chat-id <p2p_chat_id>` fails with "Bot/User can NOT be
  out of the chat" (code 230002). The user must initiate the DM first, or use
  `--as user` (requires `im:message.send_as_user` scope).
- **`im:message.send_as_user` scope not included by default**: The `--recommend` flag in
  `lark-cli auth login` does NOT request this scope. Must add `--scope "im:message.send_as_user"`.
  Symptom: `lark-cli --as user im +messages-send` fails with error `missing_scope`.
  Fix: re-run OAuth with the scope flag, get a new verification URL, scan QR, poll the device code.
- **Multi-user memory leakage**: Built-in MEMORY.md/USER.md are profile-level — shared by all Feishu users who talk to the same bot on the same profile. Sessions are isolated, memory is NOT. Fix: separate profile, disable memory, or restrict bot visibility. See Step 12 and `references/multi-user-memory-isolation.md`.\n- **Custom bot rate limits (5 QPS / 100 QPM)**: The Feishu custom bot has hard platform-level rate limits of **5 requests/second** and **100 requests/minute** per bot per tenant. Exceeding either triggers HTTP 429. Message/group APIs can NOT be upgraded. Avoid sending at round-hour/half-hour times (e.g. 10:00, 17:30) which may trigger system-level 11232 throttling. Full rate limit tiers and handling strategy: `references/rate-limits.md`.\n- **Finding DM chat_id for cron delivery**: To get a DM's `oc_` format chat_id
  (needed for cron `deliver=feishu:oc_xxx`), send a one-shot test via lark-cli:
  `lark-cli --as bot im +messages-send --user-id ou_xxx --text test`
  The response JSON contains `data.chat_id` as the `oc_` string. The `ou_`
  open_id can be found from `sqlite3 state.db` querying sessions table.
- **Cron delivery: verify target first**: Don't trust the DM chat_id from memory blindly. If cron output shows up in a group, verify with the lark-cli test above. Also note that `cronjob(action=run)` may deliver to the origin session rather than the configured target — test before relying on scheduled delivery.

- **⚠️ SOUL.md is NOT loaded by Hermes**: `~/.hermes/SOUL.md` has zero references in the hermes-agent source code (grep-verified 2026-07-02). Any instructions placed there — format rules, memory write gating, reply style — are NEVER injected into any session. This file is dead weight. Use `agent.system_prompt` (config.yaml → universal injection, see `references/agent-system-prompt-injection.md` for full trace), `display.platforms.feishu.system_prompt` (Step 8, feishu-only), or `display.platforms.feishu.channel_prompts.<chat_id>` (Step 9b, per-channel).
- **话题/引用回复中的 @提及无法被检测**：飞书话题 (topic/thread) 回复和引用回复的消息都带有 `parent_id`。飞书 API **不会**在 `message.mentions` 中填充这些消息的 @提及信息——即使消息内容包含 `@Hermes`，`mentions` 数组也为空。这导致 adapter 的 `_mentions_self()` 返回 False，消息被 `_admit()` 以 `"group_policy_rejected"` 静默丢弃。两层影响：
  1. 如果群配置了 `require_mention: true`（默认），话题中 @Bot 不触发回复。
  2. 即使配了 `group_rules.require_mention: false`，如果 `group_rules` 的 bridge 修复未应用（见下方独立 pitfall），全局 `require_mention` 仍会生效，话题消息照样被拒。
  **诊断方法**: 停止后台 gateway → `hermes gateway run -vv --force 2>&1` 前台运行（`LOG_LEVEL=DEBUG` 对 gateway 无效）→ 触发问题 → 检查日志中的 `dropping inbound event`。详见 `references/topic-thread-debugging.md` 获取完整诊断矩阵、增强日志注入技巧和代码路径。
- **心跳消息在话题模式下自建子话题**：当 agent 运行超过 `gateway_notify_interval`（默认180s），gateway 发送 "⏳ Working — X min" 心跳消息。该消息的 metadata 包含 `thread_id`（话题ID）和 `reply_to_message_id`（原消息ID）。飞书 adapter 的 send 逻辑（adapter.py:4620-4665）检测到两者都存在时，用 `reply` API + `reply_in_thread=True` 发送——在飞书话题群里这会**创建一个新的回复线程**（子话题），而不是发到当前话题里。**根因**：心跳消息应该用 `create` API + `thread_id` 作为 `receive_id` 直接发到话题，而不是用 `reply` API。**临时修复**：`hermes config set agent.gateway_notify_interval 0` 关闭心跳通知。**代码位置**：run.py:19687-19691 的 `_notify_adapter.send()` 调用，以及 adapter.py:4624-4635 的 reply 优先逻辑。
- **Gateway 重启后话题回复发到群主聊天（丢失 thread_id）**：当 gateway 在处理话题消息期间被重启（手动或 crash），auto-resume 恢复 session 时丢失了 session key 中的 `omt_` 话题ID。结果：响应发到群主聊天 `oc_xxx` 而非话题 `omt_xxx`，表现为"agent 自己新建了话题"。**诊断**：日志中 `Sending response (N chars) to oc_xxx` 后面没有话题/thread 信息。**根因**：session key `feishu:group:{chat_id}:{thread_id}` 中的 thread_id 在 auto-resume 路径中未被提取传递给 send 逻辑。**缓解**：处理话题消息期间避免重启 gateway；如果必须重启，用户需在原话题重新发消息触发新 session。**日志关键词**：`Scheduled auto-resume` + 后续 `Sending response to oc_xxx`（无 thread 后缀）。
- **话题消息可能完全不被推送**：部分话题回复消息在 gateway 日志中完全没有记录（连 "Received raw message" 都没有），说明飞书 WebSocket 根本没有推送该事件。这可能是飞书侧的权限或事件订阅问题，与 adapter 代码无关。如果日志中找不到任何 trace，检查飞书开发者后台的事件订阅配置。
- **`md` element single-paragraph constraint**: Feishu's post message `md` tag supports only ONE paragraph per element. Multi-paragraph content in a single `md` element → entire element renders as plain text. The fix in `_build_markdown_post_rows` (`_make_rows()` splits on blank lines) is applied in hermes-agent source code. If multi-paragraph messages render as plain text after a fresh install, verify the fix is present. See `references/markdown-rendering-fix.md` for details.
- **飞书不支持原生语音气泡**：`msg_type="audio"` 本质是文件附件（带播放按钮的音频文件），不是 Telegram/Discord 那种内联语音条。这是平台限制，非 Hermes 问题。详见 `references/voice-audio-capabilities.md`。
- **Stale assumptions about Feishu capabilities**: Code comments and historical memory entries may claim certain features don't work (e.g. "tables forced to text mode"). Feishu's post+md renderer evolves — always verify against live Feishu or source code before concluding something is unsupported. The `_MARKDOWN_TABLE_RE` force-text block was left in adapter.py for months based on an outdated comment; tables actually work fine now. **Lesson**: when a reference doc claims a fix is applied, verify by reading the actual source — the doc may be ahead of reality (as happened 07-01 doc claim vs 07-10 actual fix).
- **Agent 卡死导致所有消息被"⚡ Interrupting"**: 当 agent 卡在长时间 API 调用上（如 MiMo 流式响应超时），`interrupt()` 只设软标志位 `_interrupt_requested`，agent 永远到不了检查点。结果：agent 永远 busy → 每条新消息都走 `_handle_active_session_busy_message` → 全部触发"⚡ Interrupting current task"但排队的消息永远不会被处理。**诊断**：群里连续收到多条"⚡ Interrupting"回复。**立即修复**：群里发 `/stop` 强制终止卡死的 agent。**长期缓解**：减小 `agent.gateway_timeout`（默认 1800s），或在 channel_prompt 中加超时放弃指引。详见 `references/interrupt-stuck-agent.md`。
- **Group events stop after gateway restart**:
## Reply Channel Discipline

**Hermes TUI 里问 → TUI 回。飞书里问 → 飞书回。Cron 自动推送 → 推飞书。禁止跨渠道回复。**

This prevents confusion where the user asks in one channel but receives the answer in another.

## Step 13 — Per-Channel Model & Sub-Agent Delegation

### 13a — Override model per group/channel

Use `channel_overrides` to assign different models to different groups:

```bash
hermes config set platforms.feishu.channel_overrides.oc_CHAT_ID.model deepseek-v4-flash
hermes config set platforms.feishu.channel_overrides.oc_CHAT_ID.provider deepseek
```

To remove an override (no `hermes config unset`), use Python:
```python
import yaml
with open(r'C:\Users\HMSJ\AppData\Local\hermes\config.yaml') as f:
    c = yaml.safe_load(f)
c['platforms']['feishu'].pop('channel_overrides', None)
with open(r'C:\Users\HMSJ\AppData\Local\hermes\config.yaml', 'w') as f:
    yaml.dump(c, f, default_flow_style=False, allow_unicode=True, sort_keys=False)
```

### 13b — Sub-agent delegation model

Sub-agents inherit the parent model unless pinned globally. To use a different model for delegated tasks:

```bash
hermes config set delegation.model deepseek-v4-pro
hermes config set delegation.provider deepseek
```

### 13c — Auto-delegation prompt

Add a channel prompt to make the agent automatically delegate complex tasks:

```bash
hermes config set platforms.feishu.channel_prompts.oc_CHAT_ID \
  "始终使用中文回复，简洁直接。遇到以下情况使用 delegate_task 委托子代理异步处理：1) 需要多轮工具调用（3+轮）的复杂任务 2) 预计耗时超过 30 秒的任务 3) 需要深度分析/计算的任务。委托后主会话立刻简短回复「收到，处理中，稍后反馈」，不等子代理结果。"
```

### 13d — `thread_sessions_per_user` (话题模式)

Controls whether topic/thread replies get per-user session isolation:

```bash
hermes config set platforms.feishu.thread_sessions_per_user true
```

- `false` (default): All users share one session per topic → messages interrupt each other
- `true`: Each user gets own session per topic → no cross-user interruption, but same-user rapid messages in same topic still interrupt

This is orthogonal to `group_sessions_per_user` (default `true`), which isolates regular group messages by user.

**Session key 构建逻辑**（gateway/session.py:871-959）：

| 场景 | Session Key |
|------|------------|
| 私聊 | `feishu:dm:{chat_id}` |
| 私聊+话题 | `feishu:dm:{chat_id}:{thread_id}` |
| 普通群聊 | `feishu:group:{chat_id}:{user_id}` |
| 话题模式（共享） | `feishu:group:{chat_id}:{thread_id}` |
| 话题模式（隔离） | `feishu:group:{chat_id}:{thread_id}:{user_id}` |

**话题模式的故障隔离**：每个话题独立 session，一个话题的 agent 卡死不影响其他话题。`/stop` 只终止当前话题。详见 `references/interrupt-stuck-agent.md`。
