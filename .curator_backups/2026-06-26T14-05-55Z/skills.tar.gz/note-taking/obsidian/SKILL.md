---
name: obsidian
description: Read, search, create, and edit notes in the Obsidian vault.
platforms: [linux, macos, windows]
---

# Obsidian Vault

Use this skill for filesystem-first Obsidian vault work: reading notes, listing notes, searching note files, creating notes, appending content, and adding wikilinks.

## Vault path
## 目录架构

```
~/Documents/KnowledgeBase/              ← Git 仓库 (branchingjade/knowledge-base)
├── .git/
├── .gitignore
├── Obsidian Vault/                     ← Obsidian 仓库（唯一）
│   ├── .obsidian/                      ← Obsidian 配置（.gitignore 排除 workspace 等）
│   ├── 犬子无双/                       ← 项目子目录
│   │   └── assets/                     ← 截图等附件
│   ├── Hermes 技能来源.md
│   └── ...                             ← 其他笔记
└── README.md
```

- **KnowledgeBase 根目录** = Git 仓库，不定时手动 push
- **Obsidian Vault 子目录** = Obsidian 打开的唯一仓库
- 笔记全放在 `Obsidian Vault/` 下，Git 版本控制在 KnowledgeBase 层
- 不要在 KnowledgeBase 根目录直接放 `.obsidian/`（会造成伪双仓库）
- **Push 规则**：KnowledgeBase 内任何文件变动后，Agent 必须先执行 `git status --short` 展示变更清单，再用 `clarify` 主动询问"要 push 吗？"。用户明确同意后才执行 `git add -A && git commit -m "..." && git push`。绝对禁止不经确认直接 push。

## Vault path

Use a known or resolved vault path before calling file tools.
The documented vault-path convention is the `OBSIDIAN_VAULT_PATH` environment variable, for example from `${HERMES_HOME:-~/.hermes}/.env`. If it is unset, use `~/Documents/KnowledgeBase/Obsidian Vault`.

File tools do not expand shell variables. Do not pass paths containing `$OBSIDIAN_VAULT_PATH` to `read_file`, `write_file`, `patch`, or `search_files`; resolve the vault path first and pass a concrete absolute path. Vault paths may contain spaces, which is another reason to prefer file tools over shell commands.

If the vault path is unknown, `terminal` is acceptable for resolving `OBSIDIAN_VAULT_PATH` or checking whether the fallback path exists. Once the path is known, switch back to file tools.

## Read a note

Use `read_file` with the resolved absolute path to the note. Prefer this over `cat` because it provides line numbers and pagination.

## List notes

Use `search_files` with `target: "files"` and the resolved vault path. Prefer this over `find` or `ls`.

- To list all markdown notes, use `pattern: "*.md"` under the vault path.
- To list a subfolder, search under that subfolder's absolute path.

## Search

Use `search_files` for both filename and content searches. Prefer this over `grep`, `find`, or `ls`.

- For filenames, use `search_files` with `target: "files"` and a filename `pattern`.
- For note contents, use `search_files` with `target: "content"`, the content regex as `pattern`, and `file_glob: "*.md"` when you want to restrict matches to markdown notes.

## Create a note

Use `write_file` with the resolved absolute path and the full markdown content. Prefer this over shell heredocs or `echo` because it avoids shell quoting issues and returns structured results.

## Append to a note

Prefer a native file-tool workflow when it is not awkward:

- Read the target note with `read_file`.
- Use `patch` for an anchored append when there is stable context, such as adding a section after an existing heading or appending before a known trailing block.
- Use `write_file` when rewriting the whole note is clearer than constructing a fragile patch.

For an anchored append with `patch`, replace the anchor with the anchor plus the new content.

For a simple append with no stable context, `terminal` is acceptable if it is the clearest safe option.

## Targeted edits

Use `patch` for focused note changes when the current content gives you stable context. Prefer this over shell text rewriting.

## Wikilinks

Obsidian links notes with `[[Note Name]]` syntax. When creating notes, use these to link related content.

## Git integration

When the vault lives inside a Git repo (e.g. as a subdirectory like `repo/Obsidian Vault/`), `.gitignore` must handle `.obsidian/` directories correctly.

### .gitignore pattern for nested vaults

```
# Track core config, ignore everything else
**/.obsidian/*
!**/.obsidian/app.json
!**/.obsidian/appearance.json
!**/.obsidian/core-plugins.json
!**/.obsidian/community-plugins.json
**/.obsidian/workspace*
```

**Why `**/` prefix is required:** `.obsidian/*` (without `**/`) only matches `.obsidian/` at the repo root — it will NOT match `Subfolder/.obsidian/`. The `**/` glob matches at any depth, so `**/.obsidian/*` correctly ignores `.obsidian/` directories anywhere in the repo tree.

**Why `/*` not `/`:** `.obsidian/` (trailing slash, directory-only match) prevents re-inclusion of files inside it — Git refuses to un-ignore files whose parent directory is excluded. Use `.obsidian/*` (match all contents) so that negation patterns (`!**/.obsidian/app.json`) can re-include specific files.

Verify with `git check-ignore`:
- Core config (app.json, etc.) should NOT be ignored → tracked
- workspace.json and everything else inside `.obsidian/` should be ignored
