---
name: hermes-browser-cdp
description: Hermes browser 工具集通过 CDP 模式运行，替代有 bug 的 agent-browser --session 模式。
---

# Hermes Browser CDP 模式

## 问题
- `agent-browser --session <name>` 在 Windows 上死锁
- Hermes browser 工具集（browser_navigate/click/snapshot/console 等）默认使用 --session 模式
- 会导致每个 browser 调用卡死

## 兜底策略 ⚠️

**agent-browser / Hermes CDP 走不通时，自动切 Kimi WebBridge 兜底，不纠结。**

| 触发条件 | 症状 | 动作 |
|---------|------|------|
| CDP 端口无响应 | `curl localhost:9222` 失败 | **立即兜底**，不重试 |
| agent-browser 报错/超时 | `browser_navigate` 返回 error/timeout | 重试 1 次 → 仍失败则兜底 |
| 目标站需要登录态 | CDP profile 检测到未登录 | 直接兜底（WebBridge 有用户登录态） |
| headless 被网站拒绝 | 页面空白 / 403 / 验证码 | 兜底 |
| SPA 依赖可见窗口 | Canvas/WebGL 在 headless 下异常 | 兜底 |

详见 `kimi-webbridge` skill。

## 解决方案
Hermes 已有内置 CDP override 机制：
- 设置 `BROWSER_CDP_URL=http://localhost:9222`（在 `~/.hermes/.env`）
- `_get_cdp_override()` 自动读取，将 backend 切换为 `--cdp` 模式
- 无需修改 Hermes 源码

## Chrome 启动方式

### 默认（无头模式）
```bash
"C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --headless=new --user-data-dir=C:\Users\HMSJ\.hermes\chrome-cdp-profile
```

### 首次登录说明（必须告知用户）

**CDP Chrome 是独立浏览器实例**，使用专用 profile `chrome-cdp-profile`，与用户的日常 Chrome/Edge 完全隔离——相当于另一台设备。这意味着：

- **每个网站都需要单独登录一次**（曲多多、GitHub 等）
- **登录态持久保留**：登过一次后，无头/有头切换不会丢失 cookies
- 用户说"怎么又要登录"时 → 解释这是独立 profile，首次需登录，之后不需要

### 需要用户登录时（有头模式）
**自主判断规则：**
- 导航到目标页面后，用 `browser_console` 执行 JS 检测登录状态
- 如果检测到"登录 / 注册"等未登录标识 → 自动切有头，**并解释这是独立 profile 的首次登录**
- 通知用户登录完成 → 自动切回无头
- 登录态保存在 `chrome-cdp-profile`，切换不丢失

**切换命令：**
```bash
# 切有头
taskkill /F /IM chrome.exe 2>/dev/null; sleep 2
cmd //c start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 "--user-data-dir=C:\Users\HMSJ\.hermes\chrome-cdp-profile" "目标URL"

# 切回无头（用户确认登录后）
taskkill /F /IM chrome.exe 2>/dev/null; sleep 2
cmd //c start "" "C:\Program Files\Google\Chrome\Application\chrome.exe" --remote-debugging-port=9222 --headless=new "--user-data-dir=C:\Users\HMSJ\.hermes\chrome-cdp-profile"
```

**登录检测 JS（只用这一版）：**
```javascript
// browser_console 执行，不要凭快照文字判断
(function(){
  var text = document.body.innerText;
  if (text.includes('退出账户') || text.includes('退出登录')) return true;
  if (text.includes('个人会员') || text.includes('企业会员') || text.includes('会员中心')) return true;
  return false;
})()
```
- 返回 `true` = 已登录
- 返回 `false` = 未登录，需切有头

### 开机自启
`C:\Users\HMSJ\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup\chrome-debug.vbs`
- 静默启动 Chrome 无头模式 + CDP 9222

## 关键配置
- `~/.hermes/.env`: `BROWSER_CDP_URL=http://localhost:9222`
- Profile: `~/.hermes/chrome-cdp-profile/`（独立 profile，不与主 Chrome 冲突）
- 端口: 9222

## 常见陷阱

### 陷阱 1：用页面文字判断登录态不可靠
页面快照中显示"登录 / 注册"**不代表未登录**——很多网站（如曲多多）即使已登录也始终显示这个链接。**必须用 `browser_console` 执行 JS 检测登录态**，不要凭快照文字判断。正确做法：

```javascript
// 检测已登录的多种标识
(function(){
  var text = document.body.innerText;
  if (text.includes('退出账户') || text.includes('退出登录')) return 'LOGGED_IN';
  if (text.includes('个人会员') || text.includes('企业会员') || text.includes('会员中心')) return 'LOGGED_IN';
  return 'NOT_LOGGED_IN';
})()
```

**被用户纠正过**：凭快照"登录 / 注册"判断未登录→切有头→窗口不可见→反复折腾。根因就是没走 JS 检测。

### 陷阱 2：有头模式窗口可能不可见
在 Windows git-bash 下，`cmd //c start` 和 PowerShell `Start-Process` 启动的 Chrome 窗口**可能不显示在用户屏幕上**（窗口存在但不可见/被遮挡/在另一桌面）。表现为：
- `curl localhost:9222/json/version` 有响应
- `browser_navigate` 正常
- 但用户说"看不到窗口"

**解决方案**：
- 优先用无头模式 + JS 检测登录态，避免切有头
- 如需切有头，先告知用户可能在任务栏找 Chrome 图标
- 备选：让用户自己在开始菜单打开 CDP profile 的 Chrome

### 陷阱 3：`taskkill /F /IM chrome.exe` 会误杀用户主 Chrome
用户日常使用的 Chrome 和 CDP Chrome 共享进程名。杀全部 Chrome 会关掉用户的所有标签页。用 PowerShell 精确定位 CDP profile 进程：

```powershell
Get-CimInstance Win32_Process -Filter "name='chrome.exe'" | 
  ForEach-Object { if ($_.CommandLine -match 'chrome-cdp-profile') { 
    Stop-Process -Id $_.ProcessId -Force 
  }}
```

### 陷阱 4：SPA 网站导航策略

Vue/Nuxt SPA（如曲多多 haifanwu.com）有多种导航方式，优先级如下：

**首选（SSR 直链）**：如果站点支持服务端渲染（SSR），直接用 `browser_navigate` 导航到完整 URL——最快、最稳定。
```bash
browser_navigate → https://haifanwu.com/song-detail/4776972
```
每个页面独立加载，不依赖 SPA 状态，连续导航多页也不会断连。

**备选（框架路由）**：当 SSR 不可用时，用 `browser_console` 调 Nuxt router：
```javascript
window.$nuxt.$router.push('/song-detail/4776972')
```
⚠️ **陷阱**：连续多次 `$router.push` 后 SPA 可能进入空页面（Nuxt context 丢失），此时需 `browser_navigate` 回首页重新初始化。

**不生效的方式**：hash 路由 `/#/music/ID`、query 参数 `?keyword=ID`、搜索框程序化输入——均被 SPA 忽略。

## 典型工作流：批量提取 SPA 页面数据

1. `browser_navigate` 到目标首页（确认登录态用 JS 检测）
2. 查路由：`browser_console` → `$nuxt.$router.options.routes`
3. **首选 SSR 直链**：`browser_navigate` 直接导航到完整 URL，最稳定
4. 循环提取：导航 → `browser_console` 提取数据
5. **默认串行**，≤20 页不用子 agent。页面数 >20 且每页 >3 秒时才考虑 `delegate_task`
