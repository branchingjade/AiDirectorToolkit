# 网页调研常见障碍与应对

> 撰写 analysis-report 时，网页调研经常遇到以下障碍，按优先级排列应对策略。

## 一、搜索引擎封锁

**现象**：
- Google → CAPTCHA（`sorry/index` 重定向）
- Bing → Cloudflare 验证（"请解决以下难题以继续"）
- DuckDuckGo → CAPTCHA（"Select all squares containing a duck"）

**应对**：
1. **跳过搜索，直接访问已知产品页**（最有效）。如 BytePlus 产品页 `byteplus.com/en/product/xxx` 直接用 curl 验证存在性。
2. 用 **浏览器工具导航到搜索页** 有时能绕过（Bing 偶尔成功），但不是可靠方案。
3. 对于中文搜索，Bing 对中文关键词匹配差——"火山引擎 视频超分"返回的是真·火山科普页面。此时**英文搜索或直接用产品域名推测 URL**。

## 二、SPA 页面无法提取内容

**现象**：
- curl 返回 HTTP 200 + JS 壳（`You need to enable JavaScript to run this app`）
- browser 工具渲染为空页面或 SPA 路由 404

**涉及平台**：
- volcengine.com（火山引擎）—— 所有产品页为 React SPA
- byteplus.com（BytePlus）—— 同上
- docs.byteplus.com —— 同上
- openai.com —— Cloudflare 保护

**应对**：
1. curl 返回 200 只代表「页面存在」，不代表「内容可提取」
2. browser 工具对这些 SPA 的渲染不稳定：higgsfield.ai 正常，volcengine/byteplus 空白或 404
3. **标记为「需本地浏览器打开」**，把链接给用户自己看
4. 尝试 docs 子域名——有时文档站比产品站更容易渲染

## 三、数据来源分级

报告中必须标明每项数据的来源级别：

| 级别 | 含义 | 示例 |
|---|---|---|
| 网页验证 | curl/browser 成功提取 | "Topaz $299/年（topazlabs.com 价格页验证）" |
| 训练知识 | 模型记忆，可能过时 | "CapCut Pro ¥79/月（训练数据，待验证）" |
| 推断 | 基于已知信息推导 | "火山引擎 智能超分 API（基于产品名录推断，未访问具体页）" |

## 四、2026-06 已知可访问的产品页

| 平台 | URL | 状态 |
|---|---|---|
| Topaz Video AI | `topazlabs.com` | ✅ curl 可提取文字 |
| Higgsfield AI | `higgsfield.ai` | ✅ browser 渲染正常 |
| BytePlus Video Enhancer | `byteplus.com/en/product/video-enhancer` | ⚠️ curl 200，browser 渲染 404 |
| BytePlus Video Enhance Docs | `docs.byteplus.com/en/docs/byteplus-video-enhance` | ⚠️ curl 200，browser 空白 |
| 火山引擎产品页 | `volcengine.com/product` | ⚠️ browser 空白 |
| OpenAI Sora | `openai.com/sora/` | ❌ Cloudflare 保护 |
| RunningHub | `runninghub.ai` | ✅ curl 可提取 |
