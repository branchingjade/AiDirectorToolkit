---
name: xiaomi-mimo-provider
description: "Xiaomi MiMo provider: model selection, vision support matrix, connectivity testing, auxiliary vision setup in Hermes."
version: 2.1.0
author: agent
tags: [xiaomi, mimo, provider, vision, multimodal, auxiliary, configuration, audio, video, tts, asr]
platforms: [windows, linux, macos]
related_skills: [mimo-audio-analyzer]
---

# Xiaomi MiMo Provider

Xiaomi MiMo is a Chinese LLM provider accessible via OpenAI-compatible API (also supports Anthropic API format for images). Use it for chat, vision, audio understanding, video understanding, TTS, and ASR tasks in Hermes.

See `mimo-audio-analyzer` skill for audio analysis. See `references/mimo-api-limits.md` for full MiMo API reference.

## Setup

```bash
# In ~/.hermes/.env
XIAOMI_API_KEY=<your-key>
XIAOMI_BASE_URL=https://api.xiaomimimo.com/v1
```

Get API key at: https://platform.xiaomimimo.com

## Available Models & Capabilities

| Model | Chat | Vision | Audio | TTS | ASR | Notes |
|-------|:----:|:------:|:-----:|:---:|:---:|-------|
| `mimo-v2.5` | ✅ | ✅ | ✅ | ❌ | ❌ | Omni-modal, 1M context. Vision + audio understanding |
| `mimo-v2.5-pro` | ✅ | ❌ | ❌ | ❌ | ❌ | 1T params/42B active, 1M context. Chat only |
| `mimo-v2.5-pro-ultraspeed` | ✅ | ❌ | ❌ | ❌ | ❌ | FP4 quantized, 1000 tok/s. **No vision/audio** |
| `mimo-v2-omni` | ✅ | ✅ | ❌ | ❌ | ❌ | ⚠️ Deprecated 2026.6.30 — use `mimo-v2.5` |
| `mimo-v2-flash` | ✅ | ❌ | ❌ | ❌ | ❌ | ⚠️ Deprecated 2026.6.30 |
| `mimo-v2-pro` | ✅ | ❌ | ❌ | ❌ | ❌ | ⚠️ Deprecated 2026.6.30 |
| `mimo-v2.5-tts` | ❌ | ❌ | ❌ | ✅ | ❌ | TTS with voice control (free) |
| `mimo-v2.5-tts-voiceclone` | ❌ | ❌ | ❌ | ✅ | ❌ | Voice cloning |
| `mimo-v2.5-tts-voicedesign` | ❌ | ❌ | ❌ | ✅ | ❌ | Voice design |
| `mimo-v2-tts` | ❌ | ❌ | ❌ | ✅ | ❌ | ⚠️ Deprecated 2026.6.27 |
| `mimo-v2.5-asr` | ❌ | ❌ | ❌ | ❌ | ✅ | Bilingual + dialects, lyrics |

### Pricing (CNY per MTok, as of 2026.06)

| Model | Input (cache hit) | Input (cache miss) | Output |
|-------|:-:|:-:|:-:|
| `mimo-v2.5` | ¥0.02 | ¥1 | ¥2 |
| `mimo-v2.5-pro` | ¥0.025 | ¥3 | ¥6 |
| `mimo-v2.5-pro-ultraspeed` | ¥0.075 | ¥9 | ¥18 |
| TTS Series | Free (limited time) | — | — |
| ASR | ¥0.5/hour | — | — |

> V2 models auto-routed to V2.5 series with V2.5 pricing. Full deprecation 2026.6.30.

---

## Multimodal Understanding Limits

### Image (`type: "image_url"`, via `image_url.url`)

| Limit | Value |
|-------|-------|
| Formats | JPEG, PNG, GIF, WebP, BMP |
| URL size | ≤ 50 MB per image |
| Base64 size | ≤ 50 MB per image |
| Multi-image | ✅ Supported (within context limits) |
| Token calc | Complex — based on resolution (PATCH=16, MERGE=2, min 8192px, max 8388608px). See docs for formula. |
| Local file | ❌ URL or base64 only |
| API formats | OpenAI (`/v1/chat/completions`) + Anthropic (`/anthropic/v1/messages`) |

### Audio (`type: "input_audio"`, via `input_audio.data`)

| Limit | Value |
|-------|-------|
| Formats | MP3, WAV, FLAC, M4A, OGG |
| URL size | ≤ 100 MB |
| Base64 size | ≤ 50 MB (encoded string) |
| Token calc | ≈ duration(sec) × 6.25 |
| Local file | ❌ URL or base64 only |

### Video (`type: "video_url"`, via `video_url.url`)

| Limit | Value |
|-------|-------|
| Formats | MP4, MOV, AVI, WMV |
| URL size | ≤ 300 MB |
| Base64 size | ≤ 50 MB |
| Token calc | video_tokens (fps×resolution) + audio_tokens (≈6.25×sec). See docs for formula. |
| Local file | ❌ URL or base64 only |
| Control params | `fps` (0.1-10, default 2), `media_resolution` ("default" or "max") |

---

## Deep Think / Reasoning

MiMo v2.5 uses `reasoning_content` in responses. Key rule: in multi-turn agent sessions with tool calls, you **must** pass back `reasoning_content` for every assistant message that contains tool calls, or the API returns 400.

**PITFALL**: `reasoning_tokens` compete with `completion_tokens` budget. Set generous `max_completion_tokens` (4096+) or content output will be empty. This affects all modalities (text, image, audio, video).

---

## Hermes Auxiliary Vision Setup

```bash
# Correct vision model
hermes config set auxiliary.vision.provider xiaomi
hermes config set auxiliary.vision.model mimo-v2.5
```

Config result in `config.yaml`:
```yaml
auxiliary:
  vision:
    provider: xiaomi
    model: mimo-v2.5
```

The empty `base_url` and `api_key` in the auxiliary section are normal — Hermes falls back to `XIAOMI_API_KEY` and `XIAOMI_BASE_URL` from `.env`.

---

### Hermes TTS Setup

```bash
hermes config set tts.provider xiaomi
hermes config set tts.model mimo-v2.5-tts
```

**CRITICAL**: MiMo TTS does NOT use OpenAI's `/v1/audio/speech` endpoint.
See `scripts/mimo_tts.py` for a working command provider that uses the correct
`POST /v1/chat/completions` format.

To wire it into Hermes, add a command provider under `tts.providers.xiaomi` in
config.yaml:

```yaml
tts:
  provider: xiaomi
  providers:
    xiaomi:
      type: command
      command: python "C:/Users/HMSJ/AppData/Local/hermes/scripts/mimo_tts.py" "{text}" "{output_path}"
      timeout: 60
      output_format: wav
      env:
        XIAOMI_API_KEY: ${XIAOMI_API_KEY}
        XIAOMI_BASE_URL: ${XIAOMI_BASE_URL}
```

Adjust the script path for Linux/macOS. The `env` block expands `${ENV_VAR}`
references from the Hermes process environment at runtime.

**xiaomi is NOT a built-in TTS provider.** There is no bundled plugin for xiaomi
TTS. The dispatch falls through to Edge TTS (default). To actually use MiMo TTS,
register a custom command provider in `~/.hermes/config.yaml`:

```yaml
tts:
  provider: xiaomi
  providers:
    xiaomi:
      type: command
      command: python "<hermes_home>/scripts/mimo_tts.py" "{text}" "{output_path}"
      timeout: 60
      output_format: wav
      env:
        XIAOMI_API_KEY: ${XIAOMI_API_KEY}
        XIAOMI_BASE_URL: ${XIAOMI_BASE_URL}
  model: mimo-v2.5-tts
```

The command provider script is at `scripts/mimo_tts.py` in this skill.
Copy it to `~/.hermes/scripts/` and reference the absolute path in the command.

### Known Limitation: ~1s Audio

MiMo v2.5 TTS currently produces ~1 second of audio per API call, regardless of
text length or `max_tokens` setting. This is a free-tier limitation as of
2026.06. For longer speech, chain multiple calls.

### Hermes MEDIA Delivery

TTS generates WAV files tagged with `MEDIA:<path>`. In **gateway sessions**
(Feishu/Telegram/Discord), the platform adapter auto-delivers audio as a voice
message. In **TUI mode**, MEDIA tags are displayed as text paths only — no
auto-playback.

**PITFALL — Fallthrough to Edge TTS**: The xiaomi provider is NOT a built-in
Hermes TTS provider. Without a command provider or plugin, the dispatch silently
falls through to Edge TTS. If `edge_tts` Python package is installed, TTS
"works" but uses Edge voices, not MiMo. If `edge_tts` is missing, all TTS calls
fail with "No audio was received" — the error looks like a MiMo problem but is
actually a missing Edge TTS dependency.

**Fix**: Add a command provider under `tts.providers.xiaomi` in
`~/.hermes/config.yaml`. See `scripts/mimo_tts_command.py` for the
ready-to-use command script:

```yaml
tts:
  provider: xiaomi
  model: mimo-v2.5-tts
  providers:
    xiaomi:
      type: command
      command: python "path/to/mimo_tts_command.py" "{text}" "{output_path}"
      timeout: 60
      output_format: wav
```

The script calls `POST /v1/chat/completions` with the MiMo TTS message format
and decodes the base64 WAV from `choices[0].message.audio.data`.

### Hermes TTS Dispatch Architecture

**xiaomi/mimo is NOT a built-in TTS provider.** Hermes built-ins are: `edge`,
`openai`, `elevenlabs`, `minimax`, `xai`, `mistral`, `gemini`, `neutts`,
`piper`, `kittentts`.  When `tts.provider: xiaomi`, the dispatch chain is:

1. **Command provider** — checks `tts.providers.xiaomi: type: command` in config. If
   not declared, skips.
2. **Plugin provider** — calls `agent.tts_registry.get_provider("xiaomi")`. The
   xiaomi TTS provider is registered at plugin-discovery time by a bundled plugin
   (under `hermes-agent/plugins/`). If found, calls `provider.synthesize()`.
3. **Fallthrough** — if no plugin found, falls through the built-in elif chain and
   lands on Edge TTS as default.

### MiMo TTS / ASR API Format (CRITICAL)

**ALL MiMo special-purpose models use the standard `/v1/chat/completions`
endpoint — NOT OpenAI-style dedicated endpoints.** Specifically:

| Task | Model | Endpoint | OpenAI equiv (DOES NOT WORK) |
|------|-------|----------|------------------------------|
| TTS | `mimo-v2.5-tts` | `POST /v1/chat/completions` | `/v1/audio/speech` → **404** |
| Voice Clone | `mimo-v2.5-tts-voiceclone` | `POST /v1/chat/completions` | `/v1/audio/speech` → **404** |
| Voice Design | `mimo-v2.5-tts-voicedesign` | `POST /v1/chat/completions` | `/v1/audio/speech` → **404** |
| ASR | `mimo-v2.5-asr` | `POST /v1/chat/completions` | `/v1/audio/transcriptions` → **404** |

**Correct TTS request format:**
```json
{
  "model": "mimo-v2.5-tts",
  "messages": [
    {"role": "user", "content": "<style instruction>. <text to speak>"},
    {"role": "assistant", "content": ""}
  ],
  "max_tokens": 4096
}
```

- **Both user AND assistant messages are required** (API returns 400 without
  assistant role: `"messages must contain an assistant role for TTS model"`).
- User message content: style instruction (first sentence) + text to speak.
- Response: `choices[0].message.audio` → dict with `data` key (base64-encoded
  WAV audio bytes).

**Auth**: Use `api-key` header (not `Authorization: Bearer`). A valid key
returns HTTP 200; an expired/revoked key returns 401 `Invalid API Key`.

### Hermes TTS Dispatch Architecture

**xiaomi/mimo is NOT a built-in TTS provider.** Hermes built-ins are: `edge`,
`openai`, `elevenlabs`, `minimax`, `xai`, `mistral`, `gemini`, `neutts`,
`piper`, `kittentts`.  When `tts.provider: xiaomi`, the dispatch chain is:

1. **Command provider** — checks `tts.providers.xiaomi: type: command` in config.
2. **Plugin provider** — the xiaomi TTS plugin (bundled under
   `hermes-agent/plugins/`) registers via `agent.tts_registry.register_provider()`.
   If found, calls `provider.synthesize()`.
3. **Fallthrough** — if no plugin, falls to Edge TTS default.

The bundled xiaomi plugin is in `hermes-agent/plugins/` (not the model-providers
subdirectory — that's only chat provider registration). The TTS plugin must call
`/v1/chat/completions` with the message format above.

### TTS Troubleshooting

When xiaomi TTS fails (\"No audio was received\"), check:
1. **Key validity** — `GET /v1/models` with `api-key` header. 401 = expired.
2. **Endpoint** — `/v1/audio/speech` will always 404. The plugin uses
   `/v1/chat/completions`.
3. **Fallback** — `hermes config set tts.provider edge` for free Edge TTS.
4. **Direct test** — use the Python script pattern above to verify the API works
   independently of Hermes plugin routing.

### MiMo TTS Raw API

See `references/mimo-tts-api.md` for the full request/response format, Python
example, and voice control instructions. Key points:

- Endpoint: `POST /v1/chat/completions` (NOT `/v1/audio/speech` — that 404s)
- Messages MUST include both `user` AND `assistant` roles (assistant content can
  be empty). Omitting assistant → 400.
- Response audio is in `message.audio.data` as base64-encoded WAV.
- No separate `voice` parameter — style instructions go in the user message
  content alongside the text.

### TTS Debugging Flow

See `references/hermes-tts-dispatch.md` for the full Hermes TTS dispatch
architecture and the xiaomi plugin registration path.

When xiaomi TTS fails ("No audio was received"), debug in this order:

1. **Test key validity** — `POST /v1/chat/completions` with any chat model.
   401 = expired key (fix: reissue at platform.xiaomimimo.com).
2. **Test TTS directly** — use the format in `references/mimo-tts-api.md`.
   Bypass Hermes plugin and call `/v1/chat/completions` with user+assistant
   messages. If this works but Hermes still fails, the plugin is the issue.
3. **Check endpoint** — `/v1/audio/speech` will always 404 on MiMo (MiMo TTS
   does NOT support OpenAI TTS format). Don't use this as a diagnostic.
4. **Check plugin registration** — the xiaomi TTS is registered by a bundled
   plugin at discovery time (`hermes-agent/plugins/`). If registration broke
   (e.g. after an update), dispatch falls through to Edge TTS silently.
5. **Fallback** — `hermes config set tts.provider edge` enables free Edge TTS
   immediately while debugging.

---

## Audio Analysis Script

See `mimo-audio-analyzer` skill for a ready-to-use script that sends local audio files to MiMo v2.5 via base64 encoding.

---

## Testing Connectivity

### List models
```bash
curl -s "$XIAOMI_BASE_URL/models" -H "Authorization: Bearer $XIAOMI_API_KEY"
```

### Test vision with base64 image
MiMo vision API requires base64-encoded images (URL-based downloads may fail). Use `data:image/<type>;base64,...` format.

### Test chat
```bash
curl -s "$XIAOMI_BASE_URL/chat/completions" \
  -H "api-key: $XIAOMI_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"mimo-v2.5","messages":[{"role":"user","content":"hello"}],"max_tokens":20}'
```

---

## Notes

- **auth header**: MiMo uses `api-key` header (not `Authorization: Bearer`), though both may work.
- **Reasoning tokens**: `mimo-v2.5` and `mimo-v2.5-pro-ultraspeed` use reasoning/thinking tokens that consume `max_completion_tokens` quota. Set generous `max_tokens` to get actual content.
- **Image format**: bmp/gif/png/jpeg/webp supported. Must be base64-encoded data URL for best reliability.
- **URL images**: MiMo API may fail to download images from URLs directly. Always use base64.
- **Hermes URL safety**: Hermes vision tool validates URL safety via DNS — some URLs may be rejected before reaching MiMo. Use local files when possible.
- **Anthropic API**: MiMo supports Anthropic Messages API at `/anthropic/v1/messages` for image understanding. Uses `api-key` header.
- **Local files**: ALL MiMo models require URL or base64 — no direct file upload support.
